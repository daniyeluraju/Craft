<?php
/**
 * Logout
 * Secure Credit Card Management System
 */
require_once 'includes/auth.php';
session_destroy();
header('Location: public/login.php');
exit;
