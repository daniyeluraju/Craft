<?php
/**
 * About Page
 * Secure Credit Card Management System
 */
require_once '../includes/auth.php';
$pageTitle = 'About — CreditGuard';
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?></title>
<meta name="description" content="Learn about CreditGuard — our mission, security features, and digital credit management technology.">
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<nav class="navbar">
    <a href="index.php" class="navbar-brand">
        <div class="logo-icon">💳</div><span>CreditGuard</span>
    </a>
    <ul class="navbar-nav">
        <li><a href="index.php">Home</a></li>
        <li><a href="about.php" class="active">About</a></li>
        <li><a href="contact.php">Contact</a></li>
    </ul>
    <div class="navbar-actions">
        <button class="theme-toggle"><span class="theme-icon">☀️</span></button>
        <a href="login.php" class="btn btn-ghost btn-sm">Login</a>
        <a href="register.php" class="btn btn-primary btn-sm">Get Started</a>
    </div>
</nav>

<!-- Hero -->
<section style="padding:140px 0 80px;background:radial-gradient(ellipse 80% 60% at 50% 0%,rgba(37,99,235,0.3) 0%,transparent 70%);">
    <div class="container" style="text-align:center;">
        <div class="section-tag">🏦 About CreditGuard</div>
        <h1 class="section-title" style="margin:12px 0;">Why Digital Credit Management Matters</h1>
        <p class="section-subtitle" style="max-width:680px;margin:0 auto;">
            In a world of digital payments, managing your credit card has never been more important.
            CreditGuard brings enterprise-grade tools to every cardholder.
        </p>
    </div>
</section>

<!-- Stats -->
<section style="padding:0 0 80px;">
    <div class="container">
        <div class="grid-4">
            <?php
            $stats = [
                ['50K+','Active Users','👥','#2563EB'],
                ['₹2.5Cr+','Total Managed','💰','#10B981'],
                ['99.9%','System Uptime','⚡','#7C3AED'],
                ['0','Fraud Cases','🛡️','#F59E0B'],
            ];
            foreach($stats as $s): ?>
            <div class="stat-card" style="--accent:<?= $s[3] ?>;">
                <div class="stat-icon" style="background:<?= $s[3] ?>22;">
                    <span><?= $s[0][0] ?></span>
                </div>
                <div class="stat-info">
                    <div class="stat-value"><?= $s[0] ?></div>
                    <div class="stat-label"><?= $s[1] ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Mission -->
<section style="padding:60px 0;background:rgba(0,0,0,0.2);">
    <div class="container">
        <div class="grid-2" style="align-items:center;">
            <div>
                <div class="section-tag">🎯 Our Mission</div>
                <h2 style="font-size:2rem;margin:12px 0 16px;">Empowering Financial Control</h2>
                <p style="color:var(--text-muted);line-height:1.8;margin-bottom:16px;">
                    CreditGuard was built to bridge the gap between traditional banking and modern digital expectations.
                    We believe every cardholder deserves visibility, control, and security over their financial data.
                </p>
                <p style="color:var(--text-muted);line-height:1.8;">
                    Our platform provides real-time insights, intelligent fraud detection, and seamless payment
                    management — giving you the power to make smarter financial decisions.
                </p>
            </div>
            <div style="display:grid;gap:16px;">
                <?php
                $features = [
                    ['🔐','Bank-Grade Encryption','All data is encrypted using AES-256 and BCrypt password hashing.'],
                    ['📱','Real-time Alerts','Instant SMS/email notifications for every transaction.'],
                    ['🤖','AI Fraud Detection','Machine learning models flag suspicious behavior automatically.'],
                    ['☁️','99.9% Uptime','Hosted on redundant infrastructure for maximum availability.'],
                ];
                foreach($features as $f): ?>
                <div class="card" style="padding:20px;">
                    <div style="display:flex;gap:14px;align-items:flex-start;">
                        <div style="font-size:1.5rem;flex-shrink:0;"><?= $f[0] ?></div>
                        <div>
                            <h4 style="margin-bottom:4px;font-size:0.95rem;"><?= $f[1] ?></h4>
                            <p style="color:var(--text-muted);font-size:0.82rem;line-height:1.5;"><?= $f[2] ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>

<!-- Security Features -->
<section style="padding:80px 0;">
    <div class="container">
        <div class="section-header">
            <div class="section-tag">🛡️ Security</div>
            <h2 class="section-title">Multi-Layer Security Architecture</h2>
            <p class="section-subtitle">Your data and transactions are protected by multiple security layers.</p>
        </div>
        <div class="grid-3">
            <?php
            $secFeatures = [
                ['🔑','OTP Verification','Two-factor authentication for all account-critical actions.','#2563EB'],
                ['🔒','CSRF Protection','Every form is protected against Cross-Site Request Forgery attacks.','#10B981'],
                ['🧪','SQL Injection Guard','Prepared statements prevent SQL injection attacks on all queries.','#7C3AED'],
                ['⏱️','Session Management','Sessions expire after inactivity to prevent unauthorized access.','#F59E0B'],
                ['🕵️','Suspicious Activity Monitoring','Admin can monitor and flag unusual transaction patterns.','#DC2626'],
                ['📋','Audit Logs','Every admin action is logged for accountability and compliance.','#06B6D4'],
            ];
            foreach($secFeatures as $f): ?>
            <div class="feature-card">
                <div class="feature-icon" style="background:<?= $f[3] ?>22;color:<?= $f[3] ?>;font-size:1.4rem;"><?= $f[0] ?></div>
                <h3 class="feature-title"><?= $f[1] ?></h3>
                <p class="feature-desc"><?= $f[2] ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Tech Stack -->
<section style="padding:60px 0;background:rgba(0,0,0,0.2);">
    <div class="container">
        <div class="section-header">
            <div class="section-tag">⚙️ Technology</div>
            <h2 class="section-title">Built with Modern Technologies</h2>
        </div>
        <div style="display:flex;gap:16px;flex-wrap:wrap;justify-content:center;">
            <?php
            $tech = ['PHP 8+','MySQL 8','HTML5','CSS3','JavaScript (ES6+)','AJAX','Chart.js','XAMPP','PDO','BCrypt'];
            foreach($tech as $t): ?>
            <div style="background:var(--glass);border:1px solid var(--border);border-radius:30px;padding:8px 20px;font-size:0.85rem;font-weight:600;color:var(--text-muted);">
                <?= $t ?>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- CTA -->
<section style="padding:80px 0;">
    <div class="container" style="text-align:center;">
        <h2 class="section-title">Ready to Get Started?</h2>
        <p class="section-subtitle" style="margin-bottom:32px;">Join thousands managing their credit cards securely with CreditGuard.</p>
        <a href="register.php" class="btn btn-primary btn-lg">Create Account</a>
    </div>
</section>

<footer class="footer">
    <div class="container">
        <div class="footer-bottom" style="border-top:none;">
            <p>© 2026 CreditGuard. MCA Final Year Project.</p>
            <div style="display:flex;gap:16px;">
                <a href="index.php" style="color:var(--text-muted);font-size:0.82rem;">Home</a>
                <a href="about.php" style="color:var(--text-muted);font-size:0.82rem;">About</a>
                <a href="contact.php" style="color:var(--text-muted);font-size:0.82rem;">Contact</a>
            </div>
        </div>
    </div>
</footer>

<div id="toast-container"></div>
<script src="../assets/js/main.js"></script>
</body>
</html>
