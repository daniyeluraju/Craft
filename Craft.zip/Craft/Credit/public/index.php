<?php
/**
 * Public Home Page
 * Credit Card Management System
 */
require_once '../includes/auth.php';
if (isLoggedIn()) {
    header('Location: ' . (isAdmin() ? '../admin/dashboard.php' : '../user/dashboard.php'));
    exit;
}
$pageTitle = 'Credit Card Management System';
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?></title>
<meta name="description" content="Credit Card Management System — Manage your credit cards, track spending, pay bills, and secure your finances in one modern portal.">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>💳</text></svg>">
<style>
/* ── HERO ─────────────────────────────── */
.hero-fullscreen {
    position: relative;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
    overflow: hidden;
}

/* Background image */
.hero-fullscreen::before {
    content: '';
    position: absolute;
    inset: 0;
    background: url('../assets/images/hero-bg.jpg') center center / cover no-repeat;
    z-index: 0;
}

/* Dark overlay so text is perfectly readable */
.hero-fullscreen::after {
    content: '';
    position: absolute;
    inset: 0;
    background: transparent;
    z-index: 1;
}

.hero-center {
    position: relative;
    z-index: 2;
    padding: 0 20px;
    max-width: 860px;
    width: 100%;
}

/* Glowing badge */
.hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    background: rgba(37,99,235,0.18);
    border: 1px solid rgba(37,99,235,0.4);
    border-radius: 30px;
    padding: 7px 18px;
    font-size: 0.8rem;
    font-weight: 600;
    letter-spacing: 1px;
    text-transform: uppercase;
    color: #93C5FD;
    margin-bottom: 28px;
    backdrop-filter: blur(12px);
    animation: fadeInDown 0.6s ease both;
}

/* MAIN TITLE */
.hero-main-title {
    font-family: 'Space Grotesk', sans-serif;
    font-size: clamp(2.6rem, 6vw, 5rem);
    font-weight: 900;
    line-height: 1.1;
    letter-spacing: -1.5px;
    color: #fff;
    margin-bottom: 24px;
    animation: fadeInUp 0.7s ease 0.15s both;
    text-shadow: 0 4px 40px rgba(0, 0, 0, 0.4);
}

.hero-main-title .word-credit { color: #fff; }
.hero-main-title .word-card   { color: #60A5FA; }
.hero-main-title .word-mgmt   {
    color: #000;
}

/* Sub-line */
.hero-tagline {
    font-size: clamp(1rem, 2.2vw, 1.3rem);
    color: rgba(255,255,255,0.7);
    max-width: 620px;
    margin: 0 auto 36px;
    line-height: 1.7;
    font-weight: 400;
    animation: fadeInUp 0.7s ease 0.3s both;
}

/* CTA buttons */
.hero-cta {
    display: flex;
    gap: 14px;
    justify-content: center;
    flex-wrap: wrap;
    animation: fadeInUp 0.7s ease 0.45s both;
    margin-bottom: 56px;
}

/* Feature pills row */
.hero-pills {
    display: flex;
    gap: 12px;
    justify-content: center;
    flex-wrap: wrap;
    animation: fadeInUp 0.7s ease 0.55s both;
}
.hero-pill {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(255,255,255,0.06);
    border: 1px solid rgba(255,255,255,0.12);
    border-radius: 20px;
    padding: 6px 14px;
    font-size: 0.78rem;
    color: rgba(255,255,255,0.75);
    backdrop-filter: blur(8px);
}

/* Scroll indicator */
.scroll-indicator {
    position: absolute;
    bottom: 28px;
    left: 50%;
    transform: translateX(-50%);
    z-index: 2;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 6px;
    color: rgba(255,255,255,0.4);
    font-size: 0.75rem;
    letter-spacing: 1px;
    animation: bounce 2s infinite;
}

@keyframes fadeInDown {
    from { opacity:0; transform:translateY(-20px); }
    to   { opacity:1; transform:translateY(0); }
}
@keyframes fadeInUp {
    from { opacity:0; transform:translateY(24px); }
    to   { opacity:1; transform:translateY(0); }
}
@keyframes bounce {
    0%,100% { transform: translateX(-50%) translateY(0); }
    50%      { transform: translateX(-50%) translateY(8px); }
}
</style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar">
    <a href="index.php" class="navbar-brand">
        <div class="logo-icon">💳</div>
        <span>Credit Card Management System</span>
    </a>
    <ul class="navbar-nav">
        <li><a href="index.php" class="active">Home</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="contact.php">Contact</a></li>
    </ul>
    <div class="navbar-actions">
        <button class="theme-toggle" title="Toggle Theme"><span class="theme-icon">☀️</span></button>
        <a href="login.php" class="btn btn-ghost btn-sm">Login</a>
        <a href="register.php" class="btn btn-primary btn-sm">Get Started</a>
    </div>
</nav>

<!-- ══════════════ HERO ══════════════ -->
<section class="hero-fullscreen">

   
        <!-- MAIN TITLE — centered, prominent -->
        <h1 class="hero-main-title">
            
            <span class="word-mgmt">Credit Card Management System</span>
        </h1>

        

        <!-- Feature pills -->
        
    

</section>

<!-- FEATURES SECTION -->


<!-- HOW IT WORKS -->
<section style="padding:80px 0;">
    <div class="container">
        <div class="section-header">
            <div class="section-tag">🚀 How It Works</div>
            <h2 class="section-title">Get Started in 3 Simple Steps</h2>
        </div>
        <div class="grid-3">
            <?php
            $steps = [
                ['01', 'Register', 'Create an account with email OTP verification in seconds.', '#2563EB'],
                ['02', 'Get Your Card', 'Admin assigns a virtual credit card with your spending limit.', '#7C3AED'],
                ['03', 'Manage & Pay', 'Track spending, pay bills, and stay financially healthy.', '#10B981'],
            ];
            foreach($steps as $s): ?>
            <div class="card" style="padding:32px;text-align:center;position:relative;overflow:hidden;">
                <div style="font-size:3.5rem;font-weight:900;color:<?= $s[3] ?>;opacity:0.12;position:absolute;top:-10px;right:16px;font-family:'Space Grotesk',sans-serif;"><?= $s[0] ?></div>
                <div style="width:56px;height:56px;border-radius:50%;background:<?= $s[3] ?>22;border:2px solid <?= $s[3] ?>44;display:flex;align-items:center;justify-content:center;font-size:1.5rem;font-weight:900;color:<?= $s[3] ?>;margin:0 auto 16px;font-family:'Space Grotesk',sans-serif;"><?= $s[0] ?></div>
                <h3 style="font-size:1.15rem;margin-bottom:10px;"><?= $s[1] ?></h3>
                <p style="color:var(--text-muted);font-size:0.88rem;"><?= $s[2] ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- CTA SECTION -->
<section style="padding:80px 0;background:linear-gradient(135deg,rgba(37,99,235,0.15),rgba(124,58,237,0.1));">
    <div class="container">
        <div style="text-align:center;max-width:600px;margin:0 auto;">
            <h2 class="section-title">Ready to Take Control of Your Finances?</h2>
            <p class="section-subtitle" style="margin-bottom:32px;">Join our Credit Card Management System for secure, smart financial management.</p>
            <div style="display:flex;gap:14px;justify-content:center;flex-wrap:wrap;">
                <a href="register.php" class="btn btn-primary btn-lg">Create Free Account</a>
                <a href="login.php" class="btn btn-ghost btn-lg">Sign In</a>
            </div>
        </div>
    </div>
</section>

<!-- FOOTER -->
<footer class="footer">
    <div class="container">
        <div class="footer-grid">
            <div>
                <div class="navbar-brand" style="position:static;background:none;border:none;padding:0;height:auto;margin-bottom:8px;">
                    <div class="logo-icon">💳</div>
                    <span>CC Management</span>
                </div>
                <p class="footer-desc">A secure, modern credit card management system built for MCA Final Year Project.</p>
            </div>
            <div class="footer-col">
                <h4>Platform</h4>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="contact.php">Contact</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Security</h4>
                <ul>
                    <li><a href="#">OTP Verification</a></li>
                    <li><a href="#">Fraud Detection</a></li>
                    <li><a href="#">Encrypted Data</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Support</h4>
                <ul>
                    <li><a href="contact.php">Help Center</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                </ul>
            </div>
        </div>
        
    </div>
</footer>

<div id="toast-container"></div>
<script src="../assets/js/main.js"></script>
</body>
</html>
