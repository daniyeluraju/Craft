<?php
/**
 * Register Page with OTP Simulation
 * Secure Credit Card Management System
 */
require_once '../includes/auth.php';

if (isLoggedIn()) {
    header('Location: ' . (isAdmin() ? '../admin/dashboard.php' : '../user/dashboard.php'));
    exit;
}

$error = '';

// Process Registration
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {
    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request. Please try again.';
    } else {
        $name     = sanitize($_POST['name'] ?? '');
        $email    = sanitize($_POST['email'] ?? '');
        $mobile   = sanitize($_POST['mobile'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm  = $_POST['confirm_password'] ?? '';
        $gender   = $_POST['gender'] ?? '';
        $address  = sanitize($_POST['address'] ?? '');
        $terms    = $_POST['terms'] ?? '';

        if (empty($name) || empty($email) || empty($mobile) || empty($password) || empty($gender) || empty($address)) {
            $error = 'All fields are required.';
        } elseif (empty($terms)) {
            $error = 'You must agree to the Terms & Conditions.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Invalid email address.';
        } elseif (!preg_match('/^[6-9]\d{9}$/', $mobile)) {
            $error = 'Invalid Indian mobile number.';
        } elseif (strlen($password) < 8) {
            $error = 'Password must be at least 8 characters.';
        } elseif ($password !== $confirm) {
            $error = 'Passwords do not match.';
        } else {
            // Check email exists
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                $error = 'Email already registered. Please login.';
            } else {
                try {
                    $stmt = $pdo->prepare("INSERT INTO users (name, email, mobile, password, status) VALUES (?,?,?,?,'active')");
                    $stmt->execute([$name, $email, $mobile, hashPassword($password)]);
                    $userId = $pdo->lastInsertId();

                    // Welcome notification
                    $notif = $pdo->prepare("INSERT INTO notifications (user_id, title, message, type) VALUES (?,?,?,?)");
                    $notif->execute([$userId, '🎉 Welcome to CreditGuard!', 'Your account has been created. A credit card will be assigned by admin shortly.', 'info']);

                    $_SESSION['flash_type'] = 'success';
                    $_SESSION['flash_msg']  = 'Account created successfully! Please login.';
                    header('Location: login.php');
                    exit;
                } catch (PDOException $e) {
                    $error = 'Registration failed: ' . $e->getMessage();
                }
            }
        }
    }
}

$csrf = generateCSRF();
$demoOtp = $_SESSION['demo_otp'] ?? null;
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Register — CreditGuard</title>
<meta name="description" content="Create your CreditGuard account to manage your credit cards securely.">
<link rel="stylesheet" href="../assets/css/style.css?v=<?= time() ?>">
</head>
<body>
<div class="auth-bg"></div>
<div id="particles" class="particles"></div>

<div class="auth-wrapper">
    <div class="auth-card" style="max-width:520px;">
        <div class="auth-logo">
            <div class="logo-icon">💳</div>
            <div>
                <h1 class="auth-title">Create Account</h1>
                <p class="auth-subtitle">Join CreditGuard for smart card management</p>
            </div>
        </div>

        <?php if ($error): ?>
        <div style="background:rgba(220,38,38,0.1);border:1px solid rgba(220,38,38,0.3);border-radius:12px;padding:12px 16px;margin-bottom:20px;font-size:0.88rem;color:#F87171;">
            <?= $error ?>
        </div>
        <?php endif; ?>

        <!-- Registration Form -->
        <form method="POST" id="register-form">
            <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
            <input type="hidden" name="register" value="1">

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Full Name</label>
                    <input type="text" name="name" class="form-control" placeholder="John Doe"
                           value="<?= htmlspecialchars($_POST['name'] ?? '') ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Mobile Number</label>
                    <input type="tel" name="mobile" class="form-control" placeholder="9876543210"
                           value="<?= htmlspecialchars($_POST['mobile'] ?? '') ?>" maxlength="10" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Email Address</label>
                    <div class="input-group">
                        <input type="email" name="email" class="form-control" placeholder="you@example.com"
                               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
                        <span class="input-group-icon">📧</span>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Gender</label>
                    <div style="display:flex;gap:20px;padding-top:10px;">
                        <label style="display:flex;align-items:center;gap:6px;cursor:pointer;">
                            <input type="radio" name="gender" value="Male" <?= (isset($_POST['gender']) && $_POST['gender'] === 'Male') ? 'checked' : '' ?> required> Male
                        </label>
                        <label style="display:flex;align-items:center;gap:6px;cursor:pointer;">
                            <input type="radio" name="gender" value="Female" <?= (isset($_POST['gender']) && $_POST['gender'] === 'Female') ? 'checked' : '' ?> required> Female
                        </label>
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Address</label>
                <div class="input-group">
                    <input type="text" name="address" class="form-control" placeholder="Your residential address"
                           value="<?= htmlspecialchars($_POST['address'] ?? '') ?>" required>
                    <span class="input-group-icon">📍</span>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Password</label>
                    <div class="input-group">
                        <input type="password" name="password" id="reg-password" class="form-control" placeholder="Min 8 chars" required>
                        <span class="input-group-icon toggle-password">👁️</span>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Confirm Password</label>
                    <div class="input-group">
                        <input type="password" name="confirm_password" class="form-control" placeholder="Repeat password" required>
                        <span class="input-group-icon toggle-password">👁️</span>
                    </div>
                </div>
            </div>

            <!-- Password strength -->
            <div class="form-group" id="strength-bar" style="margin-top:-10px;display:none;">
                <div class="progress-bar-wrap" style="height:4px;">
                    <div class="progress-bar-fill" id="strength-fill" style="width:0%;background:var(--danger);"></div>
                </div>
                <span id="strength-text" style="font-size:0.75rem;color:var(--text-muted);margin-top:4px;display:block;"></span>
            </div>

            <div class="form-group">
                <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:0.85rem;color:var(--text-muted);">
                    <input type="checkbox" name="terms" value="1" required> I agree to the <a href="#" style="color:var(--primary-light);">Terms & Conditions</a> and <a href="#" style="color:var(--primary-light);">Privacy Policy</a>.
                </label>
            </div>

            <button type="submit" class="btn btn-primary btn-block" style="margin-top:8px;" id="reg-btn">
                Create Account
            </button>
        </form>

        <p style="text-align:center;font-size:0.88rem;color:var(--text-muted);margin-top:20px;">
            Already have an account? <a href="login.php" style="color:var(--primary-light);font-weight:600;">Sign in</a>
        </p>
    </div>
</div>

<div id="toast-container"></div>
<script src="../assets/js/main.js"></script>
<script>
// Password strength meter
const passInput = document.getElementById('reg-password');
if (passInput) {
    passInput.addEventListener('input', function() {
        const val = this.value;
        const bar = document.getElementById('strength-bar');
        const fill = document.getElementById('strength-fill');
        const text = document.getElementById('strength-text');
        bar.style.display = val ? 'block' : 'none';
        let score = 0;
        if (val.length >= 8) score++;
        if (/[A-Z]/.test(val)) score++;
        if (/\d/.test(val)) score++;
        if (/[^A-Za-z0-9]/.test(val)) score++;
        const levels = [
            [0, 'var(--danger)', 'Too weak'],
            [25, 'var(--danger)', 'Weak'],
            [50, 'var(--warning)', 'Fair'],
            [75, '#06B6D4', 'Strong'],
            [100, 'var(--success)', 'Very strong']
        ];
        const l = levels[score];
        fill.style.width = l[0] + '%';
        fill.style.background = l[1];
        text.textContent = l[2];
        text.style.color = l[1];
    });
}

// Form loading state
    const form = document.getElementById('register-form');
    if (form) form.addEventListener('submit', () => {
        const btn = form.querySelector('button[type=submit]');
        if (btn) { btn.innerHTML = '<span class="spinner"></span> Processing...'; btn.disabled = true; }
    });
</script>
</body>
</html>
