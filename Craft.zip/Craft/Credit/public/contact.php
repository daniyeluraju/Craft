<?php
/**
 * Contact Page with AJAX Form
 * Secure Credit Card Management System
 */
require_once '../includes/auth.php';

// Handle AJAX contact form
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax_contact'])) {
    header('Content-Type: application/json');
    $name    = sanitize($_POST['name'] ?? '');
    $email   = sanitize($_POST['email'] ?? '');
    $subject = sanitize($_POST['subject'] ?? '');
    $message = sanitize($_POST['message'] ?? '');

    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        echo json_encode(['success' => false, 'message' => 'All fields are required.']);
        exit;
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'Invalid email address.']);
        exit;
    }

    $stmt = $pdo->prepare("INSERT INTO contact_messages (name, email, subject, message) VALUES (?,?,?,?)");
    $stmt->execute([$name, $email, $subject, $message]);
    echo json_encode(['success' => true, 'message' => 'Message sent! We\'ll get back to you within 24 hours.']);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Contact — CreditGuard</title>
<meta name="description" content="Contact CreditGuard support for help with your credit card management.">
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<nav class="navbar">
    <a href="index.php" class="navbar-brand">
        <div class="logo-icon">💳</div><span>CreditGuard</span>
    </a>
    <ul class="navbar-nav">
        <li><a href="index.php">Home</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="contact.php" class="active">Contact</a></li>
    </ul>
    <div class="navbar-actions">
        <button class="theme-toggle"><span class="theme-icon">☀️</span></button>
        <a href="login.php" class="btn btn-ghost btn-sm">Login</a>
        <a href="register.php" class="btn btn-primary btn-sm">Get Started</a>
    </div>
</nav>

<!-- Hero -->
<section style="padding:140px 0 80px;background:radial-gradient(ellipse 60% 60% at 50% 0%,rgba(124,58,237,0.3) 0%,transparent 70%);">
    <div class="container" style="text-align:center;">
        <div class="section-tag">📞 Get in Touch</div>
        <h1 class="section-title" style="margin:12px 0;">How Can We Help?</h1>
        <p class="section-subtitle">Our support team is available 24/7 to help you with any questions.</p>
    </div>
</section>

<!-- Contact Section -->
<section style="padding:0 0 80px;">
    <div class="container">
        <div class="grid-2" style="gap:48px;align-items:flex-start;">
            <!-- Contact Info -->
            <div>
                <h2 style="font-size:1.4rem;margin-bottom:24px;">Support Information</h2>

                <?php
                $contacts = [
                    ['📧','Email Support','support@creditguard.com','Available 24/7 via email'],
                    ['📱','Phone Support','+91 98765 43210','Mon–Sat, 9 AM – 6 PM'],
                    ['💬','Live Chat','chat.creditguard.com','Avg. response time: 2 mins'],
                    ['📍','Office','123, Tech Park, Bengaluru, KA 560001','Visit us Mon–Fri'],
                ];
                foreach($contacts as $c): ?>
                <div class="card" style="padding:20px;margin-bottom:16px;">
                    <div style="display:flex;gap:16px;align-items:flex-start;">
                        <div style="font-size:1.8rem;flex-shrink:0;width:48px;height:48px;display:flex;align-items:center;justify-content:center;background:rgba(37,99,235,0.1);border-radius:12px;">
                            <?= $c[0] ?>
                        </div>
                        <div>
                            <h4 style="margin-bottom:2px;font-size:0.95rem;"><?= $c[1] ?></h4>
                            <p style="color:var(--primary-light);font-weight:600;font-size:0.9rem;margin-bottom:2px;"><?= $c[2] ?></p>
                            <p style="color:var(--text-muted);font-size:0.8rem;"><?= $c[3] ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>

                <!-- FAQ -->
                <div style="margin-top:32px;">
                    <h3 style="font-size:1.1rem;margin-bottom:16px;">Frequently Asked Questions</h3>
                    <?php
                    $faqs = [
                        ['How do I get a credit card assigned?', 'After registering, contact admin to assign a virtual credit card to your account.'],
                        ['Is my data secure?', 'Yes. All data is encrypted using BCrypt and AES-256. We never store plain-text passwords.'],
                        ['How do I report a suspicious transaction?', 'Go to Transactions → flag the transaction, or submit a complaint from your dashboard.'],
                    ];
                    foreach($faqs as $i => $faq): ?>
                    <div style="border:1px solid var(--border);border-radius:12px;margin-bottom:8px;overflow:hidden;">
                        <button onclick="toggleFaq(<?= $i ?>)" 
                                style="width:100%;text-align:left;padding:14px 18px;background:var(--glass);border:none;color:var(--text);font-size:0.88rem;font-weight:600;cursor:pointer;display:flex;justify-content:space-between;align-items:center;">
                            <?= $faq[0] ?> <span id="faq-icon-<?= $i ?>">+</span>
                        </button>
                        <div id="faq-<?= $i ?>" style="display:none;padding:0 18px 14px;font-size:0.85rem;color:var(--text-muted);line-height:1.6;">
                            <?= $faq[1] ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Contact Form -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">📩 Send us a Message</h3>
                </div>
                <div class="card-body">
                    <div id="form-success" style="display:none;text-align:center;padding:32px;">
                        <div style="font-size:4rem;margin-bottom:12px;">✅</div>
                        <h3 style="margin-bottom:8px;">Message Sent!</h3>
                        <p style="color:var(--text-muted);">We'll get back to you within 24 hours.</p>
                        <button onclick="resetForm()" class="btn btn-ghost btn-sm" style="margin-top:20px;">Send Another</button>
                    </div>

                    <form id="contact-form" style="">
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Your Name</label>
                                <input type="text" name="name" id="c-name" class="form-control" placeholder="John Doe" required>
                                <span class="form-error" id="err-name"></span>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Email Address</label>
                                <input type="email" name="email" id="c-email" class="form-control" placeholder="you@example.com" required>
                                <span class="form-error" id="err-email"></span>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Subject</label>
                            <select name="subject" id="c-subject" class="form-control" required>
                                <option value="">-- Select Subject --</option>
                                <option value="Login Issue">Login Issue</option>
                                <option value="Card Problem">Card Problem</option>
                                <option value="Transaction Dispute">Transaction Dispute</option>
                                <option value="Bill Payment">Bill Payment</option>
                                <option value="Account Security">Account Security</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Message</label>
                            <textarea name="message" id="c-message" class="form-control" rows="5"
                                      placeholder="Describe your issue in detail..." required
                                      style="resize:vertical;"></textarea>
                            <span class="form-error" id="err-message"></span>
                        </div>

                        <button type="submit" class="btn btn-primary btn-block" id="contact-btn">
                            📤 Send Message
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<footer class="footer">
    <div class="container">
        <div class="footer-bottom" style="border-top:none;">
            <p>© 2026 CreditGuard. MCA Final Year Project.</p>
        </div>
    </div>
</footer>

<div id="toast-container"></div>
<script src="../assets/js/main.js"></script>
<script>
// FAQ toggle
function toggleFaq(i) {
    const el   = document.getElementById('faq-' + i);
    const icon = document.getElementById('faq-icon-' + i);
    const open = el.style.display === 'block';
    el.style.display = open ? 'none' : 'block';
    icon.textContent = open ? '+' : '−';
}

// Contact form AJAX submission
document.getElementById('contact-form').addEventListener('submit', async function(e) {
    e.preventDefault();
    const btn = document.getElementById('contact-btn');
    btn.innerHTML = '<span class="spinner"></span> Sending...';
    btn.disabled = true;

    const form = new FormData(this);
    form.append('ajax_contact', '1');

    const data = await Ajax.post('contact.php', form);

    if (data.success) {
        document.getElementById('contact-form').style.display = 'none';
        document.getElementById('form-success').style.display = 'block';
        Toast.success('Message Sent!', data.message);
    } else {
        Toast.error('Error', data.message);
        btn.innerHTML = '📤 Send Message';
        btn.disabled = false;
    }
});

function resetForm() {
    document.getElementById('contact-form').reset();
    document.getElementById('contact-form').style.display = 'block';
    document.getElementById('form-success').style.display = 'none';
    document.getElementById('contact-btn').innerHTML = '📤 Send Message';
    document.getElementById('contact-btn').disabled = false;
}
</script>
</body>
</html>
