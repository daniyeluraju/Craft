<?php
/**
 * Login Page
 * Secure Credit Card Management System
 */
require_once '../includes/auth.php';

if (isLoggedIn()) {
    header('Location: ' . (isAdmin() ? '../admin/dashboard.php' : '../user/dashboard.php'));
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request. Please try again.';
    } else {
        $email    = sanitize($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if (empty($email) || empty($password)) {
            $error = 'Please fill in all fields.';
        } else {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && verifyPassword($password, $user['password'])) {
                if ($user['status'] === 'blocked') {
                    $error = '⛔ Your account has been blocked. Contact support.';
                } elseif ($user['status'] === 'pending') {
                    $error = '⏳ Your account is pending verification.';
                } else {
                    // Set session
                    session_regenerate_id(true);
                    $_SESSION['user_id']   = $user['id'];
                    $_SESSION['user_name'] = $user['name'];
                    $_SESSION['user_email']= $user['email'];
                    $_SESSION['role']      = $user['role'];

                    // Log
                    if ($user['role'] === 'admin') {
                        logAdminAction('Admin logged in', 'users', $user['id'], 'Admin login from IP: ' . ($_SERVER['REMOTE_ADDR'] ?? ''));
                    }

                    $redirect = $user['role'] === 'admin' ? '../admin/dashboard.php' : '../user/dashboard.php';
                    header("Location: $redirect");
                    exit;
                }
            } else {
                $error = '❌ Invalid email or password.';
            }
        }
    }
}

$csrf = generateCSRF();
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login — CreditGuard</title>
<meta name="description" content="Sign in to your CreditGuard account to manage your credit cards.">
<link rel="stylesheet" href="../assets/css/style.css?v=<?= time() ?>">
</head>
<body>
<div class="auth-bg"></div>
<div id="particles" class="particles"></div>

<div class="auth-wrapper">
    <div class="auth-card">
        <div class="auth-logo">
            <div class="logo-icon">💳</div>
            <div>
                <h1 class="auth-title">Welcome Back</h1>
                <p class="auth-subtitle">Sign in to your CreditGuard account</p>
            </div>
        </div>

        <?php if ($error): ?>
        <div style="background:rgba(220,38,38,0.1);border:1px solid rgba(220,38,38,0.3);border-radius:12px;padding:12px 16px;margin-bottom:20px;font-size:0.88rem;color:#F87171;display:flex;align-items:center;gap:8px;">
            <?= $error ?>
        </div>
        <?php endif; ?>

        <form method="POST" id="login-form" autocomplete="off">
            <input type="hidden" name="csrf_token" value="<?= $csrf ?>">

            <div class="form-group">
                <label class="form-label" for="email">Email Address</label>
                <div class="input-group">
                    <input type="email" id="email" name="email" class="form-control"
                           placeholder="you@example.com" required
                           value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                    <span class="input-group-icon">📧</span>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="password">Password</label>
                <div class="input-group">
                    <input type="password" id="password" name="password" class="form-control"
                           placeholder="Enter your password" required>
                    <span class="input-group-icon toggle-password" title="Toggle password">👁️</span>
                </div>
            </div>

            <button type="submit" class="btn btn-primary btn-block" id="login-btn" style="margin-top:8px;">
                🔐 Sign In
            </button>
        </form>

        <div class="auth-divider">or</div>

        
        <p style="text-align:center;font-size:0.88rem;color:var(--text-muted);">
            Don't have an account? <a href="register.php" style="color:var(--primary-light);font-weight:600;">Register here</a>
        </p>
    </div>
</div>

<div id="toast-container"></div>
<script src="../assets/js/main.js"></script>
<script>
function fillDemo(email, pass) {
    document.getElementById('email').value = email;
    document.getElementById('password').value = pass;
}

document.getElementById('login-form').addEventListener('submit', function(e) {
    const btn = document.getElementById('login-btn');
    btn.innerHTML = '<span class="spinner"></span> Signing in...';
    btn.disabled = true;
});
</script>
</body>
</html>
