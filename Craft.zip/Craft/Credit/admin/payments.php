<?php
/**
 * Admin Payments Page
 */
require_once 'layout.php';

$payments = $pdo->query("
    SELECT p.*, u.name AS user_name, c.card_number
    FROM payments p JOIN users u ON p.user_id=u.id JOIN credit_cards c ON p.card_id=c.id
    ORDER BY p.payment_date DESC
")->fetchAll();

$totalPaid   = array_sum(array_map(fn($p) => $p['status']==='success' ? $p['amount'] : 0, $payments));
$totalCount  = count(array_filter($payments, fn($p) => $p['status']==='success'));
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Payments — Admin</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php renderAdminSidebar($user, $currentPage); ?>
<div class="main-wrapper">
<?php renderAdminTopbar($user, '💰 Payments'); ?>
<div class="content-area">

<div class="grid-3 mb-3">
    <div class="stat-card" style="--accent:var(--success);">
        <div class="stat-icon" style="background:rgba(16,185,129,0.15);">💰</div>
        <div class="stat-info">
            <div class="stat-label">Total Collected</div>
            <div class="stat-value" style="color:var(--success);"><?= formatCurrency($totalPaid) ?></div>
        </div>
    </div>
    <div class="stat-card" style="--accent:var(--primary);">
        <div class="stat-icon" style="background:rgba(37,99,235,0.15);">✅</div>
        <div class="stat-info">
            <div class="stat-label">Successful Payments</div>
            <div class="stat-value"><?= $totalCount ?></div>
        </div>
    </div>
    <div class="stat-card" style="--accent:var(--warning);">
        <div class="stat-icon" style="background:rgba(245,158,11,0.15);">📋</div>
        <div class="stat-info">
            <div class="stat-label">Total Records</div>
            <div class="stat-value"><?= count($payments) ?></div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header"><h3 class="card-title">💰 All Payments</h3></div>
    <div class="table-wrapper">
        <table>
            <thead>
                <tr><th>#</th><th>User</th><th>Reference</th><th>Amount</th><th>Method</th><th>Date</th><th>Status</th></tr>
            </thead>
            <tbody>
                <?php foreach($payments as $i=>$p): ?>
                <tr>
                    <td><?= $i+1 ?></td>
                    <td>
                        <div style="font-weight:600;"><?= htmlspecialchars($p['user_name']) ?></div>
                        <div style="font-size:0.75rem;color:var(--text-muted);font-family:monospace;"><?= formatMaskedCard($p['card_number']) ?></div>
                    </td>
                    <td style="font-family:monospace;font-size:0.8rem;"><?= htmlspecialchars($p['payment_reference']) ?></td>
                    <td style="font-weight:700;color:var(--success);">+<?= formatCurrency($p['amount']) ?></td>
                    <td><span class="badge badge-info" style="text-transform:capitalize;"><?= $p['payment_method'] ?></span></td>
                    <td style="font-size:0.82rem;color:var(--text-muted);"><?= date('d M Y, h:i A', strtotime($p['payment_date'])) ?></td>
                    <td><span class="badge <?= getStatusBadge($p['status']) ?>"><?= ucfirst($p['status']) ?></span></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

</div></div>
<div id="toast-container"></div>
<script src="../assets/js/main.js"></script>
</body>
</html>
