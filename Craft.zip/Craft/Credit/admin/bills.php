<?php
/**
 * Admin Bills Management
 */
require_once 'layout.php';

$bills = $pdo->query("
    SELECT b.*, u.name AS user_name, c.card_number 
    FROM bills b JOIN users u ON b.user_id=u.id JOIN credit_cards c ON b.card_id=c.id
    ORDER BY b.generated_at DESC
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Bills — Admin</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php renderAdminSidebar($user, $currentPage); ?>
<div class="main-wrapper">
<?php renderAdminTopbar($user, '🧾 Bills Management'); ?>
<div class="content-area">
<div class="card">
    <div class="card-header"><h3 class="card-title">All Bills</h3></div>
    <div class="table-wrapper">
        <table>
            <thead>
                <tr><th>#</th><th>User</th><th>Month</th><th>Total Due</th><th>Min Due</th><th>Due Date</th><th>Status</th></tr>
            </thead>
            <tbody>
                <?php foreach($bills as $i=>$b): ?>
                <tr>
                    <td><?= $i+1 ?></td>
                    <td>
                        <div style="font-weight:600;"><?= htmlspecialchars($b['user_name']) ?></div>
                        <div style="font-size:0.75rem;color:var(--text-muted);font-family:monospace;"><?= formatMaskedCard($b['card_number']) ?></div>
                    </td>
                    <td><?= date('F Y', mktime(0,0,0,$b['bill_month'],1,$b['bill_year'])) ?></td>
                    <td style="font-weight:700;color:var(--danger);"><?= formatCurrency($b['total_due']) ?></td>
                    <td><?= formatCurrency($b['minimum_due']) ?></td>
                    <td style="font-size:0.82rem;"><?= date('d M Y', strtotime($b['due_date'])) ?></td>
                    <td><span class="badge <?= getStatusBadge($b['status']) ?>"><?= ucfirst(str_replace('_',' ',$b['status'])) ?></span></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
</div></div>
<div id="toast-container"></div>
<script src="../assets/js/main.js"></script>
</body>
</html>
