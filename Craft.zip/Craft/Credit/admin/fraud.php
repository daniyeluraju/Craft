<?php
/**
 * Admin Fraud Alerts
 */
require_once 'layout.php';

$flagged = $pdo->query("
    SELECT t.*, u.name AS user_name, u.email AS user_email, c.card_number
    FROM transactions t
    JOIN users u ON t.user_id=u.id
    JOIN credit_cards c ON t.card_id=c.id
    WHERE t.status='flagged' OR t.is_suspicious=1
    ORDER BY t.transaction_date DESC
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Fraud Alerts — Admin</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php renderAdminSidebar($user, $currentPage); ?>
<div class="main-wrapper">
<?php renderAdminTopbar($user, '🚨 Fraud Alerts'); ?>
<div class="content-area">

<?php if (!empty($flagged)): ?>
<div style="background:rgba(220,38,38,0.1);border:1px solid rgba(220,38,38,0.3);border-radius:12px;padding:16px 20px;margin-bottom:24px;display:flex;align-items:center;gap:12px;">
    <span style="font-size:1.5rem;">🚨</span>
    <div>
        <div style="font-weight:700;color:var(--danger);"><?= count($flagged) ?> Suspicious Transaction<?= count($flagged)>1?'s':'' ?> Detected</div>
        <div style="font-size:0.85rem;color:var(--text-muted);">Review flagged transactions and take appropriate action.</div>
    </div>
    <a href="transactions.php?status=flagged" class="btn btn-danger btn-sm" style="margin-left:auto;">View in Monitor</a>
</div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <h3 class="card-title">🚨 Flagged Transactions</h3>
    </div>
    <?php if (!empty($flagged)): ?>
    <div class="table-wrapper">
        <table>
            <thead>
                <tr><th>#</th><th>User</th><th>Description</th><th>Amount</th><th>Date</th><th>Actions</th></tr>
            </thead>
            <tbody>
                <?php foreach($flagged as $i => $t): ?>
                <tr style="background:rgba(220,38,38,0.04);">
                    <td><?= $i+1 ?></td>
                    <td>
                        <div style="font-weight:600;"><?= htmlspecialchars($t['user_name']) ?></div>
                        <div style="font-size:0.75rem;color:var(--text-muted);"><?= htmlspecialchars($t['user_email']) ?></div>
                    </td>
                    <td>
                        <div><?= htmlspecialchars($t['description']) ?></div>
                        <div style="font-size:0.75rem;color:var(--text-muted);"><?= htmlspecialchars($t['reference_no']) ?></div>
                    </td>
                    <td style="font-weight:800;color:var(--danger);font-size:1rem;"><?= formatCurrency($t['amount']) ?></td>
                    <td style="font-size:0.82rem;color:var(--text-muted);"><?= date('d M Y, h:i A', strtotime($t['transaction_date'])) ?></td>
                    <td>
                        <a href="transactions.php?flag=<?= $t['id'] ?>" class="btn btn-success btn-sm"
                           onclick="return confirm('Mark as legitimate?')">✅ Clear</a>
                        <a href="users.php?toggle_status=<?= $t['user_id'] ?>" class="btn btn-danger btn-sm"
                           onclick="return confirm('Block this user?')">⛔ Block User</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
    <div class="card-body">
        <div class="empty-state">
            <div class="empty-icon">✅</div>
            <div class="empty-title">No Fraud Alerts</div>
            <div class="empty-desc">All transactions look normal. Great job!</div>
        </div>
    </div>
    <?php endif; ?>
</div>

</div></div>
<div id="toast-container"></div>
<script src="../assets/js/main.js"></script>
</body>
</html>
