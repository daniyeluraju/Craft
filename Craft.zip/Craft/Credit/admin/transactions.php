<?php
/**
 * Admin Transactions Monitor
 * Secure Credit Card Management System
 */
require_once 'layout.php';

// Flag/unflag transaction
if (isset($_GET['flag'])) {
    $id  = (int)$_GET['flag'];
    $row = $pdo->prepare("SELECT status FROM transactions WHERE id=?");
    $row->execute([$id]);
    $st  = $row->fetchColumn();
    $new = $st === 'flagged' ? 'success' : 'flagged';
    $isSusp = $new === 'flagged' ? 1 : 0;
    $pdo->prepare("UPDATE transactions SET status=?, is_suspicious=? WHERE id=?")->execute([$new, $isSusp, $id]);
    logAdminAction("Transaction $new", 'transactions', $id);
    header('Location: transactions.php');
    exit;
}

// Filters
$filterType   = $_GET['type'] ?? '';
$filterStatus = $_GET['status'] ?? '';
$filterUser   = $_GET['user'] ?? '';
$filterFrom   = $_GET['from'] ?? '';
$filterTo     = $_GET['to'] ?? '';
$page         = max(1, (int)($_GET['page'] ?? 1));
$perPage      = 20;
$offset       = ($page - 1) * $perPage;

$where  = ['1=1'];
$params = [];
if ($filterType)   { $where[] = "t.transaction_type=?"; $params[] = $filterType; }
if ($filterStatus) { $where[] = "t.status=?";           $params[] = $filterStatus; }
if ($filterUser)   { $where[] = "t.user_id=?";          $params[] = (int)$filterUser; }
if ($filterFrom)   { $where[] = "DATE(t.transaction_date)>=?"; $params[] = $filterFrom; }
if ($filterTo)     { $where[] = "DATE(t.transaction_date)<=?"; $params[] = $filterTo; }
$whereStr = implode(' AND ', $where);

$count = $pdo->prepare("SELECT COUNT(*) FROM transactions t WHERE $whereStr");
$count->execute($params);
$total = (int)$count->fetchColumn();
$pages = (int)ceil($total / $perPage);

$stmt = $pdo->prepare("
    SELECT t.*, u.name AS user_name, c.card_number 
    FROM transactions t 
    JOIN users u ON t.user_id=u.id 
    JOIN credit_cards c ON t.card_id=c.id
    WHERE $whereStr
    ORDER BY t.transaction_date DESC 
    LIMIT $perPage OFFSET $offset
");
$stmt->execute($params);
$txns = $stmt->fetchAll();

$allUsers = $pdo->query("SELECT id, name FROM users WHERE role='user' ORDER BY name")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Transactions — Admin</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php renderAdminSidebar($user, $currentPage); ?>
<div class="main-wrapper">
<?php renderAdminTopbar($user, '📋 Transaction Monitor'); ?>
<div class="content-area">

<!-- Filters -->
<div class="card mb-3">
    <div class="card-body">
        <form method="GET" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;align-items:end;">
            <div class="form-group" style="margin:0;">
                <label class="form-label">User</label>
                <select name="user" class="form-control">
                    <option value="">All Users</option>
                    <?php foreach($allUsers as $u2): ?>
                    <option value="<?= $u2['id'] ?>" <?= $filterUser==$u2['id']?'selected':'' ?>><?= htmlspecialchars($u2['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group" style="margin:0;">
                <label class="form-label">Type</label>
                <select name="type" class="form-control">
                    <option value="">All Types</option>
                    <?php foreach(['debit','credit','payment','refund'] as $t): ?>
                    <option value="<?= $t ?>" <?= $filterType===$t?'selected':'' ?>><?= ucfirst($t) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group" style="margin:0;">
                <label class="form-label">Status</label>
                <select name="status" class="form-control">
                    <option value="">All Status</option>
                    <?php foreach(['success','pending','failed','flagged'] as $s): ?>
                    <option value="<?= $s ?>" <?= $filterStatus===$s?'selected':'' ?>><?= ucfirst($s) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group" style="margin:0;">
                <label class="form-label">From</label>
                <input type="date" name="from" class="form-control" value="<?= htmlspecialchars($filterFrom) ?>">
            </div>
            <div class="form-group" style="margin:0;">
                <label class="form-label">To</label>
                <input type="date" name="to" class="form-control" value="<?= htmlspecialchars($filterTo) ?>">
            </div>
            <div style="display:flex;gap:8px;">
                <button type="submit" class="btn btn-primary" style="height:44px;">Filter</button>
                <a href="transactions.php" class="btn btn-ghost" style="height:44px;">Reset</a>
            </div>
        </form>
    </div>
</div>

<!-- Table -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">All Transactions</h3>
        <div style="display:flex;gap:10px;align-items:center;">
            <div class="search-bar">
                <span class="search-icon">🔍</span>
                <input type="text" id="table-search" placeholder="Search..." style="width:180px;">
            </div>
            <span style="font-size:0.82rem;color:var(--text-muted);"><?= $total ?> records</span>
        </div>
    </div>
    <div class="table-wrapper">
        <table id="main-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>User</th>
                    <th>Description</th>
                    <th>Type</th>
                    <th>Amount</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($txns as $i => $txn): ?>
                <tr style="<?= $txn['status']==='flagged' ? 'background:rgba(220,38,38,0.05);' : '' ?>">
                    <td style="color:var(--text-muted);font-size:0.8rem;"><?= $offset + $i + 1 ?></td>
                    <td>
                        <div style="font-weight:600;font-size:0.85rem;"><?= htmlspecialchars($txn['user_name']) ?></div>
                        <div style="font-size:0.72rem;color:var(--text-muted);font-family:monospace;"><?= formatMaskedCard($txn['card_number']) ?></div>
                    </td>
                    <td>
                        <div style="font-size:0.85rem;font-weight:500;"><?= htmlspecialchars($txn['description']) ?></div>
                        <div style="font-size:0.72rem;color:var(--text-muted);"><?= htmlspecialchars($txn['reference_no']) ?></div>
                    </td>
                    <td><span class="badge <?= in_array($txn['transaction_type'],['credit','payment','refund']) ? 'badge-success':'badge-danger' ?>"><?= ucfirst($txn['transaction_type']) ?></span></td>
                    <td>
                        <span style="font-weight:800;font-size:0.92rem;color:<?= $txn['status']==='flagged'?'var(--danger)':($txn['transaction_type']==='debit'?'var(--text)':'var(--success)') ?>;">
                            <?= $txn['transaction_type']==='debit'?'−':'+' ?><?= formatCurrency($txn['amount']) ?>
                        </span>
                    </td>
                    <td style="font-size:0.8rem;color:var(--text-muted);white-space:nowrap;">
                        <?= date('d M Y', strtotime($txn['transaction_date'])) ?><br>
                        <?= date('h:i A', strtotime($txn['transaction_date'])) ?>
                    </td>
                    <td>
                        <span class="badge <?= getStatusBadge($txn['status']) ?>">
                            <?= $txn['status']==='flagged'?'⚠️ ':'' ?><?= ucfirst($txn['status']) ?>
                        </span>
                    </td>
                    <td>
                        <a href="transactions.php?flag=<?= $txn['id'] ?>" class="btn btn-sm <?= $txn['status']==='flagged' ? 'btn-ghost' : 'btn-warning' ?>"
                           title="<?= $txn['status']==='flagged' ? 'Unflag' : 'Flag as suspicious' ?>"
                           onclick="return confirm('<?= $txn['status']==='flagged' ? 'Remove flag from' : 'Flag' ?> this transaction?')">
                            <?= $txn['status']==='flagged' ? '✅ Unflag' : '🚨 Flag' ?>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <?php if ($pages > 1): ?>
    <div class="card-footer" style="display:flex;justify-content:center;gap:6px;flex-wrap:wrap;">
        <?php for($p=1; $p<=$pages; $p++): ?>
        <a href="?page=<?= $p ?>&type=<?= urlencode($filterType) ?>&status=<?= urlencode($filterStatus) ?>&user=<?= $filterUser ?>&from=<?= urlencode($filterFrom) ?>&to=<?= urlencode($filterTo) ?>"
           class="btn btn-sm <?= $p===$page ? 'btn-primary' : 'btn-ghost' ?>"><?= $p ?></a>
        <?php endfor; ?>
    </div>
    <?php endif; ?>
</div>

</div></div>
<div id="toast-container"></div>
<script src="../assets/js/main.js"></script>
</body>
</html>
