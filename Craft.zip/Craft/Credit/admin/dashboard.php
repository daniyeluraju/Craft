<?php
/**
 * Admin Dashboard
 * Secure Credit Card Management System
 */
require_once 'layout.php';

$stats       = getAdminStats();
$revenueData = getAdminMonthlyRevenue(6);

// Recent transactions
$recentTxns = $pdo->query("
    SELECT t.*, u.name AS user_name, c.card_number 
    FROM transactions t 
    JOIN users u ON t.user_id=u.id 
    JOIN credit_cards c ON t.card_id=c.id 
    ORDER BY t.transaction_date DESC LIMIT 8
")->fetchAll();

// Recent users
$recentUsers = $pdo->query("
    SELECT * FROM users WHERE role='user' ORDER BY created_at DESC LIMIT 5
")->fetchAll();

// Spending by category (all users)
$catData = $pdo->query("
    SELECT category, SUM(amount) as total FROM transactions 
    WHERE transaction_type='debit' AND status!='failed'
    AND transaction_date >= DATE_SUB(NOW(), INTERVAL 3 MONTH)
    GROUP BY category ORDER BY total DESC LIMIT 7
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard — CreditGuard</title>
<link rel="stylesheet" href="../assets/css/style.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
</head>
<body>
<?php renderAdminSidebar($user, $currentPage); ?>
<div class="main-wrapper">
<?php renderAdminTopbar($user, '📊 Admin Dashboard'); ?>
<div class="content-area">

<!-- Welcome -->
<div class="card mb-3" style="background:linear-gradient(135deg,rgba(220,38,38,0.15),rgba(245,158,11,0.08));border-color:rgba(220,38,38,0.25);padding:24px;">
    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:16px;">
        <div>
            <h2 style="margin-bottom:4px;">Welcome back, <?= htmlspecialchars(explode(' ',$user['name'])[0]) ?>! 👨‍💼</h2>
            <p style="color:var(--text-muted);font-size:0.88rem;">Here's your system overview for <?= date('d F Y') ?></p>
        </div>
        <div style="display:flex;gap:10px;flex-wrap:wrap;">
            <a href="users.php?action=add" class="btn btn-primary btn-sm">➕ Add User</a>
            <a href="cards.php?action=add" class="btn btn-ghost btn-sm">💳 Assign Card</a>
            <a href="reports.php" class="btn btn-ghost btn-sm">📈 Reports</a>
        </div>
    </div>
</div>

<!-- Stats Row 1 -->
<div class="grid-4 mb-3">
    <div class="stat-card" style="--accent:var(--primary);">
        <div class="stat-icon" style="background:rgba(37,99,235,0.15);">👥</div>
        <div class="stat-info">
            <div class="stat-label">Total Users</div>
            <div class="stat-value" data-counter="<?= $stats['total_users'] ?>"><?= $stats['total_users'] ?></div>
            <div class="stat-change stat-up">↑ <?= $stats['active_users'] ?> Active</div>
        </div>
    </div>
    <div class="stat-card" style="--accent:var(--success);">
        <div class="stat-icon" style="background:rgba(16,185,129,0.15);">💳</div>
        <div class="stat-info">
            <div class="stat-label">Active Cards</div>
            <div class="stat-value" data-counter="<?= $stats['active_cards'] ?>"><?= $stats['active_cards'] ?></div>
            <div class="stat-change">of <?= $stats['total_cards'] ?> total</div>
        </div>
    </div>
    <div class="stat-card" style="--accent:var(--warning);">
        <div class="stat-icon" style="background:rgba(245,158,11,0.15);">💰</div>
        <div class="stat-info">
            <div class="stat-label">Total Revenue</div>
            <div class="stat-value" data-counter="<?= $stats['total_revenue'] ?>" data-prefix="₹"><?= formatCurrency($stats['total_revenue']) ?></div>
            <div class="stat-change stat-up">All time payments</div>
        </div>
    </div>
    <div class="stat-card" style="--accent:var(--danger);">
        <div class="stat-icon" style="background:rgba(220,38,38,0.15);">🚨</div>
        <div class="stat-info">
            <div class="stat-label">Fraud Alerts</div>
            <div class="stat-value" style="color:var(--danger);" data-counter="<?= $stats['suspicious_transactions'] ?>"><?= $stats['suspicious_transactions'] ?></div>
            <div class="stat-change stat-down">Needs review</div>
        </div>
    </div>
</div>

<!-- Stats Row 2 -->
<div class="grid-4 mb-3">
    <div class="stat-card" style="--accent:var(--info);">
        <div class="stat-icon" style="background:rgba(6,182,212,0.15);">📋</div>
        <div class="stat-info">
            <div class="stat-label">Transactions</div>
            <div class="stat-value" data-counter="<?= $stats['total_transactions'] ?>"><?= $stats['total_transactions'] ?></div>
        </div>
    </div>
    <div class="stat-card" style="--accent:#F97316;">
        <div class="stat-icon" style="background:rgba(249,115,22,0.15);">📝</div>
        <div class="stat-info">
            <div class="stat-label">Open Complaints</div>
            <div class="stat-value" data-counter="<?= $stats['open_complaints'] ?>"><?= $stats['open_complaints'] ?></div>
        </div>
    </div>
    <div class="stat-card" style="--accent:#7C3AED;">
        <div class="stat-icon" style="background:rgba(124,58,237,0.15);">⛔</div>
        <div class="stat-info">
            <div class="stat-label">Blocked Users</div>
            <div class="stat-value" data-counter="<?= $stats['blocked_users'] ?>"><?= $stats['blocked_users'] ?></div>
        </div>
    </div>
    <div class="stat-card" style="--accent:var(--danger);">
        <div class="stat-icon" style="background:rgba(220,38,38,0.15);">🧾</div>
        <div class="stat-info">
            <div class="stat-label">Total Outstanding</div>
            <div class="stat-value" style="font-size:1.1rem;" data-counter="<?= $stats['total_outstanding'] ?>" data-prefix="₹"><?= formatCurrency($stats['total_outstanding']) ?></div>
        </div>
    </div>
</div>

<!-- Charts Row -->
<div class="grid-2 mb-3">
    <!-- Revenue Chart -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">📈 Monthly Revenue</h3>
            <span style="font-size:0.8rem;color:var(--text-muted);">Last 6 months</span>
        </div>
        <div class="card-body">
            <canvas id="revenueChart" style="max-height:250px;"></canvas>
        </div>
    </div>

    <!-- Category Pie -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">📊 Spending Categories</h3>
            <span style="font-size:0.8rem;color:var(--text-muted);">All users · Last 3 months</span>
        </div>
        <div class="card-body" style="display:flex;gap:20px;align-items:center;flex-wrap:wrap;">
            <canvas id="adminCatChart" style="max-height:220px;max-width:220px;flex-shrink:0;"></canvas>
            <div style="flex:1;min-width:150px;">
                <?php foreach(array_slice($catData,0,6) as $c): ?>
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;font-size:0.82rem;">
                    <span style="text-transform:capitalize;"><?= getCategoryIcon($c['category']) ?> <?= $c['category'] ?></span>
                    <span style="font-weight:700;">₹<?= number_format($c['total']) ?></span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<!-- Recent Transactions + Recent Users -->
<div class="grid-2">
    <!-- Recent Transactions -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">🔔 Recent Transactions</h3>
            <a href="transactions.php" class="btn btn-ghost btn-sm">View All →</a>
        </div>
        <div style="max-height:400px;overflow-y:auto;">
            <?php foreach($recentTxns as $txn): ?>
            <div style="display:flex;align-items:center;gap:12px;padding:12px 20px;border-bottom:1px solid var(--border);transition:background 0.15s;" onmouseover="this.style.background='var(--glass)'" onmouseout="this.style.background=''">
                <div style="width:36px;height:36px;border-radius:10px;background:<?= $txn['transaction_type']==='debit' ? 'rgba(220,38,38,0.1)' : 'rgba(16,185,129,0.1)' ?>;display:flex;align-items:center;justify-content:center;font-size:1rem;flex-shrink:0;">
                    <?= getCategoryIcon($txn['category']) ?>
                </div>
                <div style="flex:1;min-width:0;">
                    <div style="font-weight:600;font-size:0.85rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= htmlspecialchars($txn['description']) ?></div>
                    <div style="font-size:0.75rem;color:var(--text-muted);"><?= htmlspecialchars($txn['user_name']) ?> · <?= timeAgo($txn['transaction_date']) ?></div>
                </div>
                <div style="text-align:right;flex-shrink:0;">
                    <div style="font-weight:700;font-size:0.88rem;color:<?= $txn['status']==='flagged' ? 'var(--danger)' : ($txn['transaction_type']==='debit' ? 'var(--text)' : 'var(--success)') ?>;">
                        <?= $txn['transaction_type']==='debit' ? '−' : '+' ?><?= formatCurrency($txn['amount']) ?>
                    </div>
                    <span class="badge <?= getStatusBadge($txn['status']) ?>" style="font-size:0.68rem;"><?= $txn['status'] ?></span>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Recent Users -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">👥 Recent Users</h3>
            <a href="users.php" class="btn btn-ghost btn-sm">Manage →</a>
        </div>
        <div>
            <?php foreach($recentUsers as $u): ?>
            <div style="display:flex;align-items:center;gap:12px;padding:14px 20px;border-bottom:1px solid var(--border);">
                <div style="width:38px;height:38px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--info));display:flex;align-items:center;justify-content:center;font-weight:700;color:white;font-size:0.9rem;flex-shrink:0;">
                    <?= strtoupper(substr($u['name'],0,1)) ?>
                </div>
                <div style="flex:1;min-width:0;">
                    <div style="font-weight:600;font-size:0.88rem;"><?= htmlspecialchars($u['name']) ?></div>
                    <div style="font-size:0.75rem;color:var(--text-muted);"><?= htmlspecialchars($u['email']) ?></div>
                </div>
                <div style="display:flex;align-items:center;gap:8px;">
                    <span class="badge <?= getStatusBadge($u['status']) ?>"><?= ucfirst($u['status']) ?></span>
                    <a href="users.php?edit=<?= $u['id'] ?>" class="btn btn-ghost btn-sm">✏️</a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="card-footer">
            <a href="users.php?action=add" class="btn btn-primary btn-sm">➕ Add New User</a>
        </div>
    </div>
</div>

</div></div>
<div id="toast-container"></div>
<script src="../assets/js/main.js"></script>
<script>
// Revenue chart
<?php if (!empty($revenueData)): ?>
const revCtx = document.getElementById('revenueChart');
if (revCtx) {
    const g = revCtx.getContext('2d');
    const grad = g.createLinearGradient(0,0,0,250);
    grad.addColorStop(0,'rgba(16,185,129,0.3)');
    grad.addColorStop(1,'rgba(16,185,129,0)');

    new Chart(revCtx, {
        type: 'bar',
        data: {
            labels: <?= json_encode(array_column($revenueData,'label')) ?>,
            datasets: [{
                label: 'Revenue',
                data: <?= json_encode(array_map(fn($r) => round((float)$r['revenue']), $revenueData)) ?>,
                backgroundColor: 'rgba(16,185,129,0.6)',
                borderColor: '#10B981',
                borderWidth: 2,
                borderRadius: 8,
                borderSkipped: false,
            }]
        },
        options: {
            responsive: true, maintainAspectRatio: true,
            plugins: {
                legend: { display: false },
                tooltip: { callbacks: { label: ctx => '₹' + ctx.raw.toLocaleString('en-IN') }}
            },
            scales: {
                x: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#94A3B8' }},
                y: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#94A3B8', callback: v => '₹' + v.toLocaleString('en-IN') }}
            }
        }
    });
}
<?php endif; ?>

// Category pie
<?php if (!empty($catData)): ?>
const catCtx2 = document.getElementById('adminCatChart');
if (catCtx2) {
    new Chart(catCtx2, {
        type: 'doughnut',
        data: {
            labels: <?= json_encode(array_column(array_slice($catData,0,7),'category')) ?>,
            datasets: [{
                data: <?= json_encode(array_map(fn($c) => round((float)$c['total']), array_slice($catData,0,7))) ?>,
                backgroundColor: ['#2563EB','#10B981','#F59E0B','#7C3AED','#DC2626','#06B6D4','#F97316'],
                borderWidth: 0,
                hoverOffset: 6
            }]
        },
        options: {
            responsive: true,
            cutout: '70%',
            plugins: {
                legend: { display: false },
                tooltip: { callbacks: { label: ctx => '₹' + ctx.raw.toLocaleString('en-IN') }}
            }
        }
    });
}
<?php endif; ?>
</script>
</body>
</html>
