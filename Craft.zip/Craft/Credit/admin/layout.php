<?php
/**
 * Admin Layout Helper
 * Secure Credit Card Management System
 */
require_once '../includes/auth.php';
require_once '../includes/functions.php';
requireAdmin();

$user  = getCurrentUser();
if (!$user) { session_destroy(); header('Location: ../public/login.php'); exit; }

$notifCount  = getUnreadNotificationCount($user['id']);
$currentPage = basename($_SERVER['PHP_SELF']);

function renderAdminSidebar(array $user, string $currentPage): void {
    // Pending complaints count
    global $pdo;
    $openComplaints = (int)$pdo->query("SELECT COUNT(*) FROM complaints WHERE status='open'")->fetchColumn();
    $pendingUsers   = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE status='pending'")->fetchColumn();
    $contactMsgs    = (int)$pdo->query("SELECT COUNT(*) FROM contact_messages WHERE is_read=0")->fetchColumn();
?>
<div class="sidebar-overlay"></div>
<aside class="sidebar">
    <div class="sidebar-header">
        <a href="dashboard.php" class="sidebar-brand">
            <div class="logo-icon">💳</div>
            <span>CreditGuard</span>
        </a>
    </div>
    <div class="sidebar-user">
        <div class="sidebar-avatar" style="background:linear-gradient(135deg,#DC2626,#EF4444);">
            <?= strtoupper(substr($user['name'], 0, 1)) ?>
        </div>
        <div class="sidebar-user-info">
            <div class="name"><?= htmlspecialchars(explode(' ',$user['name'])[0]) ?></div>
            <div class="role" style="color:var(--danger);">⚡ Administrator</div>
        </div>
    </div>

    <nav class="sidebar-nav">
        <div class="nav-section-title">Overview</div>
        <a href="dashboard.php" class="<?= $currentPage==='dashboard.php'?'active':'' ?>">
            <span class="nav-icon">📊</span> Dashboard
        </a>

        <div class="nav-section-title">User Management</div>
        <a href="users.php" class="<?= $currentPage==='users.php'?'active':'' ?>">
            <span class="nav-icon">👥</span> Manage Users
            <?php if ($pendingUsers): ?><span class="badge-count"><?= $pendingUsers ?></span><?php endif; ?>
        </a>
        <a href="cards.php" class="<?= $currentPage==='cards.php'?'active':'' ?>">
            <span class="nav-icon">💳</span> Credit Cards
        </a>

        <div class="nav-section-title">Transactions</div>
        <a href="transactions.php" class="<?= $currentPage==='transactions.php'?'active':'' ?>">
            <span class="nav-icon">📋</span> All Transactions
        </a>
        <a href="fraud.php" class="<?= $currentPage==='fraud.php'?'active':'' ?>">
            <span class="nav-icon">🚨</span> Fraud Alerts
            <?php
            $flagged = (int)$pdo->query("SELECT COUNT(*) FROM transactions WHERE status='flagged'")->fetchColumn();
            if ($flagged): ?><span class="badge-count"><?= $flagged ?></span><?php endif; ?>
        </a>

        <div class="nav-section-title">Finance</div>
        <a href="bills.php" class="<?= $currentPage==='bills.php'?'active':'' ?>">
            <span class="nav-icon">🧾</span> Bills
        </a>
        <a href="payments.php" class="<?= $currentPage==='payments.php'?'active':'' ?>">
            <span class="nav-icon">💰</span> Payments
        </a>
        <a href="reports.php" class="<?= $currentPage==='reports.php'?'active':'' ?>">
            <span class="nav-icon">📈</span> Reports & Analytics
        </a>

        <div class="nav-section-title">Support</div>
        <a href="complaints.php" class="<?= $currentPage==='complaints.php'?'active':'' ?>">
            <span class="nav-icon">📝</span> Complaints
            <?php if ($openComplaints): ?><span class="badge-count"><?= $openComplaints ?></span><?php endif; ?>
        </a>
        <a href="messages.php" class="<?= $currentPage==='messages.php'?'active':'' ?>">
            <span class="nav-icon">📩</span> Contact Messages
            <?php if ($contactMsgs): ?><span class="badge-count"><?= $contactMsgs ?></span><?php endif; ?>
        </a>
        <a href="logs.php" class="<?= $currentPage==='logs.php'?'active':'' ?>">
            <span class="nav-icon">📋</span> Audit Logs
        </a>
    </nav>

    <div class="sidebar-footer">
        <a href="../logout.php" class="btn btn-ghost btn-sm btn-block" style="color:var(--danger);">
            🚪 Logout
        </a>
    </div>
</aside>
<?php }

function renderAdminTopbar(array $user, string $pageTitle): void { ?>
<div class="topbar">
    <div class="topbar-left">
        <button class="hamburger">☰</button>
        <span class="page-title"><?= htmlspecialchars($pageTitle) ?></span>
    </div>
    <div class="topbar-right">
        <button class="theme-toggle"><span class="theme-icon">☀️</span></button>
        <div style="display:flex;align-items:center;gap:8px;background:rgba(220,38,38,0.1);border:1px solid rgba(220,38,38,0.3);border-radius:12px;padding:6px 12px;">
            <div style="width:28px;height:28px;border-radius:50%;background:linear-gradient(135deg,#DC2626,#EF4444);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:0.8rem;color:white;">
                <?= strtoupper(substr($user['name'],0,1)) ?>
            </div>
            <span style="font-size:0.85rem;font-weight:600;color:var(--danger);">Admin</span>
        </div>
        <a href="../public/index.php" class="btn btn-ghost btn-sm" target="_blank">🌐 View Site</a>
    </div>
</div>
<?php }
