<?php
/**
 * Admin Complaints Management
 * Secure Credit Card Management System
 */
require_once 'layout.php';

$msg = '';

// Reply/Update complaint
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['resolve'])) {
    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
        $msg = ['type'=>'error','text'=>'Invalid request.'];
    } else {
        $id     = (int)$_POST['complaint_id'];
        $reply  = sanitize($_POST['admin_reply'] ?? '');
        $status = in_array($_POST['status']??'', ['open','in_progress','resolved','closed']) ? $_POST['status'] : 'in_progress';
        $resolvedAt = $status === 'resolved' ? date('Y-m-d H:i:s') : null;

        $pdo->prepare("UPDATE complaints SET admin_reply=?, status=?, resolved_at=?, updated_at=NOW() WHERE id=?")
            ->execute([$reply, $status, $resolvedAt, $id]);
        logAdminAction("Complaint $status", 'complaints', $id);

        // Notify user
        $comp = $pdo->prepare("SELECT user_id, subject FROM complaints WHERE id=?");
        $comp->execute([$id]);
        $compRow = $comp->fetch();
        if ($compRow) {
            createNotification($compRow['user_id'], "📝 Complaint Update", "Your complaint '{$compRow['subject']}' status changed to $status.", 'info');
        }
        $msg = ['type'=>'success','text'=>'✅ Complaint updated successfully.'];
    }
}

// Get complaints with user info
$statusFilter = $_GET['status'] ?? '';
$where  = ['1=1'];
$params = [];
if ($statusFilter) { $where[] = "c.status=?"; $params[] = $statusFilter; }
$whereStr = implode(' AND ', $where);

$stmt = $pdo->prepare("
    SELECT c.*, u.name AS user_name, u.email AS user_email
    FROM complaints c JOIN users u ON c.user_id=u.id
    WHERE $whereStr
    ORDER BY c.created_at DESC
");
$stmt->execute($params);
$complaints = $stmt->fetchAll();

$csrf = generateCSRF();
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Complaints — Admin</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php renderAdminSidebar($user, $currentPage); ?>
<div class="main-wrapper">
<?php renderAdminTopbar($user, '📝 Complaint Management'); ?>
<div class="content-area">

<?php if ($msg): ?>
<div style="background:<?= $msg['type']==='success'?'rgba(16,185,129,0.1)':'rgba(220,38,38,0.1)' ?>;border:1px solid <?= $msg['type']==='success'?'rgba(16,185,129,0.3)':'rgba(220,38,38,0.3)' ?>;border-radius:12px;padding:12px 16px;margin-bottom:20px;color:<?= $msg['type']==='success'?'#34D399':'#F87171' ?>;">
    <?= $msg['text'] ?>
</div>
<?php endif; ?>

<!-- Filters -->
<div class="card mb-3">
    <div class="card-body" style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
        <span style="color:var(--text-muted);font-size:0.88rem;">Filter by status:</span>
        <?php foreach(['','open','in_progress','resolved','closed'] as $s): ?>
        <a href="?<?= $s ? "status=$s" : '' ?>" class="btn btn-sm <?= $statusFilter===$s ? 'btn-primary' : 'btn-ghost' ?>">
            <?= $s ? ucfirst(str_replace('_',' ',$s)) : 'All' ?>
            <?php if ($s): ?>
            <span style="margin-left:4px;opacity:0.7;"><?= count(array_filter($complaints,fn($c)=>$c['status']===$s)) ?></span>
            <?php endif; ?>
        </a>
        <?php endforeach; ?>
    </div>
</div>

<!-- Complaints List -->
<?php if (!empty($complaints)): ?>
<div style="display:grid;gap:16px;">
    <?php foreach($complaints as $c):
        $statusColors = ['open'=>'var(--warning)','in_progress'=>'var(--info)','resolved'=>'var(--success)','closed'=>'var(--text-muted)'];
    ?>
    <div class="card">
        <div class="card-body">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:16px;flex-wrap:wrap;margin-bottom:16px;">
                <!-- User info -->
                <div style="display:flex;align-items:center;gap:12px;">
                    <div style="width:40px;height:40px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--info));display:flex;align-items:center;justify-content:center;font-weight:700;color:white;flex-shrink:0;">
                        <?= strtoupper(substr($c['user_name'],0,1)) ?>
                    </div>
                    <div>
                        <div style="font-weight:700;"><?= htmlspecialchars($c['user_name']) ?></div>
                        <div style="font-size:0.78rem;color:var(--text-muted);"><?= htmlspecialchars($c['user_email']) ?></div>
                    </div>
                </div>
                <div style="display:flex;align-items:center;gap:10px;">
                    <span class="badge badge-secondary"><?= $c['category'] ?></span>
                    <span class="badge <?= getStatusBadge($c['status']) ?>"><?= ucfirst(str_replace('_',' ',$c['status'])) ?></span>
                    <span style="font-size:0.78rem;color:var(--text-muted);"><?= timeAgo($c['created_at']) ?></span>
                </div>
            </div>

            <h4 style="font-size:1rem;margin-bottom:8px;"><?= htmlspecialchars($c['subject']) ?></h4>
            <p style="font-size:0.88rem;color:var(--text-muted);line-height:1.6;margin-bottom:16px;"><?= nl2br(htmlspecialchars($c['message'])) ?></p>

            <?php if ($c['admin_reply']): ?>
            <div style="background:rgba(16,185,129,0.08);border:1px solid rgba(16,185,129,0.2);border-radius:10px;padding:12px 16px;margin-bottom:16px;">
                <p style="font-size:0.78rem;color:var(--success);font-weight:600;margin-bottom:6px;">💬 Admin Response:</p>
                <p style="font-size:0.85rem;color:var(--text-muted);"><?= nl2br(htmlspecialchars($c['admin_reply'])) ?></p>
            </div>
            <?php endif; ?>

            <!-- Reply Form -->
            <?php if ($c['status'] !== 'closed'): ?>
            <details style="border-top:1px solid var(--border);padding-top:16px;">
                <summary style="cursor:pointer;font-size:0.88rem;font-weight:600;color:var(--primary-light);list-style:none;">
                    ✏️ <?= $c['admin_reply'] ? 'Update Response' : 'Reply to Complaint' ?> ▾
                </summary>
                <div style="margin-top:16px;">
                    <form method="POST">
                        <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
                        <input type="hidden" name="resolve" value="1">
                        <input type="hidden" name="complaint_id" value="<?= $c['id'] ?>">
                        <div class="form-group">
                            <label class="form-label">Your Response</label>
                            <textarea name="admin_reply" class="form-control" rows="3" required><?= htmlspecialchars($c['admin_reply'] ?? '') ?></textarea>
                        </div>
                        <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
                            <select name="status" class="form-control" style="width:auto;">
                                <?php foreach(['open','in_progress','resolved','closed'] as $s): ?>
                                <option value="<?= $s ?>" <?= $c['status']===$s?'selected':'' ?>><?= ucfirst(str_replace('_',' ',$s)) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <button type="submit" class="btn btn-primary btn-sm">💬 Submit Response</button>
                        </div>
                    </form>
                </div>
            </details>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php else: ?>
<div class="card">
    <div class="card-body">
        <div class="empty-state">
            <div class="empty-icon">📝</div>
            <div class="empty-title">No complaints</div>
            <div class="empty-desc"><?= $statusFilter ? "No $statusFilter complaints." : 'All clear!' ?></div>
        </div>
    </div>
</div>
<?php endif; ?>

</div></div>
<div id="toast-container"></div>
<script src="../assets/js/main.js"></script>
</body>
</html>
