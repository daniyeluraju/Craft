<?php
/**
 * Admin Audit Logs
 * Secure Credit Card Management System
 */
require_once 'layout.php';

$page    = max(1, (int)($_GET['page'] ?? 1));
$perPage = 30;
$offset  = ($page - 1) * $perPage;

$total = (int)$pdo->query("SELECT COUNT(*) FROM admin_logs")->fetchColumn();
$pages = (int)ceil($total / $perPage);

$logs = $pdo->prepare("
    SELECT l.*, u.name AS admin_name 
    FROM admin_logs l JOIN users u ON l.admin_id=u.id 
    ORDER BY l.created_at DESC 
    LIMIT $perPage OFFSET $offset
");
$logs->execute();
$logs = $logs->fetchAll();
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Audit Logs — Admin</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php renderAdminSidebar($user, $currentPage); ?>
<div class="main-wrapper">
<?php renderAdminTopbar($user, '📋 Audit Logs'); ?>
<div class="content-area">

<div class="card">
    <div class="card-header">
        <h3 class="card-title">📋 Admin Activity Log</h3>
        <span style="font-size:0.82rem;color:var(--text-muted);"><?= $total ?> entries</span>
    </div>
    <div class="table-wrapper">
        <table id="main-table">
            <thead>
                <tr><th>#</th><th>Admin</th><th>Action</th><th>Table</th><th>Details</th><th>IP</th><th>Time</th></tr>
            </thead>
            <tbody>
                <?php foreach($logs as $i => $log): ?>
                <tr>
                    <td style="color:var(--text-muted);font-size:0.8rem;"><?= $offset+$i+1 ?></td>
                    <td style="font-weight:600;font-size:0.85rem;"><?= htmlspecialchars($log['admin_name']) ?></td>
                    <td style="font-size:0.85rem;"><?= htmlspecialchars($log['action']) ?></td>
                    <td><span class="badge badge-secondary" style="font-size:0.68rem;"><?= $log['target_table'] ?? '—' ?></span></td>
                    <td style="font-size:0.8rem;color:var(--text-muted);max-width:250px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= htmlspecialchars($log['details'] ?? '—') ?></td>
                    <td style="font-size:0.8rem;font-family:monospace;"><?= htmlspecialchars($log['ip_address'] ?? '—') ?></td>
                    <td style="font-size:0.8rem;color:var(--text-muted);white-space:nowrap;"><?= date('d M Y, h:i A', strtotime($log['created_at'])) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php if ($pages > 1): ?>
    <div class="card-footer" style="display:flex;justify-content:center;gap:6px;flex-wrap:wrap;">
        <?php for($p=1;$p<=$pages;$p++): ?>
        <a href="?page=<?= $p ?>" class="btn btn-sm <?= $p===$page?'btn-primary':'btn-ghost' ?>"><?= $p ?></a>
        <?php endfor; ?>
    </div>
    <?php endif; ?>
</div>

</div></div>
<div id="toast-container"></div>
<script src="../assets/js/main.js"></script>
</body>
</html>
