<?php
/**
 * Admin Messages & Audit Logs pages
 * Secure Credit Card Management System
 */
require_once 'layout.php';

$msgs = $pdo->query("SELECT * FROM contact_messages ORDER BY created_at DESC")->fetchAll();
// Mark all as read
if (isset($_GET['markread'])) {
    $pdo->exec("UPDATE contact_messages SET is_read=1");
    header('Location: messages.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Contact Messages — Admin</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php renderAdminSidebar($user, $currentPage); ?>
<div class="main-wrapper">
<?php renderAdminTopbar($user, '📩 Contact Messages'); ?>
<div class="content-area">

<div class="card">
    <div class="card-header">
        <h3 class="card-title">Contact Messages</h3>
        <a href="?markread=1" class="btn btn-ghost btn-sm">✅ Mark All Read</a>
    </div>
    <?php if (!empty($msgs)): ?>
    <div>
        <?php foreach($msgs as $m): ?>
        <div style="padding:20px 24px;border-bottom:1px solid var(--border);<?= !$m['is_read']?'background:rgba(37,99,235,0.04);':'' ?>">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:10px;margin-bottom:10px;">
                <div style="display:flex;align-items:center;gap:10px;">
                    <?php if (!$m['is_read']): ?><span style="width:8px;height:8px;background:var(--primary);border-radius:50%;flex-shrink:0;"></span><?php endif; ?>
                    <span style="font-weight:700;"><?= htmlspecialchars($m['name']) ?></span>
                    <span style="font-size:0.8rem;color:var(--text-muted);"><?= htmlspecialchars($m['email']) ?></span>
                </div>
                <span style="font-size:0.78rem;color:var(--text-muted);"><?= timeAgo($m['created_at']) ?></span>
            </div>
            <p style="font-weight:600;margin-bottom:6px;"><?= htmlspecialchars($m['subject']) ?></p>
            <p style="font-size:0.85rem;color:var(--text-muted);"><?= htmlspecialchars($m['message']) ?></p>
        </div>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div class="card-body"><div class="empty-state"><div class="empty-icon">📩</div><div class="empty-title">No messages</div></div></div>
    <?php endif; ?>
</div>

</div></div>
<div id="toast-container"></div>
<script src="../assets/js/main.js"></script>
</body>
</html>
