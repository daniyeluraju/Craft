<?php
/**
 * Admin Reports & Analytics
 * Secure Credit Card Management System
 */
require_once 'layout.php';

// Get analytics data
$monthlyRevenue = getAdminMonthlyRevenue(12);
$spendByCategory = $pdo->query("
    SELECT category, SUM(amount) as total, COUNT(*) as count
    FROM transactions WHERE transaction_type='debit' AND status!='failed'
    GROUP BY category ORDER BY total DESC
")->fetchAll();

// User growth
$userGrowth = $pdo->query("
    SELECT DATE_FORMAT(created_at,'%b %Y') as label, COUNT(*) as count
    FROM users WHERE role='user'
    GROUP BY YEAR(created_at), MONTH(created_at)
    ORDER BY created_at ASC LIMIT 12
")->fetchAll();

// Top spenders
$topSpenders = $pdo->query("
    SELECT u.name, u.email, SUM(t.amount) as total_spent, COUNT(*) as txn_count
    FROM transactions t JOIN users u ON t.user_id=u.id
    WHERE t.transaction_type='debit' AND t.status!='failed'
    GROUP BY t.user_id ORDER BY total_spent DESC LIMIT 5
")->fetchAll();

// Monthly transaction counts
$txnTrend = $pdo->query("
    SELECT 
        DATE_FORMAT(transaction_date,'%b %Y') as label,
        COUNT(*) as total,
        SUM(CASE WHEN transaction_type='debit' THEN amount ELSE 0 END) as debit_sum,
        SUM(CASE WHEN transaction_type='payment' THEN amount ELSE 0 END) as payment_sum,
        SUM(CASE WHEN status='flagged' THEN 1 ELSE 0 END) as flagged_count
    FROM transactions
    GROUP BY YEAR(transaction_date), MONTH(transaction_date)
    ORDER BY transaction_date ASC LIMIT 12
")->fetchAll();

$stats = getAdminStats();
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Reports & Analytics — Admin</title>
<link rel="stylesheet" href="../assets/css/style.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
</head>
<body>
<?php renderAdminSidebar($user, $currentPage); ?>
<div class="main-wrapper">
<?php renderAdminTopbar($user, '📈 Reports & Analytics'); ?>
<div class="content-area">

<!-- KPI Cards -->
<div class="grid-4 mb-3">
    <div class="stat-card" style="--accent:var(--primary);">
        <div class="stat-icon" style="background:rgba(37,99,235,0.15);">💰</div>
        <div class="stat-info">
            <div class="stat-label">Total Revenue</div>
            <div class="stat-value" data-counter="<?= $stats['total_revenue'] ?>" data-prefix="₹"><?= formatCurrency($stats['total_revenue']) ?></div>
        </div>
    </div>
    <div class="stat-card" style="--accent:var(--danger);">
        <div class="stat-icon" style="background:rgba(220,38,38,0.15);">🧾</div>
        <div class="stat-info">
            <div class="stat-label">Outstanding Dues</div>
            <div class="stat-value" style="color:var(--danger);" data-counter="<?= $stats['total_outstanding'] ?>" data-prefix="₹"><?= formatCurrency($stats['total_outstanding']) ?></div>
        </div>
    </div>
    <div class="stat-card" style="--accent:var(--warning);">
        <div class="stat-icon" style="background:rgba(245,158,11,0.15);">📋</div>
        <div class="stat-info">
            <div class="stat-label">Total Transactions</div>
            <div class="stat-value" data-counter="<?= $stats['total_transactions'] ?>"><?= $stats['total_transactions'] ?></div>
        </div>
    </div>
    <div class="stat-card" style="--accent:var(--danger);">
        <div class="stat-icon" style="background:rgba(220,38,38,0.15);">🚨</div>
        <div class="stat-info">
            <div class="stat-label">Fraud Alerts</div>
            <div class="stat-value" style="color:var(--danger);" data-counter="<?= $stats['suspicious_transactions'] ?>"><?= $stats['suspicious_transactions'] ?></div>
        </div>
    </div>
</div>

<!-- Revenue + Transaction Trend Charts -->
<div class="grid-2 mb-3">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">💰 Revenue Trend (12 Months)</h3>
        </div>
        <div class="card-body">
            <canvas id="revenueChart12" style="max-height:280px;"></canvas>
        </div>
    </div>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">📊 Spending vs Payments</h3>
        </div>
        <div class="card-body">
            <canvas id="txnTrendChart" style="max-height:280px;"></canvas>
        </div>
    </div>
</div>

<!-- Categories + User Growth -->
<div class="grid-2 mb-3">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">🛍️ Spending by Category</h3>
        </div>
        <div class="card-body">
            <canvas id="catBarChart" style="max-height:280px;"></canvas>
        </div>
    </div>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">👥 User Growth</h3>
        </div>
        <div class="card-body">
            <canvas id="userGrowthChart" style="max-height:280px;"></canvas>
        </div>
    </div>
</div>

<!-- Top Spenders + Summary Table -->
<div class="grid-2">
    <!-- Top Spenders -->
    <div class="card">
        <div class="card-header"><h3 class="card-title">🏆 Top Spenders</h3></div>
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr><th>#</th><th>User</th><th>Transactions</th><th>Total Spent</th></tr>
                </thead>
                <tbody>
                    <?php foreach($topSpenders as $i => $s): ?>
                    <tr>
                        <td style="font-weight:700;color:<?= ['#FFD700','#C0C0C0','#CD7F32'][$i] ?? 'var(--text-muted)' ?>;"><?= $i+1 ?></td>
                        <td>
                            <div style="font-weight:600;font-size:0.88rem;"><?= htmlspecialchars($s['name']) ?></div>
                            <div style="font-size:0.75rem;color:var(--text-muted);"><?= htmlspecialchars($s['email']) ?></div>
                        </td>
                        <td style="text-align:center;"><?= $s['txn_count'] ?></td>
                        <td style="font-weight:700;color:var(--danger);"><?= formatCurrency($s['total_spent']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Category Summary -->
    <div class="card">
        <div class="card-header"><h3 class="card-title">📋 Category Summary</h3></div>
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr><th>Category</th><th>Transactions</th><th>Total</th><th>Share</th></tr>
                </thead>
                <tbody>
                    <?php
                    $grandTotal = array_sum(array_column($spendByCategory,'total'));
                    foreach($spendByCategory as $c):
                        $pct = $grandTotal > 0 ? round($c['total'] / $grandTotal * 100) : 0;
                    ?>
                    <tr>
                        <td><?= getCategoryIcon($c['category']) ?> <span style="text-transform:capitalize;"><?= $c['category'] ?></span></td>
                        <td style="text-align:center;"><?= $c['count'] ?></td>
                        <td style="font-weight:700;"><?= formatCurrency($c['total']) ?></td>
                        <td style="white-space:nowrap;">
                            <div style="display:flex;align-items:center;gap:8px;">
                                <div class="progress-bar-wrap" style="height:6px;width:60px;">
                                    <div class="progress-bar-fill" data-width="<?= $pct ?>" style=""></div>
                                </div>
                                <span style="font-size:0.78rem;color:var(--text-muted);"><?= $pct ?>%</span>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</div></div>
<div id="toast-container"></div>
<script src="../assets/js/main.js"></script>
<script>
// Revenue 12 months
const revCtx12 = document.getElementById('revenueChart12').getContext('2d');
const revGrad  = revCtx12.createLinearGradient(0,0,0,280);
revGrad.addColorStop(0,'rgba(37,99,235,0.4)'); revGrad.addColorStop(1,'rgba(37,99,235,0)');
new Chart(revCtx12, {
    type: 'line',
    data: {
        labels: <?= json_encode(array_column($monthlyRevenue,'label')) ?>,
        datasets: [{
            label:'Revenue',
            data: <?= json_encode(array_map(fn($r) => round((float)$r['revenue']),$monthlyRevenue)) ?>,
            borderColor:'#2563EB', backgroundColor:revGrad, fill:true, tension:0.4,
            pointRadius:4, pointBackgroundColor:'#2563EB', borderWidth:2.5
        }]
    },
    options: {
        responsive:true,
        plugins:{ legend:{display:false}, tooltip:{callbacks:{label:c=>'₹'+c.raw.toLocaleString('en-IN')}} },
        scales:{
            x:{grid:{color:'rgba(255,255,255,0.05)'},ticks:{color:'#94A3B8',font:{size:10}}},
            y:{grid:{color:'rgba(255,255,255,0.05)'},ticks:{color:'#94A3B8',callback:v=>'₹'+v.toLocaleString('en-IN')}}
        }
    }
});

// Transaction trend chart
const txnCtx = document.getElementById('txnTrendChart').getContext('2d');
const spGrad = txnCtx.createLinearGradient(0,0,0,280);
spGrad.addColorStop(0,'rgba(220,38,38,0.3)'); spGrad.addColorStop(1,'rgba(220,38,38,0)');
const pyGrad = txnCtx.createLinearGradient(0,0,0,280);
pyGrad.addColorStop(0,'rgba(16,185,129,0.3)'); pyGrad.addColorStop(1,'rgba(16,185,129,0)');
new Chart(txnCtx, {
    type:'line',
    data:{
        labels: <?= json_encode(array_column($txnTrend,'label')) ?>,
        datasets:[
            {label:'Spending',data:<?= json_encode(array_map(fn($t)=>round((float)$t['debit_sum']),$txnTrend)) ?>,borderColor:'#DC2626',backgroundColor:spGrad,fill:true,tension:0.4,borderWidth:2},
            {label:'Payments',data:<?= json_encode(array_map(fn($t)=>round((float)$t['payment_sum']),$txnTrend)) ?>,borderColor:'#10B981',backgroundColor:pyGrad,fill:true,tension:0.4,borderWidth:2}
        ]
    },
    options:{
        responsive:true,
        plugins:{legend:{labels:{color:'#94A3B8'}},tooltip:{callbacks:{label:c=>c.dataset.label+': ₹'+c.raw.toLocaleString('en-IN')}}},
        scales:{x:{grid:{color:'rgba(255,255,255,0.05)'},ticks:{color:'#94A3B8',font:{size:10}}},y:{grid:{color:'rgba(255,255,255,0.05)'},ticks:{color:'#94A3B8',callback:v=>'₹'+v.toLocaleString('en-IN')}}}
    }
});

// Category bar chart
new Chart(document.getElementById('catBarChart'), {
    type:'bar',
    data:{
        labels: <?= json_encode(array_column($spendByCategory,'category')) ?>,
        datasets:[{
            label:'Total Spending',
            data: <?= json_encode(array_map(fn($c)=>round((float)$c['total']),$spendByCategory)) ?>,
            backgroundColor: ['#2563EB','#10B981','#F59E0B','#7C3AED','#DC2626','#06B6D4','#F97316','#84CC16','#EC4899'],
            borderWidth:0, borderRadius:6
        }]
    },
    options:{
        responsive:true, indexAxis:'y',
        plugins:{legend:{display:false},tooltip:{callbacks:{label:c=>'₹'+c.raw.toLocaleString('en-IN')}}},
        scales:{x:{grid:{color:'rgba(255,255,255,0.05)'},ticks:{color:'#94A3B8',callback:v=>'₹'+v.toLocaleString('en-IN')}},y:{grid:{display:false},ticks:{color:'#94A3B8'}}}
    }
});

// User growth
new Chart(document.getElementById('userGrowthChart'), {
    type:'line',
    data:{
        labels: <?= json_encode(array_column($userGrowth,'label')) ?>,
        datasets:[{
            label:'New Users',
            data: <?= json_encode(array_column($userGrowth,'count')) ?>,
            borderColor:'#10B981', backgroundColor:'rgba(16,185,129,0.15)',
            fill:true, tension:0.4, pointRadius:4, pointBackgroundColor:'#10B981'
        }]
    },
    options:{
        responsive:true,
        plugins:{legend:{display:false}},
        scales:{x:{grid:{color:'rgba(255,255,255,0.05)'},ticks:{color:'#94A3B8',font:{size:10}}},y:{grid:{color:'rgba(255,255,255,0.05)'},ticks:{color:'#94A3B8'}}}
    }
});
</script>
</body>
</html>
