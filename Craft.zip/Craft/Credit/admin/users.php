<?php
/**
 * Admin User Management (CRUD)
 * Secure Credit Card Management System
 */
require_once 'layout.php';

$msg = '';

// DELETE user (via POST for security)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_user'])) {
    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
        $msg = ['type'=>'error','text'=>'Invalid request.'];
    } else {
        $id = (int)$_POST['delete_user'];
        // Prevent self-deletion
        if ($id != (int)$user['id']) {
            $pdo->prepare("DELETE FROM users WHERE id=? AND role!='admin'")->execute([$id]);
            logAdminAction("Deleted user", 'users', $id, "Admin deleted user ID $id");
            header('Location: users.php?msg=deleted');
            exit;
        } else {
            $msg = ['type'=>'error','text'=>'You cannot delete your own account.'];
        }
    }
}

// BLOCK/UNBLOCK user (via POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_user'])) {
    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
        $msg = ['type'=>'error','text'=>'Invalid request.'];
    } else {
        $id  = (int)$_POST['toggle_user'];
        $row = $pdo->prepare("SELECT status FROM users WHERE id=?");
        $row->execute([$id]);
        $st  = $row->fetchColumn();
        $newSt = $st === 'active' ? 'blocked' : 'active';
        $pdo->prepare("UPDATE users SET status=? WHERE id=?")->execute([$newSt, $id]);
        logAdminAction("Changed status to $newSt", 'users', $id);
        // Notify user of status change
        createNotification($id, $newSt === 'blocked' ? '⛔ Account Blocked' : '✅ Account Activated',
            $newSt === 'blocked' ? 'Your account has been blocked by admin. Contact support.' : 'Your account has been reactivated.', 'alert');
        header('Location: users.php?msg=' . ($newSt === 'blocked' ? 'blocked' : 'unblocked'));
        exit;
    }
}

// ADD / EDIT user
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_user'])) {
    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
        $msg = ['type'=>'error','text'=>'Invalid request.'];
    } else {
        $id     = (int)($_POST['user_id'] ?? 0);
        $name   = sanitize($_POST['name'] ?? '');
        $email  = sanitize($_POST['email'] ?? '');
        $mobile = sanitize($_POST['mobile'] ?? '');
        $role   = in_array($_POST['role'] ?? '', ['admin','user']) ? $_POST['role'] : 'user';
        $status = in_array($_POST['status'] ?? '', ['active','blocked','pending']) ? $_POST['status'] : 'active';

        if (empty($name) || empty($email) || empty($mobile)) {
            $msg = ['type'=>'error','text'=>'Name, email and mobile are required.'];
        } else {
            if ($id) {
                // Edit
                $pdo->prepare("UPDATE users SET name=?,email=?,mobile=?,role=?,status=? WHERE id=?")
                    ->execute([$name,$email,$mobile,$role,$status,$id]);
                logAdminAction("Updated user", 'users', $id, "Updated details for $email");
                $msg = ['type'=>'success','text'=>"✅ User updated successfully."];
            } else {
                // Add
                $password = $_POST['password'] ?? 'Admin@123';
                $check    = $pdo->prepare("SELECT id FROM users WHERE email=?");
                $check->execute([$email]);
                if ($check->fetch()) {
                    $msg = ['type'=>'error','text'=>'Email already registered.'];
                } else {
                    $pdo->prepare("INSERT INTO users (name,email,mobile,password,role,status) VALUES (?,?,?,?,?,?)")
                        ->execute([$name,$email,$mobile,hashPassword($password),$role,$status]);
                    $newId = $pdo->lastInsertId();
                    logAdminAction("Added new user", 'users', $newId, "Added user $email");
                    $msg = ['type'=>'success','text'=>"✅ User created successfully."];
                }
            }
        }
    }
}

// Get edit user
$editUser = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id=?");
    $stmt->execute([(int)$_GET['edit']]);
    $editUser = $stmt->fetch();
}

// Flash from redirect
if (isset($_GET['msg'])) {
    $msg = match($_GET['msg']) {
        'deleted'   => ['type'=>'success','text'=>'✅ User deleted successfully.'],
        'blocked'   => ['type'=>'success','text'=>'⛔ User has been blocked.'],
        'unblocked' => ['type'=>'success','text'=>'✅ User has been reactivated.'],
        default     => null
    };
}

// Filters
$search = sanitize($_GET['search'] ?? '');
$statusFilter = $_GET['status_filter'] ?? '';

$where  = ["role!='admin'"];
$params = [];
if ($search) { $where[] = "(name LIKE ? OR email LIKE ? OR mobile LIKE ?)"; $params = array_merge($params, ["%$search%","%$search%","%$search%"]); }
if ($statusFilter) { $where[] = "status=?"; $params[] = $statusFilter; }

$whereStr  = implode(' AND ', $where);
$usersList = $pdo->prepare("SELECT * FROM users WHERE $whereStr ORDER BY created_at DESC");
$usersList->execute($params);
$users = $usersList->fetchAll();

$addMode = isset($_GET['action']) && $_GET['action'] === 'add';
$csrf = generateCSRF();
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>User Management — Admin</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php renderAdminSidebar($user, $currentPage); ?>
<div class="main-wrapper">
<?php renderAdminTopbar($user, '👥 User Management'); ?>
<div class="content-area">

<?php if ($msg): ?>
<div style="background:<?= $msg['type']==='success' ? 'rgba(16,185,129,0.1)' : 'rgba(220,38,38,0.1)' ?>;border:1px solid <?= $msg['type']==='success' ? 'rgba(16,185,129,0.3)' : 'rgba(220,38,38,0.3)' ?>;border-radius:12px;padding:12px 16px;margin-bottom:20px;color:<?= $msg['type']==='success' ? '#34D399' : '#F87171' ?>;">
    <?= $msg['text'] ?>
</div>
<?php endif; ?>

<?php if ($addMode || $editUser): ?>
<!-- Add/Edit Form -->
<div class="card mb-3">
    <div class="card-header">
        <h3 class="card-title"><?= $editUser ? '✏️ Edit User' : '➕ Add New User' ?></h3>
        <a href="users.php" class="btn btn-ghost btn-sm">✕ Cancel</a>
    </div>
    <div class="card-body">
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
            <input type="hidden" name="save_user" value="1">
            <input type="hidden" name="user_id" value="<?= $editUser['id'] ?? 0 ?>">

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Full Name *</label>
                    <input type="text" name="name" class="form-control" required
                           value="<?= htmlspecialchars($editUser['name'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label class="form-label">Mobile *</label>
                    <input type="tel" name="mobile" class="form-control" maxlength="10" required
                           value="<?= htmlspecialchars($editUser['mobile'] ?? '') ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Email *</label>
                    <input type="email" name="email" class="form-control" required
                           value="<?= htmlspecialchars($editUser['email'] ?? '') ?>">
                </div>
                <?php if (!$editUser): ?>
                <div class="form-group">
                    <label class="form-label">Password</label>
                    <input type="text" name="password" class="form-control" value="Admin@123">
                    <p class="form-hint">Default password. User should change on first login.</p>
                </div>
                <?php endif; ?>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Role</label>
                    <select name="role" class="form-control">
                        <option value="user"  <?= ($editUser['role'] ?? 'user')==='user'  ? 'selected' : '' ?>>User</option>
                        <option value="admin" <?= ($editUser['role'] ?? '')==='admin' ? 'selected' : '' ?>>Admin</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-control">
                        <option value="active"  <?= ($editUser['status'] ?? 'active')==='active'  ? 'selected' : '' ?>>Active</option>
                        <option value="pending" <?= ($editUser['status'] ?? '')==='pending' ? 'selected' : '' ?>>Pending</option>
                        <option value="blocked" <?= ($editUser['status'] ?? '')==='blocked' ? 'selected' : '' ?>>Blocked</option>
                    </select>
                </div>
            </div>
            <button type="submit" class="btn btn-primary"><?= $editUser ? '💾 Update User' : '➕ Create User' ?></button>
        </form>
    </div>
</div>
<?php endif; ?>

<!-- Filters + Table -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">All Users</h3>
        <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
            <form method="GET" style="display:flex;gap:8px;align-items:center;">
                <div class="search-bar">
                    <span class="search-icon">🔍</span>
                    <input type="text" name="search" id="table-search" placeholder="Search..." value="<?= htmlspecialchars($search) ?>" style="width:190px;">
                </div>
                <select name="status_filter" class="form-control" style="height:38px;width:120px;" onchange="this.form.submit()">
                    <option value="">All Status</option>
                    <option value="active"  <?= $statusFilter==='active'  ?'selected':'' ?>>Active</option>
                    <option value="pending" <?= $statusFilter==='pending' ?'selected':'' ?>>Pending</option>
                    <option value="blocked" <?= $statusFilter==='blocked' ?'selected':'' ?>>Blocked</option>
                </select>
                <button type="submit" class="btn btn-primary btn-sm">Go</button>
            </form>
            <a href="users.php?action=add" class="btn btn-primary btn-sm">➕ Add User</a>
        </div>
    </div>
    <div class="table-wrapper">
        <table id="main-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>User</th>
                    <th>Mobile</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Registered</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($users as $i => $u): ?>
                <tr>
                    <td style="color:var(--text-muted);"><?= $i + 1 ?></td>
                    <td>
                        <div style="display:flex;align-items:center;gap:10px;">
                            <div style="width:36px;height:36px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--info));display:flex;align-items:center;justify-content:center;font-weight:700;color:white;font-size:0.85rem;flex-shrink:0;">
                                <?= strtoupper(substr($u['name'],0,1)) ?>
                            </div>
                            <div>
                                <div style="font-weight:600;font-size:0.88rem;"><?= htmlspecialchars($u['name']) ?></div>
                                <div style="font-size:0.75rem;color:var(--text-muted);"><?= htmlspecialchars($u['email']) ?></div>
                            </div>
                        </div>
                    </td>
                    <td style="font-size:0.88rem;"><?= htmlspecialchars($u['mobile']) ?></td>
                    <td><span class="badge <?= $u['role']==='admin' ? 'badge-danger' : 'badge-info' ?>"><?= ucfirst($u['role']) ?></span></td>
                    <td><span class="badge <?= getStatusBadge($u['status']) ?>"><?= ucfirst($u['status']) ?></span></td>
                    <td style="font-size:0.8rem;color:var(--text-muted);"><?= date('d M Y', strtotime($u['created_at'])) ?></td>
                    <td>
                        <div style="display:flex;gap:4px;">
                            <a href="users.php?edit=<?= $u['id'] ?>" class="btn btn-ghost btn-sm" title="Edit">✏️</a>
                            <button type="button"
                                    class="btn btn-sm <?= $u['status']==='active' ? 'btn-warning' : 'btn-success' ?>"
                                    title="<?= $u['status']==='active' ? 'Block User' : 'Activate User' ?>"
                                    onclick="toggleUser(<?= $u['id'] ?>, '<?= htmlspecialchars(addslashes($u['name'])) ?>', '<?= $u['status'] ?>')">
                                <?= $u['status']==='active' ? '⛔' : '✅' ?>
                            </button>
                            <?php if ($u['id'] != $user['id']): ?>
                            <button type="button" class="btn btn-danger btn-sm" title="Delete"
                                    onclick="deleteUser(<?= $u['id'] ?>, '<?= htmlspecialchars(addslashes($u['name'])) ?>')">
                                🗑️
                            </button>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($users)): ?>
                <tr><td colspan="7" style="text-align:center;padding:40px;color:var(--text-muted);">No users found</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</div></div>

<!-- Hidden delete form -->
<form id="delete-user-form" method="POST" style="display:none;">
    <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
    <input type="hidden" name="delete_user" id="delete-user-id" value="">
</form>

<!-- Hidden TOGGLE form -->
<form id="toggle-user-form" method="POST" style="display:none;">
    <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
    <input type="hidden" name="toggle_user" id="toggle-user-id" value="">
</form>

<!-- Delete Confirm Modal -->
<div id="delete-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.7);z-index:9999;align-items:center;justify-content:center;">
    <div style="background:#1e293b;border:1px solid rgba(220,38,38,0.4);border-radius:16px;padding:32px;max-width:420px;width:90%;text-align:center;">
        <div style="font-size:3rem;margin-bottom:12px;">🗑️</div>
        <h3 style="margin-bottom:8px;">Delete User?</h3>
        <p id="delete-modal-msg" style="color:var(--text-muted);margin-bottom:24px;font-size:0.9rem;"></p>
        <div style="display:flex;gap:12px;justify-content:center;">
            <button onclick="closeDeleteModal()" class="btn btn-ghost" style="min-width:110px;">Cancel</button>
            <button onclick="confirmDelete()" class="btn btn-danger" style="min-width:110px;">Yes, Delete</button>
        </div>
    </div>
</div>

<!-- Toggle / Block-Unblock Confirm Modal -->
<div id="toggle-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.7);z-index:9999;align-items:center;justify-content:center;">
    <div style="background:#1e293b;border:1px solid rgba(245,158,11,0.4);border-radius:16px;padding:32px;max-width:440px;width:90%;text-align:center;">
        <div id="toggle-modal-icon" style="font-size:3rem;margin-bottom:12px;">⛔</div>
        <h3 id="toggle-modal-title" style="margin-bottom:8px;">Block User?</h3>
        <p id="toggle-modal-msg" style="color:var(--text-muted);margin-bottom:24px;font-size:0.9rem;"></p>
        <div style="display:flex;gap:12px;justify-content:center;">
            <button onclick="closeToggleModal()" class="btn btn-ghost" style="min-width:110px;">Cancel</button>
            <button id="toggle-confirm-btn" onclick="confirmToggle()" class="btn btn-warning" style="min-width:110px;">Confirm</button>
        </div>
    </div>
</div>

<div id="toast-container"></div>
<script src="../assets/js/main.js"></script>
<script>
// DELETE
function deleteUser(id, name) {
    document.getElementById('delete-user-id').value = id;
    document.getElementById('delete-modal-msg').textContent = 'Are you sure you want to delete "' + name + '"? This action cannot be undone.';
    document.getElementById('delete-modal').style.display = 'flex';
}
function closeDeleteModal() {
    document.getElementById('delete-modal').style.display = 'none';
}
function confirmDelete() {
    document.getElementById('delete-user-form').submit();
}
document.getElementById('delete-modal').addEventListener('click', function(e) {
    if (e.target === this) closeDeleteModal();
});

// TOGGLE (BLOCK / UNBLOCK)
function toggleUser(id, name, currentStatus) {
    const isActive = currentStatus === 'active';
    document.getElementById('toggle-user-id').value = id;
    document.getElementById('toggle-modal-icon').textContent = isActive ? '⛔' : '✅';
    document.getElementById('toggle-modal-title').textContent = isActive ? 'Block User?' : 'Activate User?';
    document.getElementById('toggle-modal-msg').textContent = isActive
        ? 'Block "' + name + '"? They will not be able to log in until unblocked.'
        : 'Activate "' + name + '"? They will regain access to their account.';
    const btn = document.getElementById('toggle-confirm-btn');
    btn.textContent = isActive ? 'Yes, Block' : 'Yes, Activate';
    btn.className = isActive ? 'btn btn-warning' : 'btn btn-success';
    document.getElementById('toggle-modal').style.display = 'flex';
}
function closeToggleModal() {
    document.getElementById('toggle-modal').style.display = 'none';
}
function confirmToggle() {
    document.getElementById('toggle-user-form').submit();
}
document.getElementById('toggle-modal').addEventListener('click', function(e) {
    if (e.target === this) closeToggleModal();
});
</script>
</body>
</html>

