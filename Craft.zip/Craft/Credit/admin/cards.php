<?php
/**
 * Admin Credit Card Management
 * Secure Credit Card Management System
 */
require_once 'layout.php';

$msg = '';

// Delete card (via POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_card'])) {
    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
        $msg = ['type'=>'error','text'=>'Invalid request.'];
    } else {
        $id = (int)$_POST['delete_card'];
        $pdo->prepare("DELETE FROM credit_cards WHERE id=?")->execute([$id]);
        logAdminAction("Deleted credit card", 'credit_cards', $id);
        header('Location: cards.php?msg=deleted');
        exit;
    }
}

// Toggle card status (via POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_card'])) {
    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
        $msg = ['type'=>'error','text'=>'Invalid request.'];
    } else {
        $id  = (int)$_POST['toggle_card'];
        $row = $pdo->prepare("SELECT status FROM credit_cards WHERE id=?");
        $row->execute([$id]);
        $st  = $row->fetchColumn();
        $new = $st === 'active' ? 'blocked' : 'active';
        $pdo->prepare("UPDATE credit_cards SET status=? WHERE id=?")->execute([$new, $id]);
        logAdminAction("Card status changed to $new", 'credit_cards', $id);
        // Notify card holder
        $cardRow = $pdo->prepare("SELECT user_id FROM credit_cards WHERE id=?");
        $cardRow->execute([$id]);
        $uid = $cardRow->fetchColumn();
        if ($uid) createNotification($uid, $new === 'blocked' ? '⛔ Card Blocked' : '✅ Card Activated',
            $new === 'blocked' ? 'Your credit card has been blocked. Contact support.' : 'Your credit card has been reactivated.', 'alert');
        header('Location: cards.php?msg=' . ($new === 'blocked' ? 'blocked' : 'activated'));
        exit;
    }
}

// Save card (add/edit)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_card'])) {
    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
        $msg = ['type'=>'error','text'=>'Invalid request.'];
    } else {
        $cardId  = (int)($_POST['card_id'] ?? 0);
        $userId  = (int)($_POST['user_id'] ?? 0);
        $holder  = sanitize($_POST['card_holder'] ?? '');
        $type    = in_array($_POST['card_type']??'', ['Visa','MasterCard','Rupay','Amex']) ? $_POST['card_type'] : 'Visa';
        $limit   = (float)($_POST['credit_limit'] ?? 50000);
        $bal     = (float)($_POST['available_balance'] ?? $limit);
        $outst   = (float)($_POST['outstanding_balance'] ?? 0);
        $status  = in_array($_POST['status']??'', ['active','blocked','expired','pending']) ? $_POST['status'] : 'active';
        $expM    = (int)($_POST['expiry_month'] ?? date('m'));
        $expY    = (int)($_POST['expiry_year']  ?? date('Y') + 4);
        $issued  = sanitize($_POST['issued_date'] ?? date('Y-m-d'));

        if (!$userId || !$holder) {
            $msg = ['type'=>'error','text'=>'User and card holder name are required.'];
        } elseif ($cardId) {
            // Edit
            $pdo->prepare("UPDATE credit_cards SET user_id=?,card_holder=?,card_type=?,credit_limit=?,available_balance=?,outstanding_balance=?,status=?,expiry_month=?,expiry_year=?,issued_date=? WHERE id=?")
                ->execute([$userId,$holder,$type,$limit,$bal,$outst,$status,$expM,$expY,$issued,$cardId]);
            logAdminAction("Updated credit card", 'credit_cards', $cardId);
            $msg = ['type'=>'success','text'=>'✅ Card updated successfully.'];
        } else {
            // Add
            $cardNum = implode('', array_map(fn($c) => str_pad(random_int(0,9999),4,'0',STR_PAD_LEFT), array_fill(0,4,'')));
            $cvv     = str_pad(random_int(0,999), 3, '0', STR_PAD_LEFT);

            // Check user already has card
            $ck = $pdo->prepare("SELECT id FROM credit_cards WHERE user_id=?");
            $ck->execute([$userId]);
            if ($ck->fetch()) {
                $msg = ['type'=>'error','text'=>'This user already has a credit card assigned.'];
            } else {
                $pdo->prepare("INSERT INTO credit_cards (user_id,card_number,card_holder,card_type,expiry_month,expiry_year,cvv,credit_limit,available_balance,outstanding_balance,status,issued_date) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)")
                    ->execute([$userId,$cardNum,$holder,$type,$expM,$expY,hashPassword($cvv),$limit,$bal,$outst,$status,$issued]);
                $newId = $pdo->lastInsertId();
                logAdminAction("Assigned credit card", 'credit_cards', $newId, "Assigned $type card to user $userId");
                createNotification($userId, '💳 Credit Card Assigned!', "A $type credit card has been assigned to your account with limit " . formatCurrency($limit), 'info');
                $msg = ['type'=>'success','text'=>"✅ Card assigned! Card Number: $cardNum"];
            }
        }
    }
}

// Get edit card
$editCard = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM credit_cards WHERE id=?");
    $stmt->execute([(int)$_GET['edit']]);
    $editCard = $stmt->fetch();
}

if (isset($_GET['msg'])) $msg = ['type'=>'success','text'=>match($_GET['msg']) {
    'deleted'   => '✅ Card deleted.',
    'blocked'   => '⛔ Card has been blocked.',
    'activated' => '✅ Card has been activated.',
    default     => 'Done.'
}];

// Get all users without cards (for add form)
$usersNoCard = $pdo->query("SELECT u.id,u.name,u.email FROM users u WHERE u.role='user' AND u.status='active' AND u.id NOT IN (SELECT user_id FROM credit_cards) ORDER BY u.name")->fetchAll();

// Get all cards
$cards = $pdo->query("
    SELECT c.*, u.name AS user_name, u.email AS user_email 
    FROM credit_cards c 
    JOIN users u ON c.user_id=u.id 
    ORDER BY c.created_at DESC
")->fetchAll();

$addMode = isset($_GET['action']) && $_GET['action'] === 'add';
$csrf = generateCSRF();
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Credit Card Management — Admin</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php renderAdminSidebar($user, $currentPage); ?>
<div class="main-wrapper">
<?php renderAdminTopbar($user, '💳 Credit Card Management'); ?>
<div class="content-area">

<?php if ($msg): ?>
<div style="background:<?= $msg['type']==='success' ? 'rgba(16,185,129,0.1)' : 'rgba(220,38,38,0.1)' ?>;border:1px solid <?= $msg['type']==='success' ? 'rgba(16,185,129,0.3)' : 'rgba(220,38,38,0.3)' ?>;border-radius:12px;padding:12px 16px;margin-bottom:20px;color:<?= $msg['type']==='success' ? '#34D399' : '#F87171' ?>;">
    <?= $msg['text'] ?>
</div>
<?php endif; ?>

<?php if ($addMode || $editCard): ?>
<!-- Add/Edit Card Form -->
<div class="card mb-3">
    <div class="card-header">
        <h3 class="card-title"><?= $editCard ? '✏️ Edit Credit Card' : '💳 Assign Credit Card' ?></h3>
        <a href="cards.php" class="btn btn-ghost btn-sm">✕ Cancel</a>
    </div>
    <div class="card-body">
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
            <input type="hidden" name="save_card" value="1">
            <input type="hidden" name="card_id" value="<?= $editCard['id'] ?? 0 ?>">

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Assign to User *</label>
                    <select name="user_id" class="form-control" required>
                        <option value="">-- Select User --</option>
                        <?php if ($editCard):
                            // Show current user too
                            $cu = $pdo->prepare("SELECT id,name,email FROM users WHERE id=?");
                            $cu->execute([$editCard['user_id']]);
                            $uRow = $cu->fetch(); ?>
                        <option value="<?= $uRow['id'] ?>" selected><?= htmlspecialchars($uRow['name']) ?> (<?= htmlspecialchars($uRow['email']) ?>)</option>
                        <?php else: foreach($usersNoCard as $u2): ?>
                        <option value="<?= $u2['id'] ?>"><?= htmlspecialchars($u2['name']) ?> — <?= htmlspecialchars($u2['email']) ?></option>
                        <?php endforeach; endif; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Card Type</label>
                    <select name="card_type" class="form-control">
                        <?php foreach(['Visa','MasterCard','Rupay','Amex'] as $t): ?>
                        <option <?= ($editCard['card_type']??'Visa')===$t?'selected':'' ?>><?= $t ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Card Holder Name *</label>
                    <input type="text" name="card_holder" class="form-control" required
                           value="<?= htmlspecialchars($editCard['card_holder'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label class="form-label">Credit Limit (₹)</label>
                    <input type="number" name="credit_limit" class="form-control" min="1000" max="10000000"
                           value="<?= $editCard['credit_limit'] ?? 50000 ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Available Balance (₹)</label>
                    <input type="number" name="available_balance" class="form-control" step="0.01"
                           value="<?= $editCard['available_balance'] ?? 50000 ?>">
                </div>
                <div class="form-group">
                    <label class="form-label">Outstanding Balance (₹)</label>
                    <input type="number" name="outstanding_balance" class="form-control" step="0.01"
                           value="<?= $editCard['outstanding_balance'] ?? 0 ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Expiry Month</label>
                    <select name="expiry_month" class="form-control">
                        <?php for($m=1;$m<=12;$m++): ?>
                        <option value="<?= $m ?>" <?= ($editCard['expiry_month']??date('n'))===$m?'selected':'' ?>><?= date('M', mktime(0,0,0,$m,1)) ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Expiry Year</label>
                    <select name="expiry_year" class="form-control">
                        <?php for($y=date('Y'); $y<=date('Y')+8; $y++): ?>
                        <option value="<?= $y ?>" <?= ($editCard['expiry_year']??date('Y')+4)===$y?'selected':'' ?>><?= $y ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-control">
                        <?php foreach(['active','blocked','expired','pending'] as $s): ?>
                        <option value="<?= $s ?>" <?= ($editCard['status']??'active')===$s?'selected':'' ?>><?= ucfirst($s) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Issued Date</label>
                    <input type="date" name="issued_date" class="form-control"
                           value="<?= $editCard['issued_date'] ?? date('Y-m-d') ?>">
                </div>
            </div>
            <button type="submit" class="btn btn-primary"><?= $editCard ? '💾 Update Card' : '💳 Assign Card' ?></button>
        </form>
    </div>
</div>
<?php endif; ?>

<!-- Cards Table -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">All Credit Cards</h3>
        <div style="display:flex;gap:10px;">
            <div class="search-bar">
                <span class="search-icon">🔍</span>
                <input type="text" id="table-search" placeholder="Search..." style="width:190px;">
            </div>
            <a href="cards.php?action=add" class="btn btn-primary btn-sm">💳 Assign Card</a>
        </div>
    </div>
    <div class="table-wrapper">
        <table id="main-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>User</th>
                    <th>Card Number</th>
                    <th>Type</th>
                    <th>Credit Limit</th>
                    <th>Available</th>
                    <th>Outstanding</th>
                    <th>Expires</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($cards as $i => $c): ?>
                <tr>
                    <td style="color:var(--text-muted);"><?= $i + 1 ?></td>
                    <td>
                        <div style="font-weight:600;font-size:0.88rem;"><?= htmlspecialchars($c['user_name']) ?></div>
                        <div style="font-size:0.75rem;color:var(--text-muted);"><?= htmlspecialchars($c['user_email']) ?></div>
                    </td>
                    <td style="font-family:monospace;font-size:0.85rem;"><?= formatMaskedCard($c['card_number']) ?></td>
                    <td><span class="badge badge-primary"><?= $c['card_type'] ?></span></td>
                    <td style="font-weight:600;"><?= formatCurrency($c['credit_limit']) ?></td>
                    <td style="color:var(--success);font-weight:600;"><?= formatCurrency($c['available_balance']) ?></td>
                    <td style="color:<?= $c['outstanding_balance'] > 0 ? 'var(--danger)' : 'var(--text-muted)' ?>;font-weight:600;"><?= formatCurrency($c['outstanding_balance']) ?></td>
                    <td style="font-size:0.82rem;"><?= str_pad($c['expiry_month'],2,'0',STR_PAD_LEFT) ?>/<?= $c['expiry_year'] ?></td>
                    <td><span class="badge <?= getStatusBadge($c['status']) ?>"><?= ucfirst($c['status']) ?></span></td>
                    <td>
                        <div style="display:flex;gap:4px;">
                            <a href="cards.php?edit=<?= $c['id'] ?>" class="btn btn-ghost btn-sm">✏️</a>
                            <button type="button" class="btn btn-sm <?= $c['status']==='active' ? 'btn-warning' : 'btn-success' ?>"
                                    onclick="toggleCard(<?= $c['id'] ?>, '<?= htmlspecialchars(addslashes($c['user_name'])) ?>', '<?= $c['status'] ?>')">
                                <?= $c['status']==='active' ? '⛔' : '✅' ?>
                            </button>
                            <button type="button" class="btn btn-danger btn-sm"
                                    onclick="deleteCard(<?= $c['id'] ?>, '<?= htmlspecialchars(addslashes($c['user_name'])) ?>')">🗑️</button>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

</div></div>

<!-- Hidden delete form -->
<form id="delete-card-form" method="POST" style="display:none;">
    <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
    <input type="hidden" name="delete_card" id="delete-card-id" value="">
</form>

<!-- Hidden TOGGLE form -->
<form id="toggle-card-form" method="POST" style="display:none;">
    <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
    <input type="hidden" name="toggle_card" id="toggle-card-id" value="">
</form>

<!-- Delete Card Modal -->
<div id="delete-card-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.7);z-index:9999;align-items:center;justify-content:center;">
    <div style="background:#1e293b;border:1px solid rgba(220,38,38,0.4);border-radius:16px;padding:32px;max-width:420px;width:90%;text-align:center;">
        <div style="font-size:3rem;margin-bottom:12px;">💳</div>
        <h3 style="margin-bottom:8px;">Delete Credit Card?</h3>
        <p id="delete-card-msg" style="color:var(--text-muted);margin-bottom:8px;font-size:0.9rem;"></p>
        <p style="color:var(--danger);font-size:0.82rem;margin-bottom:24px;">⚠️ All transactions will also be deleted.</p>
        <div style="display:flex;gap:12px;justify-content:center;">
            <button onclick="closeCardModal()" class="btn btn-ghost" style="min-width:110px;">Cancel</button>
            <button onclick="confirmCardDelete()" class="btn btn-danger" style="min-width:110px;">Yes, Delete</button>
        </div>
    </div>
</div>

<!-- Toggle Card Modal -->
<div id="toggle-card-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.7);z-index:9999;align-items:center;justify-content:center;">
    <div style="background:#1e293b;border:1px solid rgba(245,158,11,0.4);border-radius:16px;padding:32px;max-width:440px;width:90%;text-align:center;">
        <div id="tcard-icon" style="font-size:3rem;margin-bottom:12px;">⛔</div>
        <h3 id="tcard-title" style="margin-bottom:8px;">Block Card?</h3>
        <p id="tcard-msg" style="color:var(--text-muted);margin-bottom:24px;font-size:0.9rem;"></p>
        <div style="display:flex;gap:12px;justify-content:center;">
            <button onclick="closeCardToggleModal()" class="btn btn-ghost" style="min-width:110px;">Cancel</button>
            <button id="tcard-confirm-btn" onclick="confirmCardToggle()" class="btn btn-warning" style="min-width:110px;">Confirm</button>
        </div>
    </div>
</div>

<div id="toast-container"></div>
<script src="../assets/js/main.js"></script>
<script>
// DELETE CARD
function deleteCard(id, userName) {
    document.getElementById('delete-card-id').value = id;
    document.getElementById('delete-card-msg').textContent = 'Delete credit card assigned to "' + userName + '"?';
    document.getElementById('delete-card-modal').style.display = 'flex';
}
function closeCardModal() {
    document.getElementById('delete-card-modal').style.display = 'none';
}
function confirmCardDelete() {
    document.getElementById('delete-card-form').submit();
}
document.getElementById('delete-card-modal').addEventListener('click', function(e) {
    if (e.target === this) closeCardModal();
});

// TOGGLE CARD (BLOCK / ACTIVATE)
function toggleCard(id, name, currentStatus) {
    const isActive = currentStatus === 'active';
    document.getElementById('toggle-card-id').value = id;
    document.getElementById('tcard-icon').textContent = isActive ? '⛔' : '✅';
    document.getElementById('tcard-title').textContent = isActive ? 'Block Card?' : 'Activate Card?';
    document.getElementById('tcard-msg').textContent = isActive
        ? 'Block card for "' + name + '"? They will not be able to use it until reactivated.'
        : 'Activate card for "' + name + '"? They will regain access to their card.';
    const btn = document.getElementById('tcard-confirm-btn');
    btn.textContent = isActive ? 'Yes, Block' : 'Yes, Activate';
    btn.className = isActive ? 'btn btn-warning' : 'btn btn-success';
    document.getElementById('toggle-card-modal').style.display = 'flex';
}
function closeCardToggleModal() {
    document.getElementById('toggle-card-modal').style.display = 'none';
}
function confirmCardToggle() {
    document.getElementById('toggle-card-form').submit();
}
document.getElementById('toggle-card-modal').addEventListener('click', function(e) {
    if (e.target === this) closeCardToggleModal();
});
</script>
</body>
</html>


    if (e.target === this) closeCardModal();
});
</script>
</body>
</html>
