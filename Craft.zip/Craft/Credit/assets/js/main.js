/**
 * Main JavaScript - Secure Credit Card Management System
 */

'use strict';

// ── THEME MANAGEMENT ────────────────────────────────
const ThemeManager = {
    init() {
        const saved = localStorage.getItem('ccms-theme') || 'dark';
        document.documentElement.setAttribute('data-theme', saved);
        this.updateIcon(saved);
    },
    toggle() {
        const current = document.documentElement.getAttribute('data-theme');
        const next = current === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', next);
        localStorage.setItem('ccms-theme', next);
        this.updateIcon(next);
    },
    updateIcon(theme) {
        const icons = document.querySelectorAll('.theme-icon');
        icons.forEach(i => { i.textContent = theme === 'dark' ? '☀️' : '🌙'; });
    }
};

// ── TOAST NOTIFICATIONS ─────────────────────────────
const Toast = {
    container: null,
    init() {
        this.container = document.getElementById('toast-container');
        if (!this.container) {
            this.container = document.createElement('div');
            this.container.id = 'toast-container';
            document.body.appendChild(this.container);
        }
    },
    show(title, message = '', type = 'info', duration = 4000) {
        const icons = { success: '✅', error: '❌', warning: '⚠️', info: 'ℹ️' };
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = `
            <span class="toast-icon">${icons[type] || 'ℹ️'}</span>
            <div class="flex-1">
                <div class="toast-title">${title}</div>
                ${message ? `<div class="toast-msg">${message}</div>` : ''}
            </div>
            <button class="toast-close" onclick="this.closest('.toast').remove()">✕</button>
        `;
        toast.onclick = (e) => { if (!e.target.classList.contains('toast-close')) toast.remove(); };
        this.container.appendChild(toast);
        setTimeout(() => {
            toast.classList.add('hide');
            setTimeout(() => toast.remove(), 300);
        }, duration);
    },
    success(title, msg) { this.show(title, msg, 'success'); },
    error(title, msg)   { this.show(title, msg, 'error'); },
    warning(title, msg) { this.show(title, msg, 'warning'); },
    info(title, msg)    { this.show(title, msg, 'info'); }
};

// ── SIDEBAR MANAGEMENT ──────────────────────────────
const Sidebar = {
    sidebar: null,
    overlay: null,
    init() {
        this.sidebar  = document.querySelector('.sidebar');
        this.overlay  = document.querySelector('.sidebar-overlay') || this.createOverlay();
        const toggle  = document.querySelector('.hamburger');
        if (toggle) toggle.addEventListener('click', () => this.toggle());
        if (this.overlay) this.overlay.addEventListener('click', () => this.close());
        this.setActive();
    },
    createOverlay() {
        const el = document.createElement('div');
        el.className = 'sidebar-overlay';
        document.body.appendChild(el);
        return el;
    },
    toggle() {
        if (this.sidebar) this.sidebar.classList.toggle('open');
        if (this.overlay) this.overlay.classList.toggle('show');
    },
    close() {
        if (this.sidebar) this.sidebar.classList.remove('open');
        if (this.overlay) this.overlay.classList.remove('show');
    },
    setActive() {
        const path = window.location.pathname;
        const links = document.querySelectorAll('.sidebar-nav a');
        links.forEach(link => {
            const href = link.getAttribute('href');
            if (href && path.endsWith(href.split('/').pop())) {
                link.classList.add('active');
            }
        });
    }
};

// ── ANIMATED COUNTERS ───────────────────────────────
const Counter = {
    animate(el, target, duration = 1500, prefix = '', suffix = '') {
        const start     = performance.now();
        const startVal  = parseFloat(el.dataset.start || 0);
        const targetVal = parseFloat(target);
        const isFloat   = target.toString().includes('.');
        const decimals  = isFloat ? 2 : 0;

        const update = (time) => {
            const elapsed  = time - start;
            const progress = Math.min(elapsed / duration, 1);
            const eased    = 1 - Math.pow(1 - progress, 3);
            const current  = startVal + (targetVal - startVal) * eased;
            el.textContent = prefix + current.toFixed(decimals).replace(/\B(?=(\d{3})+(?!\d))/g, ',') + suffix;
            if (progress < 1) requestAnimationFrame(update);
        };
        requestAnimationFrame(update);
    },
    initAll() {
        const counters = document.querySelectorAll('[data-counter]');
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting && !entry.target.dataset.done) {
                    entry.target.dataset.done = '1';
                    const el = entry.target;
                    Counter.animate(el, el.dataset.counter, 1500,
                        el.dataset.prefix || '', el.dataset.suffix || '');
                }
            });
        }, { threshold: 0.5 });
        counters.forEach(c => observer.observe(c));
    }
};

// ── MODAL MANAGEMENT ────────────────────────────────
const Modal = {
    open(id) {
        const overlay = document.getElementById(id);
        if (overlay) {
            overlay.classList.add('open');
            document.body.style.overflow = 'hidden';
        }
    },
    close(id) {
        const overlay = document.getElementById(id);
        if (overlay) {
            overlay.classList.remove('open');
            document.body.style.overflow = '';
        }
    },
    closeAll() {
        document.querySelectorAll('.modal-overlay').forEach(m => {
            m.classList.remove('open');
        });
        document.body.style.overflow = '';
    },
    init() {
        document.querySelectorAll('[data-modal-open]').forEach(btn => {
            btn.addEventListener('click', () => Modal.open(btn.dataset.modalOpen));
        });
        document.querySelectorAll('[data-modal-close]').forEach(btn => {
            btn.addEventListener('click', () => Modal.close(btn.closest('.modal-overlay').id));
        });
        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) Modal.close(overlay.id);
            });
        });
    }
};

// ── AJAX HELPER ─────────────────────────────────────
const Ajax = {
    async post(url, data) {
        try {
            const body = data instanceof FormData ? data : new URLSearchParams(data);
            const res = await fetch(url, {
                method: 'POST',
                headers: data instanceof FormData ? {} : { 'Content-Type': 'application/x-www-form-urlencoded' },
                body
            });
            return await res.json();
        } catch (err) {
            return { success: false, message: 'Network error: ' + err.message };
        }
    },
    async get(url) {
        try {
            const res = await fetch(url);
            return await res.json();
        } catch (err) {
            return { success: false, message: 'Network error: ' + err.message };
        }
    }
};

// ── FORM VALIDATION ─────────────────────────────────
const Validate = {
    email: (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v),
    mobile: (v) => /^[6-9]\d{9}$/.test(v),
    password: (v) => v.length >= 8 && /[A-Z]/.test(v) && /\d/.test(v),
    required: (v) => v.trim().length > 0,
    amount: (v) => !isNaN(v) && parseFloat(v) > 0,

    form(formId, rules) {
        const form = document.getElementById(formId);
        if (!form) return false;
        let valid = true;
        Object.entries(rules).forEach(([field, checks]) => {
            const el = form.querySelector(`[name="${field}"]`);
            const errEl = form.querySelector(`#err-${field}`);
            if (!el) return;
            let msg = '';
            for (const [rule, ruleMsg] of Object.entries(checks)) {
                if (rule === 'required' && !Validate.required(el.value)) { msg = ruleMsg; break; }
                if (rule === 'email' && !Validate.email(el.value)) { msg = ruleMsg; break; }
                if (rule === 'mobile' && !Validate.mobile(el.value)) { msg = ruleMsg; break; }
                if (rule === 'password' && !Validate.password(el.value)) { msg = ruleMsg; break; }
                if (rule === 'minLength' && el.value.length < ruleMsg[0]) { msg = ruleMsg[1]; break; }
            }
            if (errEl) errEl.textContent = msg;
            if (msg) { el.classList.add('is-invalid'); valid = false; }
            else el.classList.remove('is-invalid');
        });
        return valid;
    }
};

// ── OTP INPUT HANDLER ───────────────────────────────
const OTPInput = {
    init(containerId) {
        const container = document.getElementById(containerId);
        if (!container) return;
        const inputs = container.querySelectorAll('.otp-input');
        inputs.forEach((input, idx) => {
            input.addEventListener('input', (e) => {
                e.target.value = e.target.value.slice(-1);
                if (e.target.value && inputs[idx + 1]) inputs[idx + 1].focus();
            });
            input.addEventListener('keydown', (e) => {
                if (e.key === 'Backspace' && !e.target.value && inputs[idx - 1]) {
                    inputs[idx - 1].focus();
                }
            });
            input.addEventListener('paste', (e) => {
                e.preventDefault();
                const text = (e.clipboardData || window.clipboardData).getData('text').slice(0, 6);
                [...text].forEach((char, i) => { if (inputs[i]) inputs[i].value = char; });
                if (inputs[Math.min(text.length, 5)]) inputs[Math.min(text.length, 5)].focus();
            });
        });
    },
    getValue(containerId) {
        const container = document.getElementById(containerId);
        if (!container) return '';
        return [...container.querySelectorAll('.otp-input')].map(i => i.value).join('');
    }
};

// ── PASSWORD TOGGLE ─────────────────────────────────
function initPasswordToggles() {
    document.querySelectorAll('.toggle-password').forEach(btn => {
        btn.addEventListener('click', () => {
            const input = btn.closest('.input-group').querySelector('input');
            if (!input) return;
            const show = input.type === 'password';
            input.type = show ? 'text' : 'password';
            btn.textContent = show ? '🙈' : '👁️';
        });
    });
}

// ── PARTICLES ───────────────────────────────────────
function initParticles(containerId = 'particles') {
    const container = document.getElementById(containerId);
    if (!container) return;
    const count = 20;
    for (let i = 0; i < count; i++) {
        const p = document.createElement('div');
        p.className = 'particle';
        p.style.left = Math.random() * 100 + '%';
        p.style.setProperty('--dur', (15 + Math.random() * 20) + 's');
        p.style.setProperty('--delay', -(Math.random() * 20) + 's');
        p.style.width = p.style.height = (1 + Math.random() * 3) + 'px';
        container.appendChild(p);
    }
}

// ── CREDIT CARD 3D EFFECT ───────────────────────────
function initCard3D() {
    document.querySelectorAll('.credit-card-display').forEach(card => {
        card.addEventListener('mousemove', (e) => {
            const rect = card.getBoundingClientRect();
            const x = ((e.clientX - rect.left) / rect.width - 0.5) * 20;
            const y = ((e.clientY - rect.top) / rect.height - 0.5) * -20;
            card.style.transform = `perspective(1000px) rotateY(${x}deg) rotateX(${y}deg) scale(1.03)`;
        });
        card.addEventListener('mouseleave', () => {
            card.style.transform = '';
        });
    });
}

// ── NOTIFICATIONS POLLING ───────────────────────────
const NotificationPoller = {
    interval: null,
    start(url, dotEl, badgeEl) {
        this.fetch(url, dotEl, badgeEl);
        this.interval = setInterval(() => this.fetch(url, dotEl, badgeEl), 30000);
    },
    async fetch(url, dotEl, badgeEl) {
        try {
            const data = await Ajax.get(url);
            if (data.count > 0) {
                if (dotEl) dotEl.style.display = 'block';
                if (badgeEl) badgeEl.textContent = data.count;
            } else {
                if (dotEl) dotEl.style.display = 'none';
            }
        } catch(e) {}
    }
};

// ── CHART HELPERS ────────────────────────────────────
function createGradient(ctx, color1, color2) {
    const grad = ctx.createLinearGradient(0, 0, 0, 300);
    grad.addColorStop(0, color1);
    grad.addColorStop(1, color2);
    return grad;
}

// ── PROGRESS BAR ANIMATION ───────────────────────────
function animateProgressBars() {
    document.querySelectorAll('.progress-bar-fill').forEach(bar => {
        const target = bar.dataset.width || '0';
        setTimeout(() => { bar.style.width = target + '%'; }, 100);
    });
}

// ── DATA TABLE SEARCH ────────────────────────────────
function initTableSearch(inputId, tableId) {
    const input = document.getElementById(inputId);
    const table = document.getElementById(tableId);
    if (!input || !table) return;
    input.addEventListener('input', () => {
        const q = input.value.toLowerCase();
        table.querySelectorAll('tbody tr').forEach(row => {
            row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
        });
    });
}

// ── CONFIRM DELETE ───────────────────────────────────
function confirmAction(msg, callback) {
    if (confirm(msg || 'Are you sure?')) callback();
}

// ── TOP LOADING BAR ──────────────────────────────────
const LoadingBar = {
    el: null,
    init() {
        this.el = document.createElement('div');
        Object.assign(this.el.style, {
            position: 'fixed', top: '0', left: '0', height: '3px',
            background: 'linear-gradient(90deg,#2563EB,#7C3AED,#06B6D4)',
            width: '0', zIndex: '99999', transition: 'width 0.3s ease',
            boxShadow: '0 0 10px rgba(37,99,235,0.7)'
        });
        document.body.appendChild(this.el);
    },
    start() {
        if (!this.el) this.init();
        this.el.style.width = '70%';
        this.el.style.opacity = '1';
    },
    done() {
        if (!this.el) return;
        this.el.style.width = '100%';
        setTimeout(() => {
            this.el.style.opacity = '0';
            setTimeout(() => { this.el.style.width = '0'; }, 300);
        }, 200);
    }
};

// ── INITIALIZE ───────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
    ThemeManager.init();
    Toast.init();
    Sidebar.init();
    Counter.initAll();
    Modal.init();
    initPasswordToggles();
    initParticles();
    initCard3D();
    animateProgressBars();
    initTableSearch('table-search', 'main-table');

    // Theme toggle buttons
    document.querySelectorAll('.theme-toggle').forEach(btn => {
        btn.addEventListener('click', ThemeManager.toggle.bind(ThemeManager));
    });

    // Handle AJAX form flash messages from PHP session
    const flashEl = document.getElementById('flash-message');
    if (flashEl) {
        const type = flashEl.dataset.type || 'info';
        const msg  = flashEl.dataset.msg;
        if (msg) Toast[type]?.(msg) || Toast.info(msg);
        flashEl.remove();
    }

    // Page transition
    LoadingBar.done();
    document.querySelectorAll('a:not([target="_blank"]):not([href^="#"]):not([href^="javascript"])').forEach(link => {
        link.addEventListener('click', (e) => {
            const href = link.getAttribute('href');
            if (href && !href.startsWith('#') && !e.ctrlKey && !e.metaKey) {
                LoadingBar.start();
            }
        });
    });
});

// Expose globals
window.Toast    = Toast;
window.Modal    = Modal;
window.Ajax     = Ajax;
window.Validate = Validate;
window.OTPInput = OTPInput;
window.Counter  = Counter;
window.NotificationPoller = NotificationPoller;
window.LoadingBar = LoadingBar;
window.confirmAction = confirmAction;
window.initTableSearch = initTableSearch;
