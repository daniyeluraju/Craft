<?php
/**
 * User Dashboard Layout Helper
 * Secure Credit Card Management System
 */
require_once '../includes/auth.php';
require_once '../includes/functions.php';
requireUser();

$user  = getCurrentUser();
if (!$user) { session_destroy(); header('Location: ../public/login.php'); exit; }

$card  = getUserCard($user['id']);
$notifCount = getUnreadNotificationCount($user['id']);

// Current page for sidebar active state
$currentPage = basename($_SERVER['PHP_SELF']);

function renderSidebar(array $user, int $notifCount, string $currentPage): void { ?>
<div class="sidebar-overlay"></div>
<aside class="sidebar">
    <div class="sidebar-header">
        <a href="dashboard.php" class="sidebar-brand">
            <div class="logo-icon">💳</div>
            <span>CreditGuard</span>
        </a>
    </div>
    <div class="sidebar-user">
        <div class="sidebar-avatar"><?= strtoupper(substr($user['name'], 0, 1)) ?></div>
        <div class="sidebar-user-info">
            <div class="name"><?= htmlspecialchars($user['name']) ?></div>
            <div class="role">User Account</div>
        </div>
    </div>
    <nav class="sidebar-nav">
        <div class="nav-section-title">Overview</div>
        <a href="dashboard.php" class="<?= $currentPage === 'dashboard.php' ? 'active' : '' ?>">
            <span class="nav-icon">📊</span> Dashboard
        </a>

        <div class="nav-section-title">Cards &amp; Transactions</div>
        <a href="cards.php" class="<?= $currentPage === 'cards.php' ? 'active' : '' ?>">
            <span class="nav-icon">💳</span> My Credit Card
        </a>
        <a href="spend.php" class="<?= $currentPage === 'spend.php' ? 'active' : '' ?>">
            <span class="nav-icon">🛍️</span> Make a Purchase
            <?php if ($currentPage !== 'spend.php'): ?>
            <span style="font-size:0.58rem;background:var(--primary);color:#fff;border-radius:4px;padding:1px 5px;margin-left:2px;vertical-align:middle;line-height:1;">NEW</span>
            <?php endif; ?>
        </a>
        <a href="transactions.php" class="<?= $currentPage === 'transactions.php' ? 'active' : '' ?>">
            <span class="nav-icon">📋</span> Transactions
        </a>

        <div class="nav-section-title">Billing</div>
        <a href="bills.php" class="<?= $currentPage === 'bills.php' ? 'active' : '' ?>">
            <span class="nav-icon">🧾</span> Bills & Payments
        </a>
        <a href="pay.php" class="<?= $currentPage === 'pay.php' ? 'active' : '' ?>">
            <span class="nav-icon">💸</span> Pay Bill
        </a>
        <a href="statement.php" class="<?= $currentPage === 'statement.php' ? 'active' : '' ?>">
            <span class="nav-icon">📄</span> Statement
        </a>

        <div class="nav-section-title">Account</div>
        <a href="notifications.php" class="<?= $currentPage === 'notifications.php' ? 'active' : '' ?>">
            <span class="nav-icon">🔔</span> Notifications
            <?php if ($notifCount > 0): ?><span class="badge-count"><?= $notifCount ?></span><?php endif; ?>
        </a>
        <a href="complaints.php" class="<?= $currentPage === 'complaints.php' ? 'active' : '' ?>">
            <span class="nav-icon">📝</span> Complaints
        </a>
        <a href="profile.php" class="<?= $currentPage === 'profile.php' ? 'active' : '' ?>">
            <span class="nav-icon">👤</span> Profile
        </a>
    </nav>
    <div class="sidebar-footer">
        <a href="../logout.php" class="btn btn-ghost btn-sm btn-block" style="color:var(--danger);">
            🚪 Logout
        </a>
    </div>
</aside>
<?php }

function renderTopbar(array $user, int $notifCount, string $pageTitle): void { ?>
<div class="topbar">
    <div class="topbar-left">
        <button class="hamburger" aria-label="Toggle menu">☰</button>
        <span class="page-title"><?= htmlspecialchars($pageTitle) ?></span>
    </div>
    <div class="topbar-right">
        <button class="theme-toggle" title="Toggle Theme"><span class="theme-icon">☀️</span></button>
        <a href="notifications.php" class="notif-btn" title="Notifications">
            🔔 <?php if ($notifCount > 0): ?><span class="notif-dot"></span><?php endif; ?>
        </a>
        <div style="display:flex;align-items:center;gap:8px;background:var(--glass);border:1px solid var(--border);border-radius:12px;padding:6px 12px;">
            <div style="width:28px;height:28px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--info));display:flex;align-items:center;justify-content:center;font-weight:700;font-size:0.8rem;color:white;">
                <?= strtoupper(substr($user['name'], 0, 1)) ?>
            </div>
            <span style="font-size:0.85rem;font-weight:600;"><?= htmlspecialchars(explode(' ', $user['name'])[0]) ?></span>
        </div>
    </div>
</div>
<?php }
