<?php
/**
 * User Notifications Page
 * Secure Credit Card Management System
 */
require_once 'layout.php';

// Mark all as read
if (isset($_GET['mark_all'])) {
    $pdo->prepare("UPDATE notifications SET is_read=1 WHERE user_id=?")->execute([$user['id']]);
    header('Location: notifications.php');
    exit;
}

// Mark single as read
if (isset($_GET['mark'])) {
    $pdo->prepare("UPDATE notifications SET is_read=1 WHERE id=? AND user_id=?")->execute([(int)$_GET['mark'], $user['id']]);
    header('Location: notifications.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC");
$stmt->execute([$user['id']]);
$notifications = $stmt->fetchAll();
$unread = array_filter($notifications, fn($n) => !$n['is_read']);
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Notifications — CreditGuard</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php renderSidebar($user, $notifCount, $currentPage); ?>
<div class="main-wrapper">
<?php renderTopbar($user, $notifCount, '🔔 Notifications'); ?>
<div class="content-area">

<div class="card">
    <div class="card-header">
        <div style="display:flex;align-items:center;gap:12px;">
            <h3 class="card-title">Notifications</h3>
            <?php if (count($unread)): ?>
            <span class="badge badge-danger"><?= count($unread) ?> Unread</span>
            <?php endif; ?>
        </div>
        <?php if (count($unread)): ?>
        <a href="?mark_all=1" class="btn btn-ghost btn-sm">✅ Mark All Read</a>
        <?php endif; ?>
    </div>

    <?php if (!empty($notifications)): ?>
    <div>
        <?php foreach($notifications as $notif):
            $icons = ['transaction'=>'💳','payment'=>'💰','alert'=>'⚠️','info'=>'ℹ️','warning'=>'⚠️'];
            $colors = ['transaction'=>'var(--primary)','payment'=>'var(--success)','alert'=>'var(--danger)','info'=>'var(--info)','warning'=>'var(--warning)'];
            $icon  = $icons[$notif['type']] ?? 'ℹ️';
            $color = $colors[$notif['type']] ?? 'var(--info)';
        ?>
        <div style="display:flex;align-items:flex-start;gap:16px;padding:18px 24px;border-bottom:1px solid var(--border);<?= !$notif['is_read'] ? 'background:rgba(37,99,235,0.04);' : '' ?>transition:background 0.2s;"
             onmouseover="this.style.background='var(--glass)'" onmouseout="this.style.background='<?= !$notif['is_read'] ? 'rgba(37,99,235,0.04)' : 'transparent' ?>'">
            <!-- Icon -->
            <div style="width:44px;height:44px;border-radius:12px;background:<?= $color ?>22;display:flex;align-items:center;justify-content:center;font-size:1.2rem;flex-shrink:0;border:1px solid <?= $color ?>33;">
                <?= $icon ?>
            </div>
            <!-- Content -->
            <div style="flex:1;min-width:0;">
                <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;">
                    <span style="font-weight:700;font-size:0.9rem;"><?= htmlspecialchars($notif['title']) ?></span>
                    <?php if (!$notif['is_read']): ?>
                    <span style="width:7px;height:7px;background:var(--primary);border-radius:50%;flex-shrink:0;"></span>
                    <?php endif; ?>
                </div>
                <p style="font-size:0.85rem;color:var(--text-muted);margin-bottom:6px;line-height:1.5;"><?= htmlspecialchars($notif['message']) ?></p>
                <span style="font-size:0.75rem;color:var(--text-muted);"><?= timeAgo($notif['created_at']) ?></span>
            </div>
            <!-- Actions -->
            <div style="display:flex;gap:6px;flex-shrink:0;">
                <?php if (!$notif['is_read']): ?>
                <a href="?mark=<?= $notif['id'] ?>" class="btn btn-ghost btn-sm" title="Mark as read">✅</a>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div class="card-body">
        <div class="empty-state">
            <div class="empty-icon">🔔</div>
            <div class="empty-title">No Notifications</div>
            <div class="empty-desc">You're all caught up! Check back later for updates.</div>
        </div>
    </div>
    <?php endif; ?>
</div>

</div></div>
<div id="toast-container"></div>
<script src="../assets/js/main.js"></script>
</body>
</html>
