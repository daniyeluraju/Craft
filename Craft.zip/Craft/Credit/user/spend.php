<?php
/**
 * Simulate Spending / Make a Purchase
 * Secure Credit Card Management System
 */
require_once 'layout.php';

$card = getUserCard($user['id']);
$msg  = null;

// Categories with icons
$categories = [
    'shopping'      => ['🛍️',  'Shopping',         'Clothes, Electronics, Online'],
    'food'          => ['🍔',  'Food & Dining',     'Restaurants, Cafes, Zomato'],
    'travel'        => ['✈️',  'Travel',            'Flights, Hotels, Cabs'],
    'entertainment' => ['🎬',  'Entertainment',     'Movies, OTT, Events'],
    'fuel'          => ['⛽',  'Fuel',              'Petrol, Diesel, CNG'],
    'health'        => ['🏥',  'Health & Medical',  'Pharmacy, Hospital, Labs'],
    'education'     => ['📚',  'Education',         'Fees, Books, Courses'],
    'utilities'     => ['💡',  'Utilities',         'Electricity, Water, Internet'],
    'other'         => ['💳',  'Other',             'Miscellaneous purchases'],
];

// Quick spend merchants per category
$merchants = [
    'shopping'      => ['Amazon', 'Flipkart', 'Myntra', 'Nykaa', 'Meesho'],
    'food'          => ['Zomato', 'Swiggy', 'Dominos', "McDonald's", 'KFC'],
    'travel'        => ['MakeMyTrip', 'IRCTC', 'Uber', 'Ola', 'IndiGo'],
    'entertainment' => ['Netflix', 'Hotstar', 'BookMyShow', 'Spotify', 'Amazon Prime'],
    'fuel'          => ['Indian Oil', 'BPCL', 'HP Petrol', 'Shell', 'Reliance Petrol'],
    'health'        => ['Apollo Pharmacy', 'MedPlus', 'Practo', 'Thyrocare', '1mg'],
    'education'     => ['Coursera', 'Udemy', 'BYJU\'S', 'Unacademy', 'Khan Academy'],
    'utilities'     => ['BESCOM', 'Airtel', 'Jio', 'ACT Fibernet', 'BWSSB'],
    'other'         => ['General Purchase', 'ATM Withdrawal', 'POS Terminal', 'Online Purchase'],
];

// Handle POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['make_purchase'])) {
    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
        $msg = ['type' => 'error', 'text' => 'Invalid CSRF token. Please try again.'];
    } elseif (!$card) {
        $msg = ['type' => 'error', 'text' => 'No credit card assigned to your account.'];
    } elseif ($card['status'] !== 'active') {
        $msg = ['type' => 'error', 'text' => 'Your card is ' . $card['status'] . '. Contact support.'];
    } else {
        $amount      = (float)($_POST['amount'] ?? 0);
        $description = sanitize($_POST['description'] ?? '');
        $category    = array_key_exists($_POST['category'] ?? '', $categories) ? $_POST['category'] : 'other';
        $merchant    = sanitize($_POST['merchant'] ?? '');

        if ($amount <= 0) {
            $msg = ['type' => 'error', 'text' => 'Please enter a valid amount greater than ₹0.'];
        } elseif ($amount > $card['available_balance']) {
            $msg = ['type' => 'error', 'text' => 'Insufficient credit limit. Available: ' . formatCurrency($card['available_balance'])];
        } elseif (empty($description)) {
            $msg = ['type' => 'error', 'text' => 'Please enter a description for the purchase.'];
        } else {
            $ref = generateReference('TXN');
            $isSuspicious = ($amount > ($card['credit_limit'] * 0.5)) ? 1 : 0; // flag if > 50% of limit in one go

            // Insert transaction
            $pdo->prepare("
                INSERT INTO transactions 
                (card_id, user_id, transaction_type, amount, description, merchant, category, status, reference_no, is_suspicious)
                VALUES (?, ?, 'debit', ?, ?, ?, ?, ?, ?, ?)
            ")->execute([
                $card['id'],
                $user['id'],
                $amount,
                $description,
                $merchant,
                $category,
                $isSuspicious ? 'flagged' : 'success',
                $ref,
                $isSuspicious
            ]);

            // Update card balances
            $pdo->prepare("
                UPDATE credit_cards 
                SET available_balance = available_balance - ?,
                    outstanding_balance = outstanding_balance + ?
                WHERE id = ?
            ")->execute([$amount, $amount, $card['id']]);

            // Notification
            $flagNote = $isSuspicious ? ' ⚠️ Transaction flagged for review.' : '';
            createNotification(
                $user['id'],
                '💳 Purchase Successful',
                "₹" . number_format($amount, 2) . " spent at " . ($merchant ?: $description) . ". Ref: $ref.$flagNote",
                $isSuspicious ? 'alert' : 'transaction'
            );

            // Refresh card data
            $card = getUserCard($user['id']);

            $msg = [
                'type'   => 'success',
                'text'   => "✅ Purchase of " . formatCurrency($amount) . " at " . htmlspecialchars($merchant ?: $description) . " successful!",
                'ref'    => $ref,
                'amount' => $amount,
                'flagged'=> $isSuspicious,
            ];
        }
    }
}

$csrf = generateCSRF();
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Make a Purchase — CreditGuard</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php renderSidebar($user, $notifCount, $currentPage); ?>
<div class="main-wrapper">
<?php renderTopbar($user, $notifCount, '🛍️ Make a Purchase'); ?>
<div class="content-area">

<?php if (!$card): ?>
<!-- No card assigned -->
<div class="card" style="text-align:center;padding:60px;">
    <div style="font-size:5rem;margin-bottom:16px;">💳</div>
    <h2 style="margin-bottom:8px;">No Credit Card Assigned</h2>
    <p style="color:var(--text-muted);">Please contact admin to assign a credit card to your account.</p>
    <a href="complaints.php" class="btn btn-primary" style="margin-top:20px;">📝 Contact Support</a>
</div>
<?php elseif ($card['status'] !== 'active'): ?>
<!-- Card blocked/expired -->
<div class="card" style="text-align:center;padding:60px;background:rgba(220,38,38,0.05);border-color:rgba(220,38,38,0.3);">
    <div style="font-size:5rem;margin-bottom:16px;">⛔</div>
    <h2 style="margin-bottom:8px;">Card <?= ucfirst($card['status']) ?></h2>
    <p style="color:var(--text-muted);">Your card is currently <?= $card['status'] ?>. Please contact support.</p>
</div>
<?php else: ?>

<!-- Success / Error Message -->
<?php if ($msg): ?>
<?php if ($msg['type'] === 'success'): ?>
<div style="background:rgba(16,185,129,0.1);border:1px solid rgba(16,185,129,0.3);border-radius:16px;padding:20px 24px;margin-bottom:24px;display:flex;align-items:flex-start;gap:16px;">
    <div style="font-size:2rem;flex-shrink:0;">✅</div>
    <div style="flex:1;">
        <div style="font-weight:700;font-size:1rem;color:#34D399;margin-bottom:4px;"><?= $msg['text'] ?></div>
        <div style="font-size:0.82rem;color:var(--text-muted);">Reference: <code style="background:rgba(255,255,255,0.05);padding:2px 6px;border-radius:4px;"><?= $msg['ref'] ?></code></div>
        <?php if ($msg['flagged']): ?>
        <div style="margin-top:8px;color:var(--warning);font-size:0.82rem;">⚠️ Large transaction flagged for security review.</div>
        <?php endif; ?>
    </div>
    <div style="text-align:right;flex-shrink:0;">
        <div style="font-size:1.5rem;font-weight:900;color:#34D399;">-<?= formatCurrency($msg['amount']) ?></div>
        <div style="font-size:0.75rem;color:var(--text-muted);">from credit limit</div>
    </div>
</div>
<?php else: ?>
<div style="background:rgba(220,38,38,0.1);border:1px solid rgba(220,38,38,0.3);border-radius:12px;padding:14px 20px;margin-bottom:24px;color:#F87171;display:flex;align-items:center;gap:10px;">
    <span>❌</span> <?= $msg['text'] ?>
</div>
<?php endif; ?>
<?php endif; ?>

<!-- Credit Limit Overview -->
<div class="grid-3 mb-3">
    <div class="stat-card" style="--accent:var(--primary);">
        <div class="stat-icon" style="background:rgba(37,99,235,0.15);">💰</div>
        <div class="stat-info">
            <div class="stat-label">Credit Limit</div>
            <div class="stat-value"><?= formatCurrency($card['credit_limit']) ?></div>
        </div>
    </div>
    <div class="stat-card" style="--accent:var(--success);">
        <div class="stat-icon" style="background:rgba(16,185,129,0.15);">✅</div>
        <div class="stat-info">
            <div class="stat-label">Available to Spend</div>
            <div class="stat-value" style="color:var(--success);"><?= formatCurrency($card['available_balance']) ?></div>
        </div>
    </div>
    <div class="stat-card" style="--accent:var(--danger);">
        <div class="stat-icon" style="background:rgba(220,38,38,0.15);">🧾</div>
        <div class="stat-info">
            <div class="stat-label">Outstanding Balance</div>
            <div class="stat-value" style="color:var(--danger);"><?= formatCurrency($card['outstanding_balance']) ?></div>
        </div>
    </div>
</div>

<!-- Utilization bar -->
<?php $util = $card['credit_limit'] > 0 ? min(round(($card['outstanding_balance'] / $card['credit_limit']) * 100), 100) : 0; ?>
<div class="card mb-3" style="padding:0;">
    <div class="card-body" style="padding:16px 20px;">
        <div style="display:flex;justify-content:space-between;margin-bottom:8px;font-size:0.85rem;">
            <span style="font-weight:600;">Credit Utilization</span>
            <span style="color:var(--text-muted);"><?= formatCurrency($card['outstanding_balance']) ?> used of <?= formatCurrency($card['credit_limit']) ?> (<?= $util ?>%)</span>
        </div>
        <div class="progress-bar-wrap" style="height:10px;">
            <div class="progress-bar-fill" data-width="<?= $util ?>"
                 style="background:<?= $util > 80 ? 'var(--danger)' : ($util > 50 ? 'var(--warning)' : 'linear-gradient(90deg,var(--primary),var(--info))') ?>;width:<?= $util ?>%;"></div>
        </div>
    </div>
</div>

<div class="grid-2" style="align-items:start;">

    <!-- Purchase Form -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">🛍️ New Purchase</h3>
            <span class="badge badge-success">Card Active</span>
        </div>
        <div class="card-body">
            <form method="POST" id="spend-form">
                <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
                <input type="hidden" name="make_purchase" value="1">

                <!-- Category Grid -->
                <div class="form-group">
                    <label class="form-label">Spending Category</label>
                    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;" id="cat-grid">
                        <?php foreach($categories as $key => [$icon, $label, $sub]): ?>
                        <label style="cursor:pointer;">
                            <input type="radio" name="category" value="<?= $key ?>" style="display:none;" <?= $key === 'shopping' ? 'checked' : '' ?>>
                            <div class="cat-card <?= $key === 'shopping' ? 'cat-active' : '' ?>"
                                 id="cat-<?= $key ?>"
                                 onclick="selectCategory('<?= $key ?>')"
                                 title="<?= $sub ?>">
                                <div style="font-size:1.4rem;"><?= $icon ?></div>
                                <div style="font-size:0.72rem;font-weight:600;margin-top:4px;line-height:1.2;"><?= $label ?></div>
                            </div>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Merchant (quick select) -->
                <div class="form-group">
                    <label class="form-label">Merchant / Store</label>
                    <div id="merchant-pills" style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px;">
                        <?php foreach($merchants['shopping'] as $m): ?>
                        <button type="button" class="merchant-pill" onclick="setMerchant('<?= $m ?>')"><?= $m ?></button>
                        <?php endforeach; ?>
                    </div>
                    <input type="text" name="merchant" id="merchant-input" class="form-control"
                           placeholder="e.g. Amazon, Swiggy, or type custom...">
                </div>

                <!-- Description -->
                <div class="form-group">
                    <label class="form-label">Description *</label>
                    <input type="text" name="description" id="desc-input" class="form-control"
                           placeholder="e.g. iPhone 15 purchase, Monthly groceries..." required maxlength="200">
                </div>

                <!-- Amount -->
                <div class="form-group">
                    <label class="form-label">Amount (₹) *</label>

                    <!-- Quick amounts -->
                    <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px;">
                        <?php foreach([500, 1000, 2000, 5000, 10000] as $qa): ?>
                        <?php if ($qa <= $card['available_balance']): ?>
                        <button type="button" class="btn btn-ghost btn-sm" onclick="document.getElementById('amount-input').value='<?= $qa ?>';updatePreview()">
                            ₹<?= number_format($qa) ?>
                        </button>
                        <?php endif; ?>
                        <?php endforeach; ?>
                    </div>

                    <div class="input-group" style="position:relative;">
                        <span style="position:absolute;left:14px;top:50%;transform:translateY(-50%);color:var(--text-muted);font-weight:700;font-size:1rem;">₹</span>
                        <input type="number" name="amount" id="amount-input" class="form-control"
                               style="padding-left:32px;"
                               placeholder="0.00" min="1" max="<?= $card['available_balance'] ?>"
                               step="0.01" required oninput="updatePreview()">
                    </div>
                    <p class="form-hint">Max available: <strong><?= formatCurrency($card['available_balance']) ?></strong></p>
                </div>

                <!-- Live Preview -->
                <div id="spend-preview" style="display:none;background:rgba(37,99,235,0.08);border:1px solid rgba(37,99,235,0.2);border-radius:12px;padding:16px;margin-bottom:20px;">
                    <div style="font-size:0.78rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:10px;">Transaction Preview</div>
                    <div style="display:flex;justify-content:space-between;margin-bottom:6px;font-size:0.88rem;">
                        <span style="color:var(--text-muted);">Amount</span>
                        <span id="preview-amt" style="font-weight:700;color:var(--danger);"></span>
                    </div>
                    <div style="display:flex;justify-content:space-between;margin-bottom:6px;font-size:0.88rem;">
                        <span style="color:var(--text-muted);">Available After</span>
                        <span id="preview-avail" style="font-weight:700;color:var(--success);"></span>
                    </div>
                    <div style="display:flex;justify-content:space-between;font-size:0.88rem;">
                        <span style="color:var(--text-muted);">Outstanding After</span>
                        <span id="preview-outst" style="font-weight:700;color:var(--warning);"></span>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary btn-block" id="spend-btn">
                    🛍️ Confirm Purchase
                </button>

                <p style="text-align:center;font-size:0.78rem;color:var(--text-muted);margin-top:12px;">
                    🔒 Securely debited from your credit limit
                </p>
            </form>
        </div>
    </div>

    <!-- Recent purchases + Tips -->
    <div style="display:grid;gap:16px;align-content:start;">

        <!-- Recent 5 purchases -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">🕐 Recent Purchases</h3>
                <a href="transactions.php" class="btn btn-ghost btn-sm">View All →</a>
            </div>
            <?php
            $recent = $pdo->prepare("
                SELECT * FROM transactions 
                WHERE user_id=? AND transaction_type='debit' 
                ORDER BY transaction_date DESC LIMIT 6
            ");
            $recent->execute([$user['id']]);
            $recentTxns = $recent->fetchAll();
            ?>
            <?php if (!empty($recentTxns)): ?>
            <div>
                <?php foreach($recentTxns as $txn): ?>
                <div style="display:flex;align-items:center;gap:12px;padding:12px 20px;border-bottom:1px solid var(--border);">
                    <div style="width:36px;height:36px;border-radius:10px;background:<?= $txn['status']==='flagged'?'rgba(220,38,38,0.12)':'rgba(37,99,235,0.1)' ?>;display:flex;align-items:center;justify-content:center;font-size:1rem;flex-shrink:0;">
                        <?= getCategoryIcon($txn['category']) ?>
                    </div>
                    <div style="flex:1;min-width:0;">
                        <div style="font-weight:600;font-size:0.85rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= htmlspecialchars($txn['description']) ?></div>
                        <div style="font-size:0.74rem;color:var(--text-muted);"><?= timeAgo($txn['transaction_date']) ?> · <?= ucfirst($txn['category']) ?></div>
                    </div>
                    <div style="text-align:right;flex-shrink:0;">
                        <div style="font-weight:800;font-size:0.9rem;color:<?= $txn['status']==='flagged'?'var(--danger)':'var(--text)' ?>;">
                            −<?= formatCurrency($txn['amount']) ?>
                        </div>
                        <?php if ($txn['status'] === 'flagged'): ?>
                        <span style="font-size:0.65rem;color:var(--danger);">⚠️ Flagged</span>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="card-body">
                <div class="empty-state">
                    <div class="empty-icon">🛍️</div>
                    <div class="empty-title">No purchases yet</div>
                    <div class="empty-desc">Make your first purchase using the form.</div>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Spending tips -->
        <div class="card">
            <div class="card-body">
                <h4 style="margin-bottom:14px;">💡 Smart Spending Tips</h4>
                <?php
                $tips = [
                    ['📊', 'Keep utilization below 30% for a healthy credit score.'],
                    ['💸', 'Pay full outstanding balance each month to avoid interest.'],
                    ['⚠️', 'Transactions above 50% of your limit are flagged for security.'],
                    ['🏆', 'On-time payments improve your credit score significantly.'],
                    ['🔔', 'You get instant notifications for every purchase.'],
                ];
                foreach($tips as $t): ?>
                <div style="display:flex;gap:10px;margin-bottom:10px;font-size:0.82rem;">
                    <span style="flex-shrink:0;font-size:1rem;"><?= $t[0] ?></span>
                    <span style="color:var(--text-muted);line-height:1.5;"><?= $t[1] ?></span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<?php endif; ?>

</div><!-- /content-area -->
</div><!-- /main-wrapper -->
<div id="toast-container"></div>

<style>
.cat-card {
    border: 1.5px solid var(--border);
    border-radius: 12px;
    padding: 10px 6px;
    text-align: center;
    transition: all 0.2s;
    background: var(--glass);
    cursor: pointer;
}
.cat-card:hover { border-color: var(--primary); background: rgba(37,99,235,0.08); }
.cat-active { border-color: var(--primary) !important; background: rgba(37,99,235,0.15) !important; box-shadow: 0 0 0 3px rgba(37,99,235,0.15); }

.merchant-pill {
    background: var(--glass);
    border: 1px solid var(--border);
    border-radius: 20px;
    padding: 4px 12px;
    font-size: 0.78rem;
    cursor: pointer;
    color: var(--text);
    transition: all 0.2s;
}
.merchant-pill:hover { border-color: var(--primary); color: var(--primary-light); background: rgba(37,99,235,0.08); }
.merchant-pill.active { border-color: var(--primary); background: rgba(37,99,235,0.2); color: var(--primary-light); }
</style>

<script src="../assets/js/main.js"></script>
<script>
const availBal   = <?= $card ? (float)$card['available_balance'] : 0 ?>;
const outstandBal = <?= $card ? (float)$card['outstanding_balance'] : 0 ?>;

// Merchant data
const merchantData = <?= json_encode($merchants) ?>;

// Format currency (INR)
function fmt(v) {
    return '₹' + parseFloat(v).toLocaleString('en-IN', {minimumFractionDigits:2, maximumFractionDigits:2});
}

// Select category
let activeCategory = 'shopping';
function selectCategory(key) {
    activeCategory = key;
    // Update UI
    document.querySelectorAll('.cat-card').forEach(el => el.classList.remove('cat-active'));
    document.getElementById('cat-' + key).classList.add('cat-active');
    document.querySelector(`input[name=category][value="${key}"]`).checked = true;

    // Update merchant pills
    const pills = merchantData[key] || [];
    const pillsDiv = document.getElementById('merchant-pills');
    pillsDiv.innerHTML = pills.map(m =>
        `<button type="button" class="merchant-pill" onclick="setMerchant('${m}')">${m}</button>`
    ).join('');

    // Update description placeholder
    const descs = {
        shopping: 'e.g. iPhone 15, New clothes, Online order',
        food: 'e.g. Lunch at Zomato, Dinner with family',
        travel: 'e.g. Flight to Delhi, Hotel booking',
        entertainment: 'e.g. Netflix subscription, Movie tickets',
        fuel: 'e.g. Petrol refill, CNG top-up',
        health: 'e.g. Medicines, Doctor consultation',
        education: 'e.g. Course fee, Study materials',
        utilities: 'e.g. Electricity bill, Internet recharge',
        other: 'e.g. Miscellaneous purchase'
    };
    document.getElementById('desc-input').placeholder = descs[key] || 'Description...';
}

// Set merchant
function setMerchant(name) {
    document.getElementById('merchant-input').value = name;
    // Highlight active pill
    document.querySelectorAll('.merchant-pill').forEach(p => p.classList.remove('active'));
    event.target.classList.add('active');
    // Auto-fill description if empty
    const desc = document.getElementById('desc-input');
    if (!desc.value) desc.value = 'Purchase at ' + name;
}

// Live preview
function updatePreview() {
    const amount = parseFloat(document.getElementById('amount-input').value) || 0;
    const preview = document.getElementById('spend-preview');
    if (amount > 0) {
        preview.style.display = 'block';
        document.getElementById('preview-amt').textContent   = '-' + fmt(amount);
        document.getElementById('preview-avail').textContent = fmt(Math.max(0, availBal - amount));
        document.getElementById('preview-outst').textContent = fmt(outstandBal + amount);
    } else {
        preview.style.display = 'none';
    }
}

// Form submit loading state
document.getElementById('spend-form').addEventListener('submit', function(e) {
    const amount = parseFloat(document.getElementById('amount-input').value) || 0;
    if (amount <= 0) {
        e.preventDefault();
        Toast.error('Invalid Amount', 'Please enter a valid purchase amount.');
        return;
    }
    if (amount > availBal) {
        e.preventDefault();
        Toast.error('Insufficient Balance', 'Amount exceeds your available credit limit.');
        return;
    }
    const btn = document.getElementById('spend-btn');
    btn.innerHTML = '<span class="spinner"></span> Processing...';
    btn.disabled = true;
});
</script>
</body>
</html>
