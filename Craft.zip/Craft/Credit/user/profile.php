<?php
/**
 * User Profile Page
 * Secure Credit Card Management System
 */
require_once 'layout.php';

$msg = '';

// Change password
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
        $msg = ['type'=>'error','text'=>'Invalid request.'];
    } else {
        $current = $_POST['current_password'] ?? '';
        $new     = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';

        if (!verifyPassword($current, $user['password'])) {
            $msg = ['type'=>'error','text'=>'Current password is incorrect.'];
        } elseif (strlen($new) < 8) {
            $msg = ['type'=>'error','text'=>'New password must be at least 8 characters.'];
        } elseif ($new !== $confirm) {
            $msg = ['type'=>'error','text'=>'New passwords do not match.'];
        } else {
            $pdo->prepare("UPDATE users SET password=? WHERE id=?")->execute([hashPassword($new), $user['id']]);
            $msg = ['type'=>'success','text'=>'✅ Password changed successfully!'];
            $user = getCurrentUser();
        }
    }
}

// Update profile
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
        $msg = ['type'=>'error','text'=>'Invalid request.'];
    } else {
        $name   = sanitize($_POST['name'] ?? '');
        $mobile = sanitize($_POST['mobile'] ?? '');
        if (empty($name) || empty($mobile)) {
            $msg = ['type'=>'error','text'=>'Name and mobile are required.'];
        } else {
            $pdo->prepare("UPDATE users SET name=?, mobile=? WHERE id=?")->execute([$name, $mobile, $user['id']]);
            $_SESSION['user_name'] = $name;
            $msg = ['type'=>'success','text'=>'✅ Profile updated successfully!'];
            $user = getCurrentUser();
        }
    }
}

$csrf = generateCSRF();
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Profile — CreditGuard</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php renderSidebar($user, $notifCount, $currentPage); ?>
<div class="main-wrapper">
<?php renderTopbar($user, $notifCount, '👤 My Profile'); ?>
<div class="content-area">

<?php if ($msg): ?>
<div style="background:<?= $msg['type']==='success' ? 'rgba(16,185,129,0.1)' : 'rgba(220,38,38,0.1)' ?>;border:1px solid <?= $msg['type']==='success' ? 'rgba(16,185,129,0.3)' : 'rgba(220,38,38,0.3)' ?>;border-radius:12px;padding:12px 16px;margin-bottom:20px;color:<?= $msg['type']==='success' ? '#34D399' : '#F87171' ?>;">
    <?= $msg['text'] ?>
</div>
<?php endif; ?>

<div class="grid-2" style="align-items:start;">
    <!-- Profile Card -->
    <div>
        <div class="card mb-3">
            <div style="text-align:center;padding:40px 24px 24px;background:linear-gradient(135deg,rgba(37,99,235,0.2),rgba(124,58,237,0.1));">
                <div style="width:80px;height:80px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--info));display:flex;align-items:center;justify-content:center;font-size:2rem;font-weight:900;margin:0 auto 16px;color:white;border:4px solid var(--border);">
                    <?= strtoupper(substr($user['name'],0,1)) ?>
                </div>
                <h2 style="font-size:1.2rem;margin-bottom:4px;"><?= htmlspecialchars($user['name']) ?></h2>
                <p style="color:var(--text-muted);font-size:0.88rem;"><?= htmlspecialchars($user['email']) ?></p>
                <span class="badge badge-success" style="margin-top:8px;">Active Account</span>
            </div>
            <div class="card-body">
                <?php
                $info = [
                    ['📧','Email', $user['email']],
                    ['📱','Mobile', $user['mobile']],
                    ['👤','Role', ucfirst($user['role'])],
                    ['📅','Member Since', date('d F Y', strtotime($user['created_at']))],
                ];
                foreach($info as $i): ?>
                <div style="display:flex;align-items:center;gap:12px;padding:12px 0;border-bottom:1px solid var(--border);">
                    <span style="font-size:1.2rem;width:30px;"><?= $i[0] ?></span>
                    <div>
                        <div style="font-size:0.72rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:1px;"><?= $i[1] ?></div>
                        <div style="font-weight:600;font-size:0.88rem;"><?= htmlspecialchars($i[2]) ?></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <div>
        <!-- Update Profile Form -->
        <div class="card mb-3">
            <div class="card-header"><h3 class="card-title">✏️ Update Profile</h3></div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
                    <input type="hidden" name="update_profile" value="1">
                    <div class="form-group">
                        <label class="form-label">Full Name</label>
                        <input type="text" name="name" class="form-control"
                               value="<?= htmlspecialchars($user['name']) ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Mobile Number</label>
                        <input type="tel" name="mobile" class="form-control"
                               value="<?= htmlspecialchars($user['mobile']) ?>" maxlength="10" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Email</label>
                        <input type="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" disabled
                               style="opacity:0.6;cursor:not-allowed;">
                        <p class="form-hint">Email cannot be changed. Contact support for email update requests.</p>
                    </div>
                    <button type="submit" class="btn btn-primary">💾 Save Changes</button>
                </form>
            </div>
        </div>

        <!-- Change Password -->
        <div class="card">
            <div class="card-header"><h3 class="card-title">🔐 Change Password</h3></div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
                    <input type="hidden" name="change_password" value="1">
                    <div class="form-group">
                        <label class="form-label">Current Password</label>
                        <div class="input-group">
                            <input type="password" name="current_password" class="form-control" required>
                            <span class="input-group-icon toggle-password">👁️</span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">New Password</label>
                        <div class="input-group">
                            <input type="password" name="new_password" class="form-control" placeholder="Min 8 characters" required>
                            <span class="input-group-icon toggle-password">👁️</span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Confirm New Password</label>
                        <div class="input-group">
                            <input type="password" name="confirm_password" class="form-control" required>
                            <span class="input-group-icon toggle-password">👁️</span>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-warning">🔐 Update Password</button>
                </form>
            </div>
        </div>
    </div>
</div>

</div></div>
<div id="toast-container"></div>
<script src="../assets/js/main.js"></script>
</body>
</html>
