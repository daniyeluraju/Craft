<?php
/**
 * User Dashboard
 * Secure Credit Card Management System
 */
require_once 'layout.php';

// Gather dashboard data
$card        = getUserCard($user['id']);
$recentTxns  = getUserTransactions($user['id'], 5);
$categoryData = getSpendingByCategory($user['id'], 3);
$monthlyData  = getMonthlySpending($user['id'], 6);
$currentBill  = $card ? getCurrentBill($user['id'], $card['id']) : null;

// Total spending this month
$spendStmt = $pdo->prepare("
    SELECT COALESCE(SUM(amount),0) FROM transactions 
    WHERE user_id=? AND transaction_type='debit' AND status!='failed'
    AND MONTH(transaction_date)=MONTH(NOW()) AND YEAR(transaction_date)=YEAR(NOW())
");
$spendStmt->execute([$user['id']]);
$monthSpend = (float)$spendStmt->fetchColumn();

// Payment history count
$payStmt = $pdo->prepare("SELECT COUNT(*) FROM payments WHERE user_id=? AND status='success'");
$payStmt->execute([$user['id']]);
$payCount = (int)$payStmt->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard — CreditGuard</title>
<link rel="stylesheet" href="../assets/css/style.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
</head>
<body>

<?php renderSidebar($user, $notifCount, $currentPage); ?>

<div class="main-wrapper">
<?php renderTopbar($user, $notifCount, '📊 Dashboard'); ?>

<div class="content-area">

<!-- Welcome Banner -->
<div class="card mb-3" style="background:linear-gradient(135deg,rgba(37,99,235,0.2),rgba(124,58,237,0.15));border-color:rgba(37,99,235,0.3);padding:28px;">
    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:16px;">
        <div>
            <p style="color:var(--text-muted);font-size:0.85rem;margin-bottom:4px;">Good <?= date('H') < 12 ? 'Morning' : (date('H') < 17 ? 'Afternoon' : 'Evening') ?> 👋</p>
            <h2 style="font-size:1.6rem;margin-bottom:6px;"><?= htmlspecialchars($user['name']) ?></h2>
            <p style="color:var(--text-muted);font-size:0.88rem;">Here's your financial summary for <?= date('F Y') ?></p>
        </div>
        <div style="display:flex;gap:12px;flex-wrap:wrap;">
            <a href="spend.php" class="btn btn-primary">🛍️ Spend Now</a>
            <a href="pay.php" class="btn btn-ghost">💸 Pay Bill</a>
            <a href="transactions.php" class="btn btn-ghost">View Transactions</a>
        </div>
    </div>
</div>

<!-- Stat Cards -->
<div class="grid-4 mb-3">
    <div class="stat-card" style="--accent:var(--primary);">
        <div class="stat-icon" style="background:rgba(37,99,235,0.15);">💳</div>
        <div class="stat-info">
            <div class="stat-label">Available Balance</div>
            <div class="stat-value" data-counter="<?= $card ? $card['available_balance'] : 0 ?>" data-prefix="₹"><?= $card ? formatCurrency($card['available_balance']) : '—' ?></div>
            <div class="stat-change stat-up">↑ of ₹<?= $card ? number_format($card['credit_limit']) : 0 ?> limit</div>
        </div>
    </div>
    <div class="stat-card" style="--accent:var(--danger);">
        <div class="stat-icon" style="background:rgba(220,38,38,0.15);">🧾</div>
        <div class="stat-info">
            <div class="stat-label">Outstanding Balance</div>
            <div class="stat-value" style="color:var(--danger);" data-counter="<?= $card ? $card['outstanding_balance'] : 0 ?>" data-prefix="₹"><?= $card ? formatCurrency($card['outstanding_balance']) : '—' ?></div>
            <div class="stat-change"><?= $currentBill ? 'Due: ' . date('d M', strtotime($currentBill['due_date'])) : 'No bill due' ?></div>
        </div>
    </div>
    <div class="stat-card" style="--accent:var(--warning);">
        <div class="stat-icon" style="background:rgba(245,158,11,0.15);">💰</div>
        <div class="stat-info">
            <div class="stat-label">Month Spending</div>
            <div class="stat-value" data-counter="<?= $monthSpend ?>" data-prefix="₹"><?= formatCurrency($monthSpend) ?></div>
            <div class="stat-change"><?= date('F Y') ?></div>
        </div>
    </div>
    <div class="stat-card" style="--accent:var(--success);">
        <div class="stat-icon" style="background:rgba(16,185,129,0.15);">✅</div>
        <div class="stat-info">
            <div class="stat-label">Total Payments</div>
            <div class="stat-value" data-counter="<?= $payCount ?>"><?= $payCount ?></div>
            <div class="stat-change stat-up">Successful payments</div>
        </div>
    </div>
</div>

<!-- Main Grid: Card + Charts -->
<div class="grid-2 mb-3">

    <!-- Credit Card Visual -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">💳 My Credit Card</h3>
            <a href="cards.php" class="btn btn-ghost btn-sm">Details →</a>
        </div>
        <div class="card-body" style="display:flex;flex-direction:column;align-items:center;gap:24px;">
            <?php if ($card): ?>
            <div class="credit-card-display card-gradient-blue" style="width:100%;max-width:340px;">
                <div class="card-chip"></div>
                <div class="card-number-display"><?= formatMaskedCard($card['card_number']) ?></div>
                <div class="card-info-row">
                    <div>
                        <div class="card-label">Card Holder</div>
                        <div class="card-value"><?= htmlspecialchars($card['card_holder']) ?></div>
                    </div>
                    <div>
                        <div class="card-label">Expires</div>
                        <div class="card-value"><?= str_pad($card['expiry_month'],2,'0',STR_PAD_LEFT) ?>/<?= $card['expiry_year'] ?></div>
                    </div>
                    <div class="card-logo"><?= strtoupper($card['card_type']) ?></div>
                </div>
            </div>

            <!-- Limit Progress -->
            <div style="width:100%;">
                <div style="display:flex;justify-content:space-between;margin-bottom:8px;">
                    <span style="font-size:0.82rem;color:var(--text-muted);">Credit Utilization</span>
                    <span style="font-size:0.82rem;font-weight:700;">
                        <?= round(($card['outstanding_balance'] / max($card['credit_limit'],1)) * 100) ?>%
                    </span>
                </div>
                <div class="progress-bar-wrap">
                    <div class="progress-bar-fill" 
                         data-width="<?= min(round(($card['outstanding_balance'] / max($card['credit_limit'],1)) * 100), 100) ?>"
                         style="background:<?= ($card['outstanding_balance'] / max($card['credit_limit'],1)) > 0.8 ? 'var(--danger)' : 'linear-gradient(90deg,var(--primary),var(--info))' ?>">
                    </div>
                </div>
                <div style="display:flex;justify-content:space-between;margin-top:6px;font-size:0.78rem;color:var(--text-muted);">
                    <span>₹<?= number_format($card['outstanding_balance']) ?> used</span>
                    <span>₹<?= number_format($card['credit_limit']) ?> limit</span>
                </div>
            </div>

            <!-- Card Status -->
            <div style="width:100%;display:flex;justify-content:space-between;padding:12px 16px;background:var(--glass);border-radius:12px;border:1px solid var(--border);">
                <div style="text-align:center;">
                    <div style="font-size:0.72rem;color:var(--text-muted);margin-bottom:2px;">Status</div>
                    <span class="badge badge-<?= $card['status'] === 'active' ? 'success' : 'danger' ?>"><?= ucfirst($card['status']) ?></span>
                </div>
                <div style="text-align:center;">
                    <div style="font-size:0.72rem;color:var(--text-muted);margin-bottom:2px;">Card Type</div>
                    <span style="font-weight:700;font-size:0.88rem;"><?= $card['card_type'] ?></span>
                </div>
                <?php if ($currentBill): ?>
                <div style="text-align:center;">
                    <div style="font-size:0.72rem;color:var(--text-muted);margin-bottom:2px;">Min Due</div>
                    <span style="font-weight:700;color:var(--warning);font-size:0.88rem;"><?= formatCurrency($currentBill['minimum_due']) ?></span>
                </div>
                <?php endif; ?>
            </div>
            <?php else: ?>
            <div class="empty-state">
                <div class="empty-icon">💳</div>
                <div class="empty-title">No Card Assigned</div>
                <div class="empty-desc">Contact admin to assign a credit card to your account.</div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Spending by Category (Doughnut) -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">📊 Spending by Category</h3>
            <span style="font-size:0.8rem;color:var(--text-muted);">Last 3 months</span>
        </div>
        <div class="card-body" style="display:flex;flex-direction:column;align-items:center;gap:16px;">
            <?php if (!empty($categoryData)): ?>
            <canvas id="categoryChart" style="max-height:220px;max-width:220px;"></canvas>
            <div style="width:100%;display:grid;gap:8px;">
                <?php foreach(array_slice($categoryData, 0, 5) as $cat): ?>
                <div style="display:flex;align-items:center;gap:10px;">
                    <span style="font-size:1rem;"><?= getCategoryIcon($cat['category']) ?></span>
                    <span style="flex:1;font-size:0.82rem;text-transform:capitalize;"><?= $cat['category'] ?></span>
                    <span style="font-weight:700;font-size:0.88rem;"><?= formatCurrency($cat['total']) ?></span>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="empty-state"><div class="empty-icon">📊</div><div class="empty-title">No spending data yet</div></div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Monthly Trend Chart -->
<div class="card mb-3">
    <div class="card-header">
        <h3 class="card-title">📈 Monthly Spending Trend</h3>
        <span style="font-size:0.8rem;color:var(--text-muted);">Last 6 months</span>
    </div>
    <div class="card-body">
        <canvas id="trendChart" style="max-height:260px;"></canvas>
    </div>
</div>

<!-- Recent Transactions -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">🕐 Recent Transactions</h3>
        <a href="transactions.php" class="btn btn-ghost btn-sm">View All →</a>
    </div>
    <?php if (!empty($recentTxns)): ?>
    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>Description</th>
                    <th>Category</th>
                    <th>Date</th>
                    <th>Amount</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($recentTxns as $txn): ?>
                <tr>
                    <td>
                        <div style="display:flex;align-items:center;gap:10px;">
                            <span style="font-size:1.2rem;"><?= getCategoryIcon($txn['category']) ?></span>
                            <div>
                                <div style="font-weight:600;font-size:0.88rem;"><?= htmlspecialchars($txn['description']) ?></div>
                                <div style="font-size:0.75rem;color:var(--text-muted);"><?= htmlspecialchars($txn['reference_no']) ?></div>
                            </div>
                        </div>
                    </td>
                    <td><span style="text-transform:capitalize;font-size:0.82rem;"><?= $txn['category'] ?></span></td>
                    <td style="font-size:0.82rem;color:var(--text-muted);"><?= date('d M Y, h:ia', strtotime($txn['transaction_date'])) ?></td>
                    <td>
                        <span style="font-weight:700;color:<?= in_array($txn['transaction_type'],['credit','payment','refund']) ? 'var(--success)' : 'var(--text)' ?>;">
                            <?= in_array($txn['transaction_type'],['credit','payment','refund']) ? '+' : '-' ?><?= formatCurrency($txn['amount']) ?>
                        </span>
                    </td>
                    <td><span class="badge <?= getStatusBadge($txn['status']) ?>"><?= $txn['status'] ?></span></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
    <div class="card-body">
        <div class="empty-state"><div class="empty-icon">📋</div><div class="empty-title">No transactions yet</div></div>
    </div>
    <?php endif; ?>
</div>

</div><!-- /content-area -->
</div><!-- /main-wrapper -->

<div id="toast-container"></div>
<script src="../assets/js/main.js"></script>
<script>
// Category Doughnut Chart
<?php if (!empty($categoryData)): ?>
const catCtx = document.getElementById('categoryChart');
if (catCtx) {
    const categoryColors = ['#2563EB','#10B981','#F59E0B','#7C3AED','#DC2626','#06B6D4','#F97316'];
    new Chart(catCtx, {
        type: 'doughnut',
        data: {
            labels: <?= json_encode(array_column(array_slice($categoryData,0,7), 'category')) ?>,
            datasets: [{
                data: <?= json_encode(array_map(fn($c) => round((float)$c['total']), array_slice($categoryData,0,7))) ?>,
                backgroundColor: categoryColors,
                borderWidth: 0,
                hoverOffset: 8
            }]
        },
        options: {
            responsive: true, maintainAspectRatio: true,
            cutout: '72%',
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: ctx => ' ₹' + ctx.raw.toLocaleString('en-IN')
                    }
                }
            }
        }
    });
}
<?php endif; ?>

// Monthly Trend Chart
<?php if (!empty($monthlyData)): ?>
const trendCtx = document.getElementById('trendChart');
if (trendCtx) {
    const ctx2d = trendCtx.getContext('2d');
    const spendGrad = ctx2d.createLinearGradient(0,0,0,260);
    spendGrad.addColorStop(0,'rgba(37,99,235,0.3)');
    spendGrad.addColorStop(1,'rgba(37,99,235,0)');
    const payGrad = ctx2d.createLinearGradient(0,0,0,260);
    payGrad.addColorStop(0,'rgba(16,185,129,0.3)');
    payGrad.addColorStop(1,'rgba(16,185,129,0)');

    new Chart(trendCtx, {
        type: 'line',
        data: {
            labels: <?= json_encode(array_column($monthlyData, 'label')) ?>,
            datasets: [
                {
                    label: 'Spending',
                    data: <?= json_encode(array_map(fn($m) => round((float)$m['spending']), $monthlyData)) ?>,
                    borderColor: '#2563EB', backgroundColor: spendGrad,
                    tension: 0.4, fill: true, pointRadius: 5,
                    pointBackgroundColor: '#2563EB', borderWidth: 2.5
                },
                {
                    label: 'Payments',
                    data: <?= json_encode(array_map(fn($m) => round((float)$m['payments']), $monthlyData)) ?>,
                    borderColor: '#10B981', backgroundColor: payGrad,
                    tension: 0.4, fill: true, pointRadius: 5,
                    pointBackgroundColor: '#10B981', borderWidth: 2.5
                }
            ]
        },
        options: {
            responsive: true, maintainAspectRatio: true,
            plugins: {
                legend: { labels: { color: '#94A3B8', font: { family: 'Inter' } } },
                tooltip: { callbacks: { label: ctx => ctx.dataset.label + ': ₹' + ctx.raw.toLocaleString('en-IN') } }
            },
            scales: {
                x: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#94A3B8' } },
                y: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#94A3B8', callback: v => '₹' + v.toLocaleString('en-IN') } }
            }
        }
    });
}
<?php endif; ?>
</script>
</body>
</html>
