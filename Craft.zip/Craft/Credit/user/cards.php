<?php
/**
 * User Cards Page - Credit Card Details
 * Secure Credit Card Management System
 */
require_once 'layout.php';

$cards = getUserCards($user['id']);
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Credit Card — CreditGuard</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php renderSidebar($user, $notifCount, $currentPage); ?>
<div class="main-wrapper">
<?php renderTopbar($user, $notifCount, '💳 My Credit Card'); ?>
<div class="content-area">

<?php if (empty($cards)): ?>
<div class="card p-3" style="text-align:center;padding:60px;">
    <div style="font-size:5rem;margin-bottom:16px;">💳</div>
    <h2 style="margin-bottom:8px;">No Credit Card Assigned</h2>
    <p style="color:var(--text-muted);">Please contact the admin to have a credit card assigned to your account.</p>
    <a href="../public/contact.php" class="btn btn-primary" style="margin-top:20px;">Contact Support</a>
</div>
<?php else: foreach($cards as $c):
    $gradients = ['Visa'=>'card-gradient-blue','MasterCard'=>'card-gradient-dark','Amex'=>'card-gradient-gold','Rupay'=>'card-gradient-green'];
    $gradient  = $gradients[$c['card_type']] ?? 'card-gradient-blue';
?>

<div class="grid-2 mb-3">
    <!-- Card Display -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Card Details</h3>
            <span class="badge <?= getStatusBadge($c['status']) ?>"><?= ucfirst($c['status']) ?></span>
        </div>
        <div class="card-body" style="display:flex;flex-direction:column;align-items:center;gap:24px;">
            <div class="credit-card-display <?= $gradient ?>" style="width:100%;max-width:360px;" id="card-display-<?= $c['id'] ?>">
                <div class="card-chip"></div>
                <div class="card-number-display" id="card-num-<?= $c['id'] ?>" data-full="<?= htmlspecialchars($c['card_number']) ?>" data-masked="<?= formatMaskedCard($c['card_number']) ?>">
                    <?= formatMaskedCard($c['card_number']) ?>
                </div>
                <div class="card-info-row">
                    <div>
                        <div class="card-label">Card Holder</div>
                        <div class="card-value"><?= htmlspecialchars($c['card_holder']) ?></div>
                    </div>
                    <div>
                        <div class="card-label">Expires</div>
                        <div class="card-value"><?= str_pad($c['expiry_month'],2,'0',STR_PAD_LEFT) ?>/<?= $c['expiry_year'] ?></div>
                    </div>
                    <div class="card-logo"><?= strtoupper($c['card_type']) ?></div>
                </div>
            </div>

            <div style="display:flex;gap:10px;">
                <button class="btn btn-ghost btn-sm" onclick="toggleCardNumber(<?= $c['id'] ?>)" id="toggle-btn-<?= $c['id'] ?>">
                    👁️ Show Number
                </button>
                <?php if ($c['status'] === 'active'): ?>
                <button class="btn btn-ghost btn-sm" onclick="Toast.info('Card Frozen','Card freezing is a premium feature.')">
                    🧊 Freeze Card
                </button>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Card Stats -->
    <div style="display:grid;gap:16px;">
        <div class="stat-card" style="--accent:var(--primary);">
            <div class="stat-icon" style="background:rgba(37,99,235,0.15);">💰</div>
            <div class="stat-info">
                <div class="stat-label">Credit Limit</div>
                <div class="stat-value" data-counter="<?= $c['credit_limit'] ?>" data-prefix="₹"><?= formatCurrency($c['credit_limit']) ?></div>
            </div>
        </div>
        <div class="stat-card" style="--accent:var(--success);">
            <div class="stat-icon" style="background:rgba(16,185,129,0.15);">✅</div>
            <div class="stat-info">
                <div class="stat-label">Available Balance</div>
                <div class="stat-value" style="color:var(--success);" data-counter="<?= $c['available_balance'] ?>" data-prefix="₹"><?= formatCurrency($c['available_balance']) ?></div>
            </div>
        </div>
        <div class="stat-card" style="--accent:var(--danger);">
            <div class="stat-icon" style="background:rgba(220,38,38,0.15);">🧾</div>
            <div class="stat-info">
                <div class="stat-label">Outstanding Balance</div>
                <div class="stat-value" style="color:var(--danger);" data-counter="<?= $c['outstanding_balance'] ?>" data-prefix="₹"><?= formatCurrency($c['outstanding_balance']) ?></div>
            </div>
        </div>
    </div>
</div>

<!-- Card Info Details -->
<div class="card mb-3">
    <div class="card-header"><h3 class="card-title">Card Information</h3></div>
    <div class="card-body">
        <div class="grid-3" style="gap:20px;">
            <?php
            $details = [
                ['Card Number',    formatMaskedCard($c['card_number'])],
                ['Card Type',      $c['card_type']],
                ['Network',        $c['card_type'] . ' Network'],
                ['Expiry',         str_pad($c['expiry_month'],2,'0',STR_PAD_LEFT) . '/' . $c['expiry_year']],
                ['Issued Date',    date('d M Y', strtotime($c['issued_date']))],
                ['Card Status',    ucfirst($c['status'])],
                ['CVV',            '●●●'],
                ['Card Holder',    $c['card_holder']],
                ['Utilization',    round(($c['outstanding_balance'] / max($c['credit_limit'],1)) * 100) . '%'],
            ];
            foreach($details as $d): ?>
            <div style="padding:16px;background:var(--glass);border:1px solid var(--border);border-radius:12px;">
                <div style="font-size:0.72rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;"><?= $d[0] ?></div>
                <div style="font-weight:700;font-size:0.95rem;"><?= htmlspecialchars($d[1]) ?></div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- Utilization Bar -->
        <div style="margin-top:24px;">
            <div style="display:flex;justify-content:space-between;margin-bottom:8px;">
                <span style="font-size:0.88rem;font-weight:600;">Credit Utilization</span>
                <span style="font-size:0.88rem;color:var(--text-muted);">
                    <?= formatCurrency($c['outstanding_balance']) ?> / <?= formatCurrency($c['credit_limit']) ?>
                </span>
            </div>
            <div class="progress-bar-wrap" style="height:10px;">
                <?php $util = min(round(($c['outstanding_balance'] / max($c['credit_limit'],1)) * 100), 100); ?>
                <div class="progress-bar-fill"
                     data-width="<?= $util ?>"
                     style="background:<?= $util > 80 ? 'var(--danger)' : ($util > 50 ? 'var(--warning)' : 'linear-gradient(90deg,var(--primary),var(--info))') ?>">
                </div>
            </div>
            <p style="font-size:0.78rem;color:var(--text-muted);margin-top:6px;">
                <?php if ($util > 80): ?>
                ⚠️ High utilization may affect your credit score. Consider paying your bill.
                <?php elseif ($util > 50): ?>
                📊 Moderate utilization. Aim to keep it below 30% for best credit score.
                <?php else: ?>
                ✅ Good utilization! You're using your credit responsibly.
                <?php endif; ?>
            </p>
        </div>
    </div>
    <div class="card-footer" style="display:flex;gap:12px;">
        <a href="pay.php" class="btn btn-primary btn-sm">💸 Pay Bill</a>
        <a href="complaints.php" class="btn btn-ghost btn-sm">⚠️ Report Issue</a>
    </div>
</div>

<?php endforeach; endif; ?>

</div><!-- /content-area -->
</div><!-- /main-wrapper -->
<div id="toast-container"></div>
<script src="../assets/js/main.js"></script>
<script>
let cardRevealed = {};
function toggleCardNumber(cardId) {
    const el  = document.getElementById('card-num-' + cardId);
    const btn = document.getElementById('toggle-btn-' + cardId);
    if (cardRevealed[cardId]) {
        el.textContent = el.dataset.masked;
        btn.innerHTML  = '👁️ Show Number';
        cardRevealed[cardId] = false;
    } else {
        // Format full card number in groups of 4
        const full = el.dataset.full.replace(/(\d{4})/g, '$1 ').trim();
        el.textContent = full;
        btn.innerHTML  = '🙈 Hide Number';
        cardRevealed[cardId] = true;
        // Auto-hide after 10 seconds
        setTimeout(() => {
            if (cardRevealed[cardId]) toggleCardNumber(cardId);
        }, 10000);
    }
}
</script>
</body>
</html>
