<?php
/**
 * User Transactions Page
 * Secure Credit Card Management System
 */
require_once 'layout.php';

// Filters
$filterType = $_GET['type'] ?? '';
$filterStatus = $_GET['status'] ?? '';
$filterFrom  = $_GET['from'] ?? '';
$filterTo    = $_GET['to'] ?? '';
$page        = max(1, (int)($_GET['page'] ?? 1));
$perPage     = 15;
$offset      = ($page - 1) * $perPage;

// Build query
$where  = ["t.user_id = ?"];
$params = [$user['id']];

if ($filterType)   { $where[] = "t.transaction_type = ?"; $params[] = $filterType; }
if ($filterStatus) { $where[] = "t.status = ?";           $params[] = $filterStatus; }
if ($filterFrom)   { $where[] = "DATE(t.transaction_date) >= ?"; $params[] = $filterFrom; }
if ($filterTo)     { $where[] = "DATE(t.transaction_date) <= ?"; $params[] = $filterTo; }

$whereStr = implode(' AND ', $where);

// Count
$countStmt = $pdo->prepare("SELECT COUNT(*) FROM transactions t WHERE $whereStr");
$countStmt->execute($params);
$total = (int)$countStmt->fetchColumn();
$pages = (int)ceil($total / $perPage);

// Fetch
$stmt = $pdo->prepare("
    SELECT t.*, c.card_number 
    FROM transactions t JOIN credit_cards c ON t.card_id = c.id
    WHERE $whereStr
    ORDER BY t.transaction_date DESC 
    LIMIT $perPage OFFSET $offset
");
$stmt->execute($params);
$transactions = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Transactions — CreditGuard</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php renderSidebar($user, $notifCount, $currentPage); ?>
<div class="main-wrapper">
<?php renderTopbar($user, $notifCount, '📋 Transactions'); ?>
<div class="content-area">

<!-- Filters -->
<div class="card mb-3">
    <div class="card-body">
        <form method="GET" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;align-items:end;">
            <div class="form-group" style="margin-bottom:0;">
                <label class="form-label">Type</label>
                <select name="type" class="form-control">
                    <option value="">All Types</option>
                    <option value="debit"   <?= $filterType==='debit'   ? 'selected' : '' ?>>Debit</option>
                    <option value="credit"  <?= $filterType==='credit'  ? 'selected' : '' ?>>Credit</option>
                    <option value="payment" <?= $filterType==='payment' ? 'selected' : '' ?>>Payment</option>
                    <option value="refund"  <?= $filterType==='refund'  ? 'selected' : '' ?>>Refund</option>
                </select>
            </div>
            <div class="form-group" style="margin-bottom:0;">
                <label class="form-label">Status</label>
                <select name="status" class="form-control">
                    <option value="">All Status</option>
                    <option value="success" <?= $filterStatus==='success' ? 'selected' : '' ?>>Success</option>
                    <option value="pending" <?= $filterStatus==='pending' ? 'selected' : '' ?>>Pending</option>
                    <option value="flagged" <?= $filterStatus==='flagged' ? 'selected' : '' ?>>Flagged</option>
                    <option value="failed"  <?= $filterStatus==='failed'  ? 'selected' : '' ?>>Failed</option>
                </select>
            </div>
            <div class="form-group" style="margin-bottom:0;">
                <label class="form-label">From Date</label>
                <input type="date" name="from" class="form-control" value="<?= htmlspecialchars($filterFrom) ?>">
            </div>
            <div class="form-group" style="margin-bottom:0;">
                <label class="form-label">To Date</label>
                <input type="date" name="to" class="form-control" value="<?= htmlspecialchars($filterTo) ?>">
            </div>
            <div style="display:flex;gap:8px;">
                <button type="submit" class="btn btn-primary" style="height:44px;">Filter</button>
                <a href="transactions.php" class="btn btn-ghost" style="height:44px;">Reset</a>
            </div>
        </form>
    </div>
</div>

<!-- Transactions Table -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Transaction History</h3>
        <div style="display:flex;align-items:center;gap:12px;">
            <div class="search-bar">
                <span class="search-icon">🔍</span>
                <input type="text" id="table-search" placeholder="Search..." style="width:200px;">
            </div>
            <span style="font-size:0.82rem;color:var(--text-muted);"><?= $total ?> records</span>
        </div>
    </div>
    <?php if (!empty($transactions)): ?>
    <div class="table-wrapper">
        <table id="main-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Description</th>
                    <th>Type</th>
                    <th>Category</th>
                    <th>Date & Time</th>
                    <th>Amount</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($transactions as $i => $txn): ?>
                <tr <?= $txn['status'] === 'flagged' ? "style='background:rgba(220,38,38,0.05);'" : '' ?>>
                    <td style="color:var(--text-muted);font-size:0.8rem;"><?= $offset + $i + 1 ?></td>
                    <td>
                        <div style="display:flex;align-items:center;gap:10px;">
                            <div style="width:38px;height:38px;border-radius:10px;background:<?= $txn['transaction_type']==='debit' ? 'rgba(220,38,38,0.1)' : 'rgba(16,185,129,0.1)' ?>;display:flex;align-items:center;justify-content:center;font-size:1.1rem;flex-shrink:0;">
                                <?= getCategoryIcon($txn['category']) ?>
                            </div>
                            <div>
                                <div style="font-weight:600;font-size:0.88rem;"><?= htmlspecialchars($txn['description']) ?></div>
                                <?php if ($txn['merchant']): ?>
                                <div style="font-size:0.75rem;color:var(--text-muted);"><?= htmlspecialchars($txn['merchant']) ?></div>
                                <?php endif; ?>
                                <div style="font-size:0.7rem;color:var(--text-muted);"><?= htmlspecialchars($txn['reference_no']) ?></div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <span class="badge <?= in_array($txn['transaction_type'],['credit','payment','refund']) ? 'badge-success' : 'badge-danger' ?>">
                            <?= ucfirst($txn['transaction_type']) ?>
                        </span>
                    </td>
                    <td>
                        <span style="font-size:0.82rem;text-transform:capitalize;">
                            <?= getCategoryIcon($txn['category']) ?> <?= $txn['category'] ?>
                        </span>
                    </td>
                    <td style="font-size:0.82rem;color:var(--text-muted);white-space:nowrap;">
                        <?= date('d M Y', strtotime($txn['transaction_date'])) ?><br>
                        <span style="font-size:0.75rem;"><?= date('h:i A', strtotime($txn['transaction_date'])) ?></span>
                    </td>
                    <td>
                        <span style="font-weight:800;font-size:0.95rem;color:<?= in_array($txn['transaction_type'],['credit','payment','refund']) ? 'var(--success)' : ($txn['status']==='flagged' ? 'var(--danger)' : 'var(--text)') ?>;">
                            <?= in_array($txn['transaction_type'],['credit','payment','refund']) ? '+' : '−' ?><?= formatCurrency($txn['amount']) ?>
                        </span>
                    </td>
                    <td>
                        <span class="badge <?= getStatusBadge($txn['status']) ?>">
                            <?= $txn['status'] === 'flagged' ? '⚠️ ' : '' ?><?= ucfirst($txn['status']) ?>
                        </span>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <?php if ($pages > 1): ?>
    <div class="card-footer" style="display:flex;justify-content:center;gap:6px;flex-wrap:wrap;">
        <?php for($p=1; $p<=$pages; $p++): ?>
        <a href="?page=<?= $p ?>&type=<?= urlencode($filterType) ?>&status=<?= urlencode($filterStatus) ?>&from=<?= urlencode($filterFrom) ?>&to=<?= urlencode($filterTo) ?>"
           class="btn btn-sm <?= $p === $page ? 'btn-primary' : 'btn-ghost' ?>"><?= $p ?></a>
        <?php endfor; ?>
    </div>
    <?php endif; ?>

    <?php else: ?>
    <div class="card-body">
        <div class="empty-state">
            <div class="empty-icon">📋</div>
            <div class="empty-title">No transactions found</div>
            <div class="empty-desc">Try adjusting your filters or check back later.</div>
        </div>
    </div>
    <?php endif; ?>
</div>

</div><!-- /content-area -->
</div><!-- /main-wrapper -->
<div id="toast-container"></div>
<script src="../assets/js/main.js"></script>
</body>
</html>
