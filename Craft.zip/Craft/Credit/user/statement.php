<?php
/**
 * User Statement Page (PDF simulation)
 * Secure Credit Card Management System
 */
require_once 'layout.php';

$card = getUserCard($user['id']);

// Get selected month/year
$month = (int)($_GET['month'] ?? date('n'));
$year  = (int)($_GET['year']  ?? date('Y'));

// Transactions for selected period
$txnStmt = $pdo->prepare("
    SELECT * FROM transactions 
    WHERE user_id=? AND MONTH(transaction_date)=? AND YEAR(transaction_date)=?
    ORDER BY transaction_date ASC
");
$txnStmt->execute([$user['id'], $month, $year]);
$stmtTxns = $txnStmt->fetchAll();

// Bill for this period
$billStmt = $pdo->prepare("SELECT * FROM bills WHERE user_id=? AND bill_month=? AND bill_year=?");
$billStmt->execute([$user['id'], $month, $year]);
$bill = $billStmt->fetch();

$totalDebit  = array_sum(array_map(fn($t) => $t['transaction_type']==='debit' ? $t['amount'] : 0, $stmtTxns));
$totalCredit = array_sum(array_map(fn($t) => in_array($t['transaction_type'],['credit','payment','refund']) ? $t['amount'] : 0, $stmtTxns));
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Statement — CreditGuard</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php renderSidebar($user, $notifCount, $currentPage); ?>
<div class="main-wrapper">
<?php renderTopbar($user, $notifCount, '📄 Monthly Statement'); ?>
<div class="content-area">

<!-- Month Selector -->
<div class="card mb-3">
    <div class="card-body">
        <form method="GET" style="display:flex;gap:12px;align-items:end;flex-wrap:wrap;">
            <div class="form-group" style="margin:0;">
                <label class="form-label">Month</label>
                <select name="month" class="form-control" onchange="this.form.submit()">
                    <?php for($m=1; $m<=12; $m++): ?>
                    <option value="<?= $m ?>" <?= $m===$month?'selected':'' ?>><?= date('F', mktime(0,0,0,$m,1)) ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="form-group" style="margin:0;">
                <label class="form-label">Year</label>
                <select name="year" class="form-control" onchange="this.form.submit()">
                    <?php for($y=date('Y'); $y>=date('Y')-3; $y--): ?>
                    <option value="<?= $y ?>" <?= $y===$year?'selected':'' ?>><?= $y ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <button type="button" class="btn btn-primary" onclick="printStatement()">🖨️ Print/Save PDF</button>
        </form>
    </div>
</div>

<!-- Statement Document -->
<div class="card" id="statement-doc">
    <!-- Statement Header -->
    <div style="background:linear-gradient(135deg,#1e3a8a,#2563eb);padding:32px;color:white;">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:20px;">
            <div>
                <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;">
                    <div style="width:40px;height:40px;background:rgba(255,255,255,0.2);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.3rem;">💳</div>
                    <div>
                        <div style="font-size:1.2rem;font-weight:800;font-family:'Space Grotesk',sans-serif;">CreditGuard</div>
                        <div style="font-size:0.75rem;opacity:0.7;">Secure Credit Card Management</div>
                    </div>
                </div>
                <h2 style="font-size:1.4rem;font-weight:800;margin-bottom:4px;">Account Statement</h2>
                <p style="opacity:0.8;font-size:0.88rem;"><?= date('F Y', mktime(0,0,0,$month,1,$year)) ?></p>
            </div>
            <div style="text-align:right;">
                <div style="font-size:0.75rem;opacity:0.7;margin-bottom:4px;">Generated On</div>
                <div style="font-weight:700;"><?= date('d M Y, h:i A') ?></div>
                <div style="font-size:0.75rem;opacity:0.7;margin-top:8px;">Statement #</div>
                <div style="font-family:monospace;font-size:0.85rem;">STMT-<?= $year ?><?= str_pad($month,2,'0',STR_PAD_LEFT) ?>-<?= str_pad($user['id'],4,'0',STR_PAD_LEFT) ?></div>
            </div>
        </div>
    </div>

    <div class="card-body">
        <!-- Account Info -->
        <div class="grid-2 mb-3">
            <div style="padding:16px;background:var(--glass);border:1px solid var(--border);border-radius:12px;">
                <h4 style="font-size:0.82rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:12px;">Account Holder</h4>
                <p style="font-weight:700;font-size:1rem;"><?= htmlspecialchars($user['name']) ?></p>
                <p style="color:var(--text-muted);font-size:0.85rem;"><?= htmlspecialchars($user['email']) ?></p>
                <p style="color:var(--text-muted);font-size:0.85rem;"><?= htmlspecialchars($user['mobile']) ?></p>
            </div>
            <?php if ($card): ?>
            <div style="padding:16px;background:var(--glass);border:1px solid var(--border);border-radius:12px;">
                <h4 style="font-size:0.82rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:12px;">Card Details</h4>
                <p style="font-weight:700;font-family:monospace;"><?= formatMaskedCard($card['card_number']) ?></p>
                <p style="color:var(--text-muted);font-size:0.85rem;"><?= $card['card_type'] ?> · Expires <?= str_pad($card['expiry_month'],2,'0',STR_PAD_LEFT) ?>/<?= $card['expiry_year'] ?></p>
                <p style="color:var(--text-muted);font-size:0.85rem;">Limit: <?= formatCurrency($card['credit_limit']) ?></p>
            </div>
            <?php endif; ?>
        </div>

        <!-- Summary -->
        <div class="grid-3 mb-3">
            <div style="text-align:center;padding:20px;background:rgba(220,38,38,0.08);border:1px solid rgba(220,38,38,0.2);border-radius:12px;">
                <div style="font-size:0.78rem;color:var(--text-muted);margin-bottom:6px;text-transform:uppercase;letter-spacing:1px;">Total Spending</div>
                <div style="font-size:1.6rem;font-weight:800;color:var(--danger);"><?= formatCurrency($totalDebit) ?></div>
            </div>
            <div style="text-align:center;padding:20px;background:rgba(16,185,129,0.08);border:1px solid rgba(16,185,129,0.2);border-radius:12px;">
                <div style="font-size:0.78rem;color:var(--text-muted);margin-bottom:6px;text-transform:uppercase;letter-spacing:1px;">Total Credits</div>
                <div style="font-size:1.6rem;font-weight:800;color:var(--success);"><?= formatCurrency($totalCredit) ?></div>
            </div>
            <div style="text-align:center;padding:20px;background:rgba(37,99,235,0.08);border:1px solid rgba(37,99,235,0.2);border-radius:12px;">
                <div style="font-size:0.78rem;color:var(--text-muted);margin-bottom:6px;text-transform:uppercase;letter-spacing:1px;">Transactions</div>
                <div style="font-size:1.6rem;font-weight:800;color:var(--primary-light);"><?= count($stmtTxns) ?></div>
            </div>
        </div>

        <!-- Transactions Table -->
        <h4 style="margin-bottom:16px;font-size:1rem;">Transaction Details</h4>
        <?php if (!empty($stmtTxns)): ?>
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Description</th>
                        <th>Category</th>
                        <th>Type</th>
                        <th>Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($stmtTxns as $txn): ?>
                    <tr>
                        <td style="font-size:0.82rem;white-space:nowrap;"><?= date('d M Y', strtotime($txn['transaction_date'])) ?></td>
                        <td>
                            <div style="font-weight:600;font-size:0.88rem;"><?= htmlspecialchars($txn['description']) ?></div>
                            <div style="font-size:0.72rem;color:var(--text-muted);"><?= htmlspecialchars($txn['reference_no']) ?></div>
                        </td>
                        <td style="text-transform:capitalize;font-size:0.82rem;"><?= getCategoryIcon($txn['category']) ?> <?= $txn['category'] ?></td>
                        <td><span class="badge <?= in_array($txn['transaction_type'],['credit','payment','refund']) ? 'badge-success' : 'badge-danger' ?>"><?= ucfirst($txn['transaction_type']) ?></span></td>
                        <td style="font-weight:700;color:<?= in_array($txn['transaction_type'],['credit','payment','refund']) ? 'var(--success)' : 'var(--text)' ?>;">
                            <?= in_array($txn['transaction_type'],['credit','payment','refund']) ? '+' : '−' ?><?= formatCurrency($txn['amount']) ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr style="background:rgba(0,0,0,0.15);">
                        <td colspan="3" style="padding:12px 16px;font-weight:700;">Closing Balance</td>
                        <td colspan="2" style="padding:12px 16px;font-weight:800;font-size:1rem;text-align:right;"><?= $card ? formatCurrency($card['outstanding_balance']) : '—' ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>
        <?php else: ?>
        <div class="empty-state"><div class="empty-icon">📄</div><div class="empty-title">No transactions for <?= date('F Y', mktime(0,0,0,$month,1,$year)) ?></div></div>
        <?php endif; ?>

        <!-- Footer note -->
        <p style="font-size:0.75rem;color:var(--text-muted);margin-top:24px;text-align:center;">
            This is a computer-generated statement and does not require a signature. 
            For queries, contact support@creditguard.com
        </p>
    </div>
</div>

</div></div>
<div id="toast-container"></div>
<script src="../assets/js/main.js"></script>
<script>
function printStatement() {
    const el = document.getElementById('statement-doc');
    const win = window.open('', '_blank');
    win.document.write(`
        <html><head>
        <title>Statement - CreditGuard</title>
        <style>body{font-family:Arial,sans-serif;padding:20px;color:#000;}table{width:100%;border-collapse:collapse;}th,td{padding:8px 12px;border:1px solid #ddd;text-align:left;}th{background:#f5f5f5;}</style>
        </head><body>` + el.innerHTML + `</body></html>`);
    win.document.close();
    win.focus();
    setTimeout(() => { win.print(); win.close(); }, 500);
    Toast.success('Print Dialog Opened', 'Use "Save as PDF" to download your statement.');
}
</script>
</body>
</html>
