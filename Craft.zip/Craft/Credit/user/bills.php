<?php
/**
 * User Bills Page
 * Secure Credit Card Management System
 */
require_once 'layout.php';

$card = getUserCard($user['id']);
$stmt = $pdo->prepare("SELECT * FROM bills WHERE user_id=? ORDER BY bill_year DESC, bill_month DESC");
$stmt->execute([$user['id']]);
$bills = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Bills & Payments — CreditGuard</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php renderSidebar($user, $notifCount, $currentPage); ?>
<div class="main-wrapper">
<?php renderTopbar($user, $notifCount, '🧾 Bills & Payments'); ?>
<div class="content-area">

<!-- Current Bill Highlight -->
<?php if (!empty($bills) && $bills[0]['status'] !== 'paid'): $cb = $bills[0]; ?>
<div class="card mb-3" style="background:linear-gradient(135deg,rgba(220,38,38,0.12),rgba(245,158,11,0.08));border-color:rgba(220,38,38,0.3);">
    <div class="card-body">
        <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:16px;">
            <div>
                <div style="font-size:0.8rem;color:var(--danger);font-weight:600;text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">
                    ⚠️ Payment Due
                </div>
                <h2 style="font-size:2rem;font-weight:900;margin-bottom:4px;"><?= formatCurrency($cb['total_due']) ?></h2>
                <p style="color:var(--text-muted);font-size:0.88rem;">
                    Due by <?= date('d F Y', strtotime($cb['due_date'])) ?> · 
                    Minimum: <?= formatCurrency($cb['minimum_due']) ?>
                </p>
            </div>
            <div style="display:flex;gap:12px;flex-wrap:wrap;">
                <a href="pay.php" class="btn btn-danger">💸 Pay Now</a>
                <a href="statement.php" class="btn btn-ghost">📄 View Statement</a>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Bills History -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">📋 Billing History</h3>
        <a href="statement.php" class="btn btn-ghost btn-sm">📄 Download Statement</a>
    </div>
    <?php if (!empty($bills)): ?>
    <div class="table-wrapper">
        <table id="main-table">
            <thead>
                <tr>
                    <th>Bill Month</th>
                    <th>Total Due</th>
                    <th>Minimum Due</th>
                    <th>Interest</th>
                    <th>Due Date</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($bills as $bill): ?>
                <tr>
                    <td style="font-weight:600;"><?= date('F Y', mktime(0,0,0,$bill['bill_month'],1,$bill['bill_year'])) ?></td>
                    <td style="font-weight:700;"><?= formatCurrency($bill['total_due']) ?></td>
                    <td><?= formatCurrency($bill['minimum_due']) ?></td>
                    <td><?= formatCurrency($bill['interest_charge']) ?></td>
                    <td style="font-size:0.82rem;color:<?= strtotime($bill['due_date']) < time() && $bill['status'] !== 'paid' ? 'var(--danger)' : 'var(--text-muted)' ?>;">
                        <?= date('d M Y', strtotime($bill['due_date'])) ?>
                        <?php if (strtotime($bill['due_date']) < time() && $bill['status'] !== 'paid'): ?>
                        <span class="badge badge-danger" style="font-size:0.65rem;">Overdue</span>
                        <?php endif; ?>
                    </td>
                    <td><span class="badge <?= getStatusBadge($bill['status']) ?>"><?= ucfirst(str_replace('_',' ',$bill['status'])) ?></span></td>
                    <td>
                        <?php if ($bill['status'] !== 'paid'): ?>
                        <a href="pay.php" class="btn btn-primary btn-sm">Pay</a>
                        <?php else: ?>
                        <span style="color:var(--success);font-size:0.82rem;">✅ Paid</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
    <div class="card-body">
        <div class="empty-state">
            <div class="empty-icon">🧾</div>
            <div class="empty-title">No Bills Yet</div>
            <div class="empty-desc">Bills are generated monthly. Check back next month.</div>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Payment History -->
<div class="card mt-3">
    <div class="card-header"><h3 class="card-title">💰 Payment History</h3></div>
    <?php
    $payStmt = $pdo->prepare("SELECT * FROM payments WHERE user_id=? ORDER BY payment_date DESC LIMIT 20");
    $payStmt->execute([$user['id']]);
    $payments = $payStmt->fetchAll();
    ?>
    <?php if (!empty($payments)): ?>
    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>Reference</th>
                    <th>Amount</th>
                    <th>Method</th>
                    <th>Date</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($payments as $pay): ?>
                <tr>
                    <td style="font-size:0.8rem;font-family:monospace;"><?= htmlspecialchars($pay['payment_reference']) ?></td>
                    <td style="font-weight:700;color:var(--success);">+<?= formatCurrency($pay['amount']) ?></td>
                    <td><span style="text-transform:capitalize;"><?= $pay['payment_method'] ?></span></td>
                    <td style="font-size:0.82rem;color:var(--text-muted);"><?= date('d M Y, h:i A', strtotime($pay['payment_date'])) ?></td>
                    <td><span class="badge <?= getStatusBadge($pay['status']) ?>"><?= ucfirst($pay['status']) ?></span></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
    <div class="card-body"><div class="empty-state"><div class="empty-icon">💰</div><div class="empty-title">No payments yet</div></div></div>
    <?php endif; ?>
</div>

</div></div>
<div id="toast-container"></div>
<script src="../assets/js/main.js"></script>
</body>
</html>
