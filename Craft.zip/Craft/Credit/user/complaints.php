<?php
/**
 * User Complaints Page
 * Secure Credit Card Management System
 */
require_once 'layout.php';

$msg = '';

// Submit complaint
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_complaint'])) {
    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
        $msg = ['type'=>'error','text'=>'Invalid request.'];
    } else {
        $subject  = sanitize($_POST['subject'] ?? '');
        $category = sanitize($_POST['category'] ?? '');
        $message  = sanitize($_POST['message'] ?? '');

        if (empty($subject) || empty($message)) {
            $msg = ['type'=>'error','text'=>'Subject and message are required.'];
        } else {
            $pdo->prepare("INSERT INTO complaints (user_id, subject, message, category) VALUES (?,?,?,?)")
                ->execute([$user['id'], $subject, $message, $category]);
            createNotification($user['id'], '📝 Complaint Submitted', "Your complaint '$subject' has been submitted. We'll respond within 24 hours.", 'info');
            $msg = ['type'=>'success','text'=>'✅ Complaint submitted successfully! We\'ll respond within 24 hours.'];
        }
    }
}

$stmt = $pdo->prepare("SELECT * FROM complaints WHERE user_id=? ORDER BY created_at DESC");
$stmt->execute([$user['id']]);
$complaints = $stmt->fetchAll();

$csrf = generateCSRF();
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Complaints — CreditGuard</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php renderSidebar($user, $notifCount, $currentPage); ?>
<div class="main-wrapper">
<?php renderTopbar($user, $notifCount, '📝 Complaints'); ?>
<div class="content-area">

<div class="grid-2" style="align-items:start;">
    <!-- Complaint Form -->
    <div class="card">
        <div class="card-header"><h3 class="card-title">Submit a Complaint</h3></div>
        <div class="card-body">
            <?php if ($msg): ?>
            <div style="background:<?= $msg['type']==='success' ? 'rgba(16,185,129,0.1)' : 'rgba(220,38,38,0.1)' ?>;border:1px solid <?= $msg['type']==='success' ? 'rgba(16,185,129,0.3)' : 'rgba(220,38,38,0.3)' ?>;border-radius:12px;padding:12px 16px;margin-bottom:20px;font-size:0.88rem;color:<?= $msg['type']==='success' ? '#34D399' : '#F87171' ?>;">
                <?= $msg['text'] ?>
            </div>
            <?php endif; ?>

            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
                <input type="hidden" name="submit_complaint" value="1">

                <div class="form-group">
                    <label class="form-label">Category</label>
                    <select name="category" class="form-control" required>
                        <option value="transaction">💳 Transaction Issue</option>
                        <option value="billing">🧾 Billing Dispute</option>
                        <option value="card">💳 Card Problem</option>
                        <option value="security">🔐 Security Issue</option>
                        <option value="other">❓ Other</option>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">Subject</label>
                    <input type="text" name="subject" class="form-control"
                           placeholder="Brief description of your issue" required
                           maxlength="200">
                </div>

                <div class="form-group">
                    <label class="form-label">Detailed Description</label>
                    <textarea name="message" class="form-control" rows="6"
                              placeholder="Describe your issue in detail — include dates, amounts, and relevant information..."
                              required style="resize:vertical;"></textarea>
                </div>

                <button type="submit" class="btn btn-primary btn-block">
                    📤 Submit Complaint
                </button>
            </form>
        </div>
    </div>

    <!-- Complaint History -->
    <div>
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">My Complaints</h3>
                <span style="font-size:0.82rem;color:var(--text-muted);"><?= count($complaints) ?> total</span>
            </div>
            <?php if (!empty($complaints)): ?>
            <div style="max-height:600px;overflow-y:auto;">
                <?php foreach($complaints as $c):
                    $statusColors = ['open'=>'var(--warning)','in_progress'=>'var(--info)','resolved'=>'var(--success)','closed'=>'var(--text-muted)'];
                    $color = $statusColors[$c['status']] ?? 'var(--text-muted)';
                ?>
                <div style="padding:18px 24px;border-bottom:1px solid var(--border);">
                    <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:8px;gap:10px;">
                        <div>
                            <span style="font-weight:700;font-size:0.9rem;"><?= htmlspecialchars($c['subject']) ?></span>
                            <span class="badge badge-secondary" style="margin-left:8px;font-size:0.65rem;"><?= $c['category'] ?></span>
                        </div>
                        <span class="badge <?= getStatusBadge($c['status']) ?>" style="flex-shrink:0;"><?= ucfirst(str_replace('_',' ',$c['status'])) ?></span>
                    </div>
                    <p style="font-size:0.82rem;color:var(--text-muted);margin-bottom:8px;line-height:1.5;"><?= nl2br(htmlspecialchars(substr($c['message'],0,120))) ?>...</p>
                    <?php if ($c['admin_reply']): ?>
                    <div style="background:rgba(16,185,129,0.08);border:1px solid rgba(16,185,129,0.2);border-radius:10px;padding:10px 12px;margin-top:8px;">
                        <p style="font-size:0.75rem;color:var(--success);font-weight:600;margin-bottom:4px;">💬 Admin Response:</p>
                        <p style="font-size:0.82rem;color:var(--text-muted);"><?= nl2br(htmlspecialchars($c['admin_reply'])) ?></p>
                    </div>
                    <?php endif; ?>
                    <p style="font-size:0.75rem;color:var(--text-muted);margin-top:8px;"><?= timeAgo($c['created_at']) ?></p>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="card-body">
                <div class="empty-state">
                    <div class="empty-icon">📝</div>
                    <div class="empty-title">No complaints yet</div>
                    <div class="empty-desc">Having an issue? Use the form to submit a complaint.</div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

</div></div>
<div id="toast-container"></div>
<script src="../assets/js/main.js"></script>
</body>
</html>
