<?php
/**
 * Pay Bill Page
 * Secure Credit Card Management System
 */
require_once 'layout.php';

$card    = getUserCard($user['id']);
$bill    = $card ? getCurrentBill($user['id'], $card['id']) : null;

// Handle payment
$payMsg  = '';
$payType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pay'])) {
    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
        $payMsg = 'Invalid request.'; $payType = 'error';
    } elseif (!$card) {
        $payMsg = 'No card found.'; $payType = 'error';
    } else {
        $amount  = (float)($_POST['amount'] ?? 0);
        $method  = sanitize($_POST['payment_method'] ?? '');
        $validMethods = ['upi', 'card', 'netbanking', 'emi'];

        if ($amount <= 0) {
            $payMsg = 'Enter a valid amount.'; $payType = 'error';
        } elseif (!in_array($method, $validMethods)) {
            $payMsg = 'Select a payment method.'; $payType = 'error';
        } elseif ($amount > $card['outstanding_balance']) {
            $payMsg = 'Amount exceeds outstanding balance.'; $payType = 'error';
        } else {
            $ref = generateReference('PAY');

            // Insert payment
            $pdo->prepare("INSERT INTO payments (user_id,card_id,amount,payment_method,payment_reference,status) VALUES (?,?,?,?,?,'success')")
                ->execute([$user['id'], $card['id'], $amount, $method, $ref]);

            // Insert transaction
            $pdo->prepare("INSERT INTO transactions (card_id,user_id,transaction_type,amount,description,category,status,reference_no) VALUES (?,?,'payment',?,?,?,?,?)")
                ->execute([$card['id'], $user['id'], $amount, 'Bill Payment via ' . strtoupper($method), 'other', 'success', $ref]);

            // Update card balance
            $pdo->prepare("UPDATE credit_cards SET outstanding_balance = outstanding_balance - ?, available_balance = available_balance + ? WHERE id = ?")
                ->execute([$amount, $amount, $card['id']]);

            // Update bill if exists
            if ($bill) {
                $newDue = max(0, $bill['total_due'] - $amount);
                $status  = $newDue <= 0 ? 'paid' : ($amount >= $bill['minimum_due'] ? 'partially_paid' : 'unpaid');
                $pdo->prepare("UPDATE bills SET total_due=?, status=?, paid_at=? WHERE id=?")
                    ->execute([$newDue, $status, $newDue <= 0 ? date('Y-m-d H:i:s') : null, $bill['id']]);
            }

            // Notification
            createNotification($user['id'], '💳 Payment Successful', "₹" . number_format($amount, 2) . " paid via " . strtoupper($method) . ". Ref: $ref", 'payment');

            $payMsg  = "✅ Payment of ₹" . number_format($amount, 2) . " successful! Ref: $ref";
            $payType = 'success';

            // Refresh card data
            $card = getUserCard($user['id']);
            $bill = getCurrentBill($user['id'], $card['id']);
        }
    }
}

$csrf = generateCSRF();
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pay Bill — CreditGuard</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php renderSidebar($user, $notifCount, $currentPage); ?>
<div class="main-wrapper">
<?php renderTopbar($user, $notifCount, '💸 Pay Bill'); ?>
<div class="content-area">

<?php if (!$card): ?>
<div class="card p-3" style="text-align:center;padding:60px;">
    <div style="font-size:4rem;">💳</div>
    <h2>No Card Assigned</h2>
    <p style="color:var(--text-muted);">Contact admin to get a credit card assigned.</p>
</div>
<?php else: ?>

<!-- Bill Summary -->
<div class="grid-3 mb-3">
    <div class="stat-card" style="--accent:var(--danger);">
        <div class="stat-icon" style="background:rgba(220,38,38,0.15);">🧾</div>
        <div class="stat-info">
            <div class="stat-label">Total Due</div>
            <div class="stat-value" style="color:var(--danger);"><?= formatCurrency($card['outstanding_balance']) ?></div>
            <div class="stat-change"><?= $bill ? 'Due: ' . date('d M Y', strtotime($bill['due_date'])) : 'No bill' ?></div>
        </div>
    </div>
    <div class="stat-card" style="--accent:var(--warning);">
        <div class="stat-icon" style="background:rgba(245,158,11,0.15);">⚠️</div>
        <div class="stat-info">
            <div class="stat-label">Minimum Due</div>
            <div class="stat-value" style="color:var(--warning);"><?= $bill ? formatCurrency($bill['minimum_due']) : '—' ?></div>
            <div class="stat-change">Pay to avoid penalty</div>
        </div>
    </div>
    <div class="stat-card" style="--accent:var(--success);">
        <div class="stat-icon" style="background:rgba(16,185,129,0.15);">✅</div>
        <div class="stat-info">
            <div class="stat-label">Available Balance</div>
            <div class="stat-value" style="color:var(--success);"><?= formatCurrency($card['available_balance']) ?></div>
            <div class="stat-change">After payment</div>
        </div>
    </div>
</div>

<?php if ($payMsg): ?>
<div style="background:<?= $payType==='success' ? 'rgba(16,185,129,0.1)' : 'rgba(220,38,38,0.1)' ?>;border:1px solid <?= $payType==='success' ? 'rgba(16,185,129,0.3)' : 'rgba(220,38,38,0.3)' ?>;border-radius:12px;padding:16px 20px;margin-bottom:20px;display:flex;align-items:center;gap:10px;color:<?= $payType==='success' ? '#34D399' : '#F87171' ?>;">
    <?= $payMsg ?>
</div>
<?php endif; ?>

<div class="grid-2">
    <!-- Payment Form -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Make a Payment</h3>
        </div>
        <div class="card-body">
            <form method="POST" id="pay-form">
                <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
                <input type="hidden" name="pay" value="1">

                <!-- Quick Amount Buttons -->
                <div class="form-group">
                    <label class="form-label">Quick Amount</label>
                    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px;">
                        <?php
                        $quickAmts = [];
                        if ($bill) {
                            $quickAmts['Minimum Due'] = $bill['minimum_due'];
                            $quickAmts['Half Due']    = round($card['outstanding_balance'] / 2);
                        }
                        $quickAmts['Total Due'] = $card['outstanding_balance'];
                        foreach($quickAmts as $label => $amt): ?>
                        <button type="button" class="btn btn-ghost btn-sm" onclick="document.getElementById('pay-amount').value='<?= $amt ?>'">
                            <?= $label ?><br><small style="color:var(--primary-light);"><?= formatCurrency($amt) ?></small>
                        </button>
                        <?php endforeach; ?>
                    </div>
                    <input type="number" id="pay-amount" name="amount" class="form-control"
                           placeholder="Enter amount" min="1" max="<?= $card['outstanding_balance'] ?>"
                           step="0.01" required>
                </div>

                <!-- Payment Method -->
                <div class="form-group">
                    <label class="form-label">Payment Method</label>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
                        <?php
                        $methods = [
                            ['upi','📱','UPI Payment','Google Pay, PhonePe, etc.'],
                            ['card','💳','Debit Card','Visa, Mastercard'],
                            ['netbanking','🏦','Net Banking','Internet banking'],
                            ['emi','📆','EMI','Pay in installments'],
                        ];
                        foreach($methods as $m): ?>
                        <label class="payment-method-label" style="cursor:pointer;">
                            <input type="radio" name="payment_method" value="<?= $m[0] ?>" style="display:none;" <?= $m[0]==='upi'?'checked':'' ?> onchange="this.closest('.payment-method-label').classList.add('selected')">
                            <div class="payment-method-card" id="pm-<?= $m[0] ?>" onclick="selectPayMethod('<?= $m[0] ?>')">
                                <div style="font-size:1.5rem;"><?= $m[1] ?></div>
                                <div style="font-weight:700;font-size:0.88rem;"><?= $m[2] ?></div>
                                <div style="font-size:0.75rem;color:var(--text-muted);"><?= $m[3] ?></div>
                            </div>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- UPI ID field (shown only for UPI) -->
                <div class="form-group" id="upi-field">
                    <label class="form-label">UPI ID</label>
                    <input type="text" class="form-control" placeholder="yourname@upi" id="upi-id">
                </div>

                <button type="submit" class="btn btn-primary btn-block" id="pay-btn"
                        <?= $card['outstanding_balance'] <= 0 ? 'disabled' : '' ?>>
                    <?= $card['outstanding_balance'] <= 0 ? '✅ No Outstanding Balance' : '💸 Pay Now' ?>
                </button>

                <p style="text-align:center;font-size:0.78rem;color:var(--text-muted);margin-top:12px;">
                    🔒 Secured by 256-bit SSL encryption
                </p>
            </form>
        </div>
    </div>

    <!-- Billing Details -->
    <div style="display:grid;gap:16px;align-content:start;">
        <!-- Current Bill -->
        <?php if ($bill): ?>
        <div class="card">
            <div class="card-header"><h3 class="card-title">Current Bill</h3></div>
            <div class="card-body">
                <?php
                $billItems = [
                    ['Bill Month', date('F Y', mktime(0,0,0,$bill['bill_month'],1,$bill['bill_year']))],
                    ['Total Due',  formatCurrency($bill['total_due'])],
                    ['Minimum Due', formatCurrency($bill['minimum_due'])],
                    ['Interest', formatCurrency($bill['interest_charge'])],
                    ['Due Date', date('d M Y', strtotime($bill['due_date']))],
                    ['Status', ucfirst($bill['status'])],
                ];
                foreach($billItems as $bi): ?>
                <div style="display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid var(--border);font-size:0.88rem;">
                    <span style="color:var(--text-muted);"><?= $bi[0] ?></span>
                    <span style="font-weight:600;"><?= $bi[1] ?></span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Payment Tips -->
        <div class="card">
            <div class="card-body">
                <h4 style="margin-bottom:14px;">💡 Payment Tips</h4>
                <?php
                $tips = [
                    ['✅','Pay total due to avoid interest charges on the remaining balance.'],
                    ['⚡','UPI payments are processed instantly with zero fees.'],
                    ['📅','Set up auto-pay to never miss a due date.'],
                    ['🏆','Paying on time improves your credit score.'],
                ];
                foreach($tips as $tip): ?>
                <div style="display:flex;gap:8px;margin-bottom:10px;font-size:0.82rem;">
                    <span style="flex-shrink:0;"><?= $tip[0] ?></span>
                    <span style="color:var(--text-muted);"><?= $tip[1] ?></span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<?php endif; ?>

</div><!-- /content-area -->
</div><!-- /main-wrapper -->
<div id="toast-container"></div>

<style>
.payment-method-card {
    border:1.5px solid var(--border);
    border-radius:12px;
    padding:14px;
    text-align:center;
    cursor:pointer;
    transition:all 0.2s;
    background:var(--glass);
}
.payment-method-card:hover { border-color:var(--primary); background:rgba(37,99,235,0.08); }
.payment-method-card.active { border-color:var(--primary); background:rgba(37,99,235,0.15); box-shadow:0 0 0 3px var(--primary-glow); }
</style>

<script src="../assets/js/main.js"></script>
<script>
// Select payment method
let selectedMethod = 'upi';
function selectPayMethod(method) {
    selectedMethod = method;
    document.querySelectorAll('.payment-method-card').forEach(el => el.classList.remove('active'));
    document.getElementById('pm-' + method).classList.add('active');
    document.querySelector(`input[name=payment_method][value=${method}]`).checked = true;

    // Show/hide UPI field
    document.getElementById('upi-field').style.display = method === 'upi' ? 'block' : 'none';
}

// Init default
selectPayMethod('upi');

// Loading state on submit
document.getElementById('pay-form')?.addEventListener('submit', function(e) {
    const amount = parseFloat(document.getElementById('pay-amount').value);
    if (isNaN(amount) || amount <= 0) {
        e.preventDefault();
        Toast.error('Invalid Amount', 'Please enter a valid payment amount.');
        return;
    }
    const btn = document.getElementById('pay-btn');
    btn.innerHTML = '<span class="spinner"></span> Processing Payment...';
    btn.disabled = true;
});
</script>
</body>
</html>
