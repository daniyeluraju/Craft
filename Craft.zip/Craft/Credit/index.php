<?php
/**
 * Root Redirect
 * Secure Credit Card Management System
 */
require_once 'includes/auth.php';

if (isLoggedIn()) {
    if (isAdmin()) {
        header('Location: admin/dashboard.php');
    } else {
        header('Location: user/dashboard.php');
    }
} else {
    header('Location: public/index.php');
}
exit;
