-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 16, 2026 at 08:00 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `creditcard_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_logs`
--

CREATE TABLE `admin_logs` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `action` varchar(200) NOT NULL,
  `target_table` varchar(100) DEFAULT NULL,
  `target_id` int(11) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_logs`
--

INSERT INTO `admin_logs` (`id`, `admin_id`, `action`, `target_table`, `target_id`, `details`, `ip_address`, `created_at`) VALUES
(1, 1, 'User blocked', 'users', 5, 'Blocked user Alice Johnson due to suspicious activity', '127.0.0.1', '2026-04-16 09:39:43'),
(2, 1, 'Card assigned', 'credit_cards', 1, 'Assigned Visa card to John Doe with limit ₹1,00,000', '127.0.0.1', '2026-04-16 09:39:43'),
(3, 1, 'Transaction flagged', 'transactions', 11, 'Flagged suspicious transaction TXN20240111001 for ₹25,000', '127.0.0.1', '2026-04-16 09:39:43'),
(4, 1, 'User blocked', 'users', 5, 'Blocked user Alice Johnson due to suspicious activity', '127.0.0.1', '2026-04-16 09:39:50'),
(5, 1, 'Card assigned', 'credit_cards', 1, 'Assigned Visa card to John Doe with limit Ôé╣1,00,000', '127.0.0.1', '2026-04-16 09:39:50'),
(6, 1, 'Transaction flagged', 'transactions', 11, 'Flagged suspicious transaction TXN20240111001 for Ôé╣25,000', '127.0.0.1', '2026-04-16 09:39:50'),
(7, 1, 'User blocked', 'users', 5, 'Blocked user Alice Johnson due to suspicious activity', '127.0.0.1', '2026-04-16 09:44:04'),
(8, 1, 'Card assigned', 'credit_cards', 1, 'Assigned Visa card to John Doe with limit ₹1,00,000', '127.0.0.1', '2026-04-16 09:44:04'),
(9, 1, 'Transaction flagged', 'transactions', 11, 'Flagged suspicious transaction TXN20240111001 for ₹25,000', '127.0.0.1', '2026-04-16 09:44:04'),
(10, 1, 'Admin logged in', 'users', 1, 'Admin login from IP: ::1', '::1', '2026-04-16 09:45:44'),
(11, 1, 'Admin logged in', 'users', 1, 'Admin login from IP: ::1', '::1', '2026-04-16 09:46:10'),
(12, 1, 'Admin logged in', 'users', 1, 'Admin login from IP: ::1', '::1', '2026-04-16 10:39:21'),
(13, 1, 'Added new user', 'users', 16, 'Added user mama@gmail.com', '::1', '2026-04-16 10:40:04'),
(14, 1, 'Assigned credit card', 'credit_cards', 13, 'Assigned Rupay card to user 16', '::1', '2026-04-16 10:42:06'),
(15, 1, 'Admin logged in', 'users', 1, 'Admin login from IP: ::1', '::1', '2026-04-16 10:46:21'),
(16, 1, 'Deleted user', 'users', 5, 'Admin deleted user ID 5', '::1', '2026-04-16 10:46:30'),
(17, 1, 'Admin logged in', 'users', 1, 'Admin login from IP: ::1', '::1', '2026-04-16 10:48:43'),
(18, 1, 'Admin logged in', 'users', 1, 'Admin login from IP: ::1', '::1', '2026-04-16 10:52:19'),
(19, 1, 'Admin logged in', 'users', 1, 'Admin login from IP: ::1', '::1', '2026-04-16 10:54:19'),
(20, 1, 'Changed status to blocked', 'users', 4, NULL, '::1', '2026-04-16 10:57:17'),
(21, 1, 'Changed status to active', 'users', 4, NULL, '::1', '2026-04-16 10:57:20'),
(22, 1, 'Admin logged in', 'users', 1, 'Admin login from IP: ::1', '::1', '2026-04-16 11:23:12');

-- --------------------------------------------------------

--
-- Table structure for table `bills`
--

CREATE TABLE `bills` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `card_id` int(11) NOT NULL,
  `bill_month` tinyint(4) NOT NULL,
  `bill_year` smallint(6) NOT NULL,
  `total_due` decimal(12,2) NOT NULL DEFAULT 0.00,
  `minimum_due` decimal(12,2) NOT NULL DEFAULT 0.00,
  `interest_charge` decimal(12,2) DEFAULT 0.00,
  `due_date` date NOT NULL,
  `status` enum('unpaid','partially_paid','paid','overdue') DEFAULT 'unpaid',
  `generated_at` datetime DEFAULT current_timestamp(),
  `paid_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bills`
--

INSERT INTO `bills` (`id`, `user_id`, `card_id`, `bill_month`, `bill_year`, `total_due`, `minimum_due`, `interest_charge`, `due_date`, `status`, `generated_at`, `paid_at`) VALUES
(1, 2, 1, 2, 2026, 23341.50, 1228.50, 0.00, '2026-04-15', 'partially_paid', '2026-04-16 09:39:43', NULL),
(2, 2, 1, 1, 2026, 18000.00, 900.00, 0.00, '2026-03-15', 'paid', '2026-04-16 09:39:43', NULL),
(3, 3, 2, 2, 2026, 23000.00, 1150.00, 0.00, '2026-04-15', 'unpaid', '2026-04-16 09:39:43', NULL),
(4, 4, 3, 2, 2026, 20000.00, 1000.00, 0.00, '2026-04-15', 'unpaid', '2026-04-16 09:39:43', NULL),
(5, 2, 1, 2, 2026, 24570.00, 1228.50, 0.00, '2026-04-15', 'unpaid', '2026-04-16 09:39:50', NULL),
(6, 2, 1, 1, 2026, 18000.00, 900.00, 0.00, '2026-03-15', 'paid', '2026-04-16 09:39:50', NULL),
(7, 3, 2, 2, 2026, 23000.00, 1150.00, 0.00, '2026-04-15', 'unpaid', '2026-04-16 09:39:50', NULL),
(8, 4, 3, 2, 2026, 20000.00, 1000.00, 0.00, '2026-04-15', 'unpaid', '2026-04-16 09:39:50', NULL),
(9, 2, 1, 2, 2026, 24570.00, 1228.50, 0.00, '2026-04-15', 'unpaid', '2026-04-16 09:44:04', NULL),
(10, 2, 1, 1, 2026, 18000.00, 900.00, 0.00, '2026-03-15', 'paid', '2026-04-16 09:44:04', NULL),
(11, 3, 2, 2, 2026, 23000.00, 1150.00, 0.00, '2026-04-15', 'unpaid', '2026-04-16 09:44:04', NULL),
(12, 4, 3, 2, 2026, 20000.00, 1000.00, 0.00, '2026-04-15', 'unpaid', '2026-04-16 09:44:04', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE `complaints` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `category` enum('transaction','billing','card','security','other') DEFAULT 'other',
  `status` enum('open','in_progress','resolved','closed') DEFAULT 'open',
  `admin_reply` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `resolved_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`id`, `user_id`, `subject`, `message`, `category`, `status`, `admin_reply`, `created_at`, `updated_at`, `resolved_at`) VALUES
(1, 2, 'Unauthorized Transaction', 'I did not authorize the ₹25,000 transaction on March 11. Please investigate.', 'security', 'in_progress', NULL, '2026-04-16 09:39:43', '2026-04-16 09:39:43', NULL),
(2, 3, 'Incorrect Bill Amount', 'My bill shows ₹23,000 but I believe it should be ₹15,000. Please review.', 'billing', 'open', NULL, '2026-04-16 09:39:43', '2026-04-16 09:39:43', NULL),
(3, 4, 'Card Blocked Unexpectedly', 'My card was blocked without any notification. Please unblock it.', 'card', 'resolved', NULL, '2026-04-16 09:39:43', '2026-04-16 09:39:43', NULL),
(4, 2, 'Unauthorized Transaction', 'I did not authorize the Ôé╣25,000 transaction on March 11. Please investigate.', 'security', 'in_progress', NULL, '2026-04-16 09:39:50', '2026-04-16 09:39:50', NULL),
(5, 3, 'Incorrect Bill Amount', 'My bill shows Ôé╣23,000 but I believe it should be Ôé╣15,000. Please review.', 'billing', 'open', NULL, '2026-04-16 09:39:50', '2026-04-16 09:39:50', NULL),
(6, 4, 'Card Blocked Unexpectedly', 'My card was blocked without any notification. Please unblock it.', 'card', 'resolved', NULL, '2026-04-16 09:39:50', '2026-04-16 09:39:50', NULL),
(7, 2, 'Unauthorized Transaction', 'I did not authorize the ₹25,000 transaction on March 11. Please investigate.', 'security', 'in_progress', NULL, '2026-04-16 09:44:04', '2026-04-16 09:44:04', NULL),
(8, 3, 'Incorrect Bill Amount', 'My bill shows ₹23,000 but I believe it should be ₹15,000. Please review.', 'billing', 'open', NULL, '2026-04-16 09:44:04', '2026-04-16 09:44:04', NULL),
(9, 4, 'Card Blocked Unexpectedly', 'My card was blocked without any notification. Please unblock it.', 'card', 'resolved', NULL, '2026-04-16 09:44:04', '2026-04-16 09:44:04', NULL),
(10, 2, 'hi', 'test', 'other', 'open', NULL, '2026-04-16 10:39:01', '2026-04-16 10:39:01', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact_messages`
--

INSERT INTO `contact_messages` (`id`, `name`, `email`, `subject`, `message`, `is_read`, `created_at`) VALUES
(1, 'Test User', 'test@example.com', 'Login Issue', 'I am unable to login to my account. Please help.', 0, '2026-04-16 09:39:43'),
(2, 'Support Inquiry', 'inquiry@example.com', 'Card Limit Increase', 'I would like to request an increase in my credit limit.', 0, '2026-04-16 09:39:43'),
(3, 'Test User', 'test@example.com', 'Login Issue', 'I am unable to login to my account. Please help.', 0, '2026-04-16 09:39:50'),
(4, 'Support Inquiry', 'inquiry@example.com', 'Card Limit Increase', 'I would like to request an increase in my credit limit.', 0, '2026-04-16 09:39:50'),
(5, 'Test User', 'test@example.com', 'Login Issue', 'I am unable to login to my account. Please help.', 0, '2026-04-16 09:44:04'),
(6, 'Support Inquiry', 'inquiry@example.com', 'Card Limit Increase', 'I would like to request an increase in my credit limit.', 0, '2026-04-16 09:44:04');

-- --------------------------------------------------------

--
-- Table structure for table `credit_cards`
--

CREATE TABLE `credit_cards` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `card_number` varchar(20) NOT NULL,
  `card_holder` varchar(100) NOT NULL,
  `card_type` enum('Visa','MasterCard','Rupay','Amex') DEFAULT 'Visa',
  `expiry_month` tinyint(4) NOT NULL,
  `expiry_year` smallint(6) NOT NULL,
  `cvv` varchar(255) NOT NULL,
  `credit_limit` decimal(12,2) DEFAULT 50000.00,
  `available_balance` decimal(12,2) DEFAULT 50000.00,
  `outstanding_balance` decimal(12,2) DEFAULT 0.00,
  `status` enum('active','blocked','expired','pending') DEFAULT 'active',
  `issued_date` date NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `credit_cards`
--

INSERT INTO `credit_cards` (`id`, `user_id`, `card_number`, `card_holder`, `card_type`, `expiry_month`, `expiry_year`, `cvv`, `credit_limit`, `available_balance`, `outstanding_balance`, `status`, `issued_date`, `created_at`, `updated_at`) VALUES
(1, 2, '4532015112830366', 'John Doe', 'Visa', 12, 2028, '$2y$10$hashedcvv1', 100000.00, 76658.50, 23341.50, 'active', '2024-01-15', '2026-04-16 09:39:43', '2026-04-16 10:38:35'),
(2, 3, '5425233430109903', 'Jane Smith', 'MasterCard', 6, 2027, '$2y$10$hashedcvv2', 75000.00, 52000.00, 23000.00, 'active', '2024-02-20', '2026-04-16 09:39:43', '2026-04-16 09:39:43'),
(3, 4, '374251018720955', 'Robert Brown', 'Amex', 9, 2026, '$2y$10$hashedcvv3', 150000.00, 130000.00, 20000.00, 'active', '2023-09-10', '2026-04-16 09:39:43', '2026-04-16 09:39:43'),
(13, 16, '5272097930363654', 'Mama', 'Rupay', 1, 2030, '$2y$12$36OJwabbj.8QjUDBYcH01.ZoBq7j1UTvbIkAP7JWuvadAOMvMDexm', 60000.00, 49000.00, 1000.00, 'active', '2026-04-16', '2026-04-16 10:42:06', '2026-04-16 10:52:06');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `message` text NOT NULL,
  `type` enum('transaction','payment','alert','info','warning') DEFAULT 'info',
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `title`, `message`, `type`, `is_read`, `created_at`) VALUES
(1, 2, 'Transaction Alert', 'Debit of ₹2,500 at Amazon India on 01 Mar 2026.', 'transaction', 0, '2026-04-16 09:39:43'),
(2, 2, 'Payment Due Reminder', 'Your bill of ₹24,570 is due on 15 Apr 2026. Please pay to avoid interest.', 'payment', 0, '2026-04-16 09:39:43'),
(3, 2, '⚠️ Suspicious Activity Detected', 'An unusual transaction of ₹25,000 was flagged. Please verify.', 'alert', 0, '2026-04-16 09:39:43'),
(4, 2, 'Cashback Credited', '₹500 cashback has been credited to your account.', 'info', 1, '2026-04-16 09:39:43'),
(5, 3, 'Transaction Alert', 'Debit of ₹4,500 at Myntra on 01 Mar 2026.', 'transaction', 0, '2026-04-16 09:39:43'),
(6, 3, 'Payment Due Reminder', 'Your bill of ₹23,000 is due on 15 Apr 2026.', 'payment', 0, '2026-04-16 09:39:43'),
(7, 4, 'Transaction Alert', 'Debit of ₹12,000 at Apple Store on 01 Mar 2026.', 'transaction', 1, '2026-04-16 09:39:43'),
(8, 1, 'New User Registered', 'A new user has registered on the platform.', 'info', 0, '2026-04-16 09:39:43'),
(9, 2, 'Transaction Alert', 'Debit of Ôé╣2,500 at Amazon India on 01 Mar 2026.', 'transaction', 0, '2026-04-16 09:39:50'),
(10, 2, 'Payment Due Reminder', 'Your bill of Ôé╣24,570 is due on 15 Apr 2026. Please pay to avoid interest.', 'payment', 0, '2026-04-16 09:39:50'),
(11, 2, 'ÔÜá´©Å Suspicious Activity Detected', 'An unusual transaction of Ôé╣25,000 was flagged. Please verify.', 'alert', 0, '2026-04-16 09:39:50'),
(12, 2, 'Cashback Credited', 'Ôé╣500 cashback has been credited to your account.', 'info', 1, '2026-04-16 09:39:50'),
(13, 3, 'Transaction Alert', 'Debit of Ôé╣4,500 at Myntra on 01 Mar 2026.', 'transaction', 0, '2026-04-16 09:39:50'),
(14, 3, 'Payment Due Reminder', 'Your bill of Ôé╣23,000 is due on 15 Apr 2026.', 'payment', 0, '2026-04-16 09:39:50'),
(15, 4, 'Transaction Alert', 'Debit of Ôé╣12,000 at Apple Store on 01 Mar 2026.', 'transaction', 1, '2026-04-16 09:39:50'),
(16, 1, 'New User Registered', 'A new user has registered on the platform.', 'info', 0, '2026-04-16 09:39:50'),
(17, 2, 'Transaction Alert', 'Debit of ₹2,500 at Amazon India on 01 Mar 2026.', 'transaction', 0, '2026-04-16 09:44:04'),
(18, 2, 'Payment Due Reminder', 'Your bill of ₹24,570 is due on 15 Apr 2026. Please pay to avoid interest.', 'payment', 0, '2026-04-16 09:44:04'),
(19, 2, '⚠️ Suspicious Activity Detected', 'An unusual transaction of ₹25,000 was flagged. Please verify.', 'alert', 0, '2026-04-16 09:44:04'),
(20, 2, 'Cashback Credited', '₹500 cashback has been credited to your account.', 'info', 1, '2026-04-16 09:44:04'),
(21, 3, 'Transaction Alert', 'Debit of ₹4,500 at Myntra on 01 Mar 2026.', 'transaction', 0, '2026-04-16 09:44:04'),
(22, 3, 'Payment Due Reminder', 'Your bill of ₹23,000 is due on 15 Apr 2026.', 'payment', 0, '2026-04-16 09:44:04'),
(23, 4, 'Transaction Alert', 'Debit of ₹12,000 at Apple Store on 01 Mar 2026.', 'transaction', 1, '2026-04-16 09:44:04'),
(24, 1, 'New User Registered', 'A new user has registered on the platform.', 'info', 0, '2026-04-16 09:44:04'),
(25, 2, '💳 Payment Successful', '₹1,228.50 paid via UPI. Ref: PAY20260416321495', 'payment', 0, '2026-04-16 10:38:35'),
(26, 2, '📝 Complaint Submitted', 'Your complaint \'hi\' has been submitted. We\'ll respond within 24 hours.', 'info', 0, '2026-04-16 10:39:01'),
(27, 16, '💳 Credit Card Assigned!', 'A Rupay credit card has been assigned to your account with limit ₹60,000.00', 'info', 0, '2026-04-16 10:42:06'),
(28, 16, '💳 Purchase Successful', '₹1,000.00 spent at Apollo Pharmacy. Ref: TXN20260416E77C55.', 'transaction', 0, '2026-04-16 10:52:06'),
(29, 4, '⛔ Account Blocked', 'Your account has been blocked by admin. Contact support.', 'alert', 0, '2026-04-16 10:57:17'),
(30, 4, '✅ Account Activated', 'Your account has been reactivated.', 'alert', 0, '2026-04-16 10:57:20'),
(31, 17, '🎉 Welcome to CreditGuard!', 'Your account has been created. A credit card will be assigned by admin shortly.', 'info', 0, '2026-04-16 11:25:26');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `card_id` int(11) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `payment_method` enum('upi','card','netbanking','emi') NOT NULL,
  `payment_reference` varchar(100) NOT NULL,
  `status` enum('success','pending','failed') DEFAULT 'pending',
  `payment_date` datetime DEFAULT current_timestamp(),
  `remarks` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `user_id`, `card_id`, `amount`, `payment_method`, `payment_reference`, `status`, `payment_date`, `remarks`) VALUES
(1, 2, 1, 10000.00, 'upi', 'PAY_UPI_20240312001', 'success', '2026-03-12 09:05:00', NULL),
(2, 2, 1, 8000.00, 'netbanking', 'PAY_NB_20240215001', 'success', '2026-03-15 11:00:00', NULL),
(3, 3, 2, 5000.00, 'card', 'PAY_CARD_20240310001', 'success', '2026-03-10 14:00:00', NULL),
(10, 2, 1, 1228.50, 'upi', 'PAY20260416321495', 'success', '2026-04-16 10:38:35', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `card_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `transaction_type` enum('debit','credit','payment','refund') NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `description` varchar(255) NOT NULL,
  `merchant` varchar(150) DEFAULT NULL,
  `category` enum('shopping','food','travel','entertainment','utilities','healthcare','fuel','education','other') DEFAULT 'other',
  `status` enum('success','pending','failed','flagged') DEFAULT 'success',
  `reference_no` varchar(50) NOT NULL,
  `transaction_date` datetime DEFAULT current_timestamp(),
  `is_suspicious` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `card_id`, `user_id`, `transaction_type`, `amount`, `description`, `merchant`, `category`, `status`, `reference_no`, `transaction_date`, `is_suspicious`) VALUES
(1, 1, 2, 'debit', 2500.00, 'Amazon Purchase', 'Amazon India', 'shopping', 'success', 'TXN20240101001', '2026-03-01 10:30:00', 0),
(2, 1, 2, 'debit', 850.00, 'Swiggy Order', 'Swiggy', 'food', 'success', 'TXN20240102001', '2026-03-02 13:15:00', 0),
(3, 1, 2, 'debit', 5200.00, 'IndiGo Flight', 'IndiGo Airlines', 'travel', 'success', 'TXN20240103001', '2026-03-03 08:00:00', 0),
(4, 1, 2, 'debit', 450.00, 'Netflix Subscription', 'Netflix', 'entertainment', 'success', 'TXN20240104001', '2026-03-04 20:00:00', 0),
(5, 1, 2, 'debit', 3200.00, 'Electricity Bill', 'BSES Rajdhani', 'utilities', 'success', 'TXN20240105001', '2026-03-05 11:00:00', 0),
(6, 1, 2, 'debit', 1200.00, 'Fuel - HPCL', 'HPCL Pump', 'fuel', 'success', 'TXN20240106001', '2026-03-06 09:30:00', 0),
(7, 1, 2, 'debit', 8500.00, 'Hospital Bill', 'Apollo Hospital', 'healthcare', 'success', 'TXN20240107001', '2026-03-07 16:00:00', 0),
(8, 1, 2, 'credit', 500.00, 'Cashback Reward', 'Bank Reward', 'other', 'success', 'TXN20240108001', '2026-03-08 12:00:00', 0),
(9, 1, 2, 'debit', 2870.00, 'Zara Shopping', 'Zara Store', 'shopping', 'success', 'TXN20240109001', '2026-03-09 15:30:00', 0),
(10, 1, 2, 'debit', 1500.00, 'Udemy Course', 'Udemy', 'education', 'success', 'TXN20240110001', '2026-03-10 10:00:00', 0),
(11, 1, 2, 'debit', 25000.00, 'Suspicious Large Transfer', 'Unknown Merchant', 'other', 'flagged', 'TXN20240111001', '2026-03-11 03:00:00', 0),
(12, 1, 2, 'payment', 10000.00, 'Bill Payment', 'Self', 'other', 'success', 'PAY20240112001', '2026-03-12 09:00:00', 0),
(13, 2, 3, 'debit', 4500.00, 'Myntra Shopping', 'Myntra', 'shopping', 'success', 'TXN20240101002', '2026-03-01 14:00:00', 0),
(14, 2, 3, 'debit', 1800.00, 'OYO Rooms', 'OYO', 'travel', 'success', 'TXN20240102002', '2026-03-02 18:00:00', 0),
(15, 3, 4, 'debit', 12000.00, 'Apple Store', 'Apple India', 'shopping', 'success', 'TXN20240101003', '2026-03-01 12:00:00', 0),
(16, 3, 4, 'debit', 5000.00, 'Gold Gym Membership', 'Gold Gym', 'healthcare', 'success', 'TXN20240102003', '2026-03-02 07:00:00', 0),
(49, 1, 2, 'payment', 1228.50, 'Bill Payment via UPI', NULL, 'other', 'success', 'PAY20260416321495', '2026-04-16 10:38:35', 0),
(50, 13, 16, 'debit', 1000.00, 'Purchase at Apollo Pharmacy', 'Apollo Pharmacy', '', 'success', 'TXN20260416E77C55', '2026-04-16 10:52:06', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','user') DEFAULT 'user',
  `status` enum('active','blocked','pending') DEFAULT 'pending',
  `otp` varchar(10) DEFAULT NULL,
  `otp_expires` datetime DEFAULT NULL,
  `profile_pic` varchar(255) DEFAULT 'default.png',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `mobile`, `password`, `role`, `status`, `otp`, `otp_expires`, `profile_pic`, `created_at`, `updated_at`) VALUES
(1, 'Super Admin', 'admin@creditcard.com', '9999900000', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'active', NULL, NULL, 'default.png', '2026-04-16 09:39:43', '2026-04-16 09:39:43'),
(2, 'John Doe', 'john@example.com', '9876543210', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user', 'active', NULL, NULL, 'default.png', '2026-04-16 09:39:43', '2026-04-16 09:39:43'),
(3, 'Jane Smith', 'jane@example.com', '9876543211', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user', 'active', NULL, NULL, 'default.png', '2026-04-16 09:39:43', '2026-04-16 09:39:43'),
(4, 'Robert Brown', 'robert@example.com', '9876543212', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user', 'active', NULL, NULL, 'default.png', '2026-04-16 09:39:43', '2026-04-16 10:57:20'),
(16, 'mama', 'mama@gmail.com', '7412589630', '$2y$12$jf4W.Ej1GdNTsgeYYGBjoOq42wpR4hq5vVbJp9rj9oummBJuc/BZ6', 'user', 'active', NULL, NULL, 'default.png', '2026-04-16 10:40:04', '2026-04-16 10:40:04'),
(17, 'subbu', 'subbu@gmail.com', '8523697412', '$2y$12$tuw7pW4NRm7vNgGNXWYz9eU/Y/YO34Y4CEeQLkeJ1N7bEaA6xyvC6', 'user', 'active', NULL, NULL, 'default.png', '2026-04-16 11:25:26', '2026-04-16 11:25:26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_logs`
--
ALTER TABLE `admin_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_admin_id` (`admin_id`),
  ADD KEY `idx_date` (`created_at`);

--
-- Indexes for table `bills`
--
ALTER TABLE `bills`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_card_id` (`card_id`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `complaints`
--
ALTER TABLE `complaints`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_read` (`is_read`);

--
-- Indexes for table `credit_cards`
--
ALTER TABLE `credit_cards`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `card_number` (`card_number`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_card_number` (`card_number`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_read` (`is_read`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `payment_reference` (`payment_reference`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_card_id` (`card_id`),
  ADD KEY `idx_date` (`payment_date`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `reference_no` (`reference_no`),
  ADD KEY `idx_card_id` (`card_id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_date` (`transaction_date`),
  ADD KEY `idx_type` (`transaction_type`),
  ADD KEY `idx_suspicious` (`is_suspicious`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_email` (`email`),
  ADD KEY `idx_role` (`role`),
  ADD KEY `idx_status` (`status`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_logs`
--
ALTER TABLE `admin_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `bills`
--
ALTER TABLE `bills`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `complaints`
--
ALTER TABLE `complaints`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `contact_messages`
--
ALTER TABLE `contact_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `credit_cards`
--
ALTER TABLE `credit_cards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin_logs`
--
ALTER TABLE `admin_logs`
  ADD CONSTRAINT `admin_logs_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `bills`
--
ALTER TABLE `bills`
  ADD CONSTRAINT `bills_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `bills_ibfk_2` FOREIGN KEY (`card_id`) REFERENCES `credit_cards` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `complaints`
--
ALTER TABLE `complaints`
  ADD CONSTRAINT `complaints_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `credit_cards`
--
ALTER TABLE `credit_cards`
  ADD CONSTRAINT `credit_cards_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`card_id`) REFERENCES `credit_cards` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`card_id`) REFERENCES `credit_cards` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `transactions_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
