<?php
/**
 * Database Setup Script - Run once to create tables and sample data
 */

$host = 'localhost';
$user = 'root';
$pass = '';

try {
    // Connect without DB first
    $pdo = new PDO("mysql:host=$host;charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    // Create and select DB
    $pdo->exec("CREATE DATABASE IF NOT EXISTS creditcard_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("USE creditcard_db");

    // Read and execute SQL file
    $sql = file_get_contents(__DIR__ . '/database/creditcard.sql');

    // Remove USE statement since we already selected it
    $sql = preg_replace('/USE\s+creditcard_db\s*;/i', '', $sql);
    $sql = preg_replace('/CREATE DATABASE.*?;/si', '', $sql);

    // Split on semicolons and execute each statement
    $statements = array_filter(array_map('trim', explode(';', $sql)), fn($s) => $s !== '');
    $success = 0; $errors = [];

    foreach ($statements as $stmt) {
        try {
            $pdo->exec($stmt);
            $success++;
        } catch (PDOException $e) {
            // Ignore duplicate entry errors (sample data may already exist)
            if ($e->getCode() != 23000) {
                $errors[] = $e->getMessage();
            }
        }
    }

    // Verify tables
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    $users  = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $cards  = $pdo->query("SELECT COUNT(*) FROM credit_cards")->fetchColumn();
    $txns   = $pdo->query("SELECT COUNT(*) FROM transactions")->fetchColumn();

    echo "<!DOCTYPE html><html><head><title>Setup Complete</title>";
    echo "<style>body{font-family:Arial,sans-serif;max-width:700px;margin:40px auto;padding:20px;background:#0f172a;color:#e2e8f0;}";
    echo ".ok{color:#10b981;} .err{color:#ef4444;} .card{background:#1e293b;border:1px solid #334155;border-radius:12px;padding:24px;margin:16px 0;}</style></head><body>";
    echo "<h1 style='color:#2563eb;'>✅ Database Setup Complete</h1>";
    echo "<div class='card'>";
    echo "<h3>Database: creditcard_db</h3>";
    echo "<p class='ok'>✓ $success statements executed successfully</p>";
    echo "<p>Tables created: " . implode(', ', $tables) . "</p>";
    echo "<hr style='border-color:#334155;margin:12px 0;'>";
    echo "<p>👥 Users: <strong>$users</strong></p>";
    echo "<p>💳 Credit Cards: <strong>$cards</strong></p>";
    echo "<p>📋 Transactions: <strong>$txns</strong></p>";
    if ($errors) { echo "<p class='err'>Warnings: " . implode('<br>', $errors) . "</p>"; }
    echo "</div>";
    echo "<div class='card'>";
    echo "<h3>🔑 Demo Credentials</h3>";
    echo "<p><strong>Admin:</strong> admin@creditcard.com | <strong>Password:</strong> password</p>";
    echo "<p><strong>User 1:</strong> john@example.com | <strong>Password:</strong> password</p>";
    echo "<p><strong>User 2:</strong> jane@example.com | <strong>Password:</strong> password</p>";
    echo "<p><strong>User 3:</strong> robert@example.com | <strong>Password:</strong> password</p>";
    echo "</div>";
    echo "<div style='margin-top:20px;'>";
    echo "<a href='index.php' style='background:#2563eb;color:white;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:bold;'>🚀 Go to Application →</a>";
    echo "</div>";
    echo "</body></html>";

} catch (PDOException $e) {
    echo "<h1 style='color:red'>❌ Setup Failed</h1>";
    echo "<p>" . $e->getMessage() . "</p>";
    echo "<p>Make sure XAMPP MySQL is running!</p>";
}
