<?php
/**
 * Authentication Helper
 * Secure Credit Card Management System
 */

require_once __DIR__ . '/db.php';

// Start session if not started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
    session_regenerate_id(true);
}

/**
 * Check if user is logged in
 */
function isLoggedIn(): bool {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Check if logged-in user is admin
 */
function isAdmin(): bool {
    return isLoggedIn() && isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

/**
 * Require login – redirect if not authenticated
 */
function requireLogin(string $redirect = BASE_URL . 'public/login.php'): void {
    if (!isLoggedIn()) {
        header("Location: $redirect");
        exit;
    }
}

/**
 * Require admin – redirect if not admin
 */
function requireAdmin(): void {
    requireLogin();
    if (!isAdmin()) {
        header('Location: ' . BASE_URL . 'user/dashboard.php');
        exit;
    }
}

/**
 * Require user role (not admin)
 */
function requireUser(): void {
    requireLogin();
    if (isAdmin()) {
        header('Location: ' . BASE_URL . 'admin/dashboard.php');
        exit;
    }
}

/**
 * Hash password
 */
function hashPassword(string $password): string {
    return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
}

/**
 * Verify password
 */
function verifyPassword(string $password, string $hash): bool {
    return password_verify($password, $hash);
}

/**
 * Generate OTP
 */
function generateOTP(int $length = 6): string {
    return str_pad((string)random_int(0, 999999), $length, '0', STR_PAD_LEFT);
}

/**
 * Get current user data from DB
 */
function getCurrentUser(): ?array {
    global $pdo;
    if (!isLoggedIn()) return null;
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? AND status = 'active'");
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch() ?: null;
}

/**
 * Log admin action
 */
function logAdminAction(string $action, ?string $table = null, ?int $targetId = null, ?string $details = null): void {
    global $pdo;
    if (!isAdmin()) return;
    $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    $stmt = $pdo->prepare("INSERT INTO admin_logs (admin_id, action, target_table, target_id, details, ip_address) VALUES (?,?,?,?,?,?)");
    $stmt->execute([$_SESSION['user_id'], $action, $table, $targetId, $details, $ip]);
}

/**
 * Sanitize input
 */
function sanitize(string $input): string {
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}

/**
 * Generate CSRF token
 */
function generateCSRF(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verify CSRF token
 */
function verifyCSRF(string $token): bool {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Format currency
 */
function formatCurrency(float $amount): string {
    return '₹' . number_format($amount, 2);
}

/**
 * Mask card number
 */
function maskCard(string $cardNumber): string {
    $card = preg_replace('/\D/', '', $cardNumber);
    return str_repeat('*', strlen($card) - 4) . substr($card, -4);
}

/**
 * Format masked card for display (groups of 4)
 */
function formatMaskedCard(string $cardNumber): string {
    $masked = maskCard($cardNumber);
    return implode(' ', str_split($masked, 4));
}

/**
 * Get unread notification count for user
 */
function getUnreadNotificationCount(int $userId): int {
    global $pdo;
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
    $stmt->execute([$userId]);
    return (int)$stmt->fetchColumn();
}
