<?php
/**
 * General Functions
 * Secure Credit Card Management System
 */

require_once __DIR__ . '/db.php';

/**
 * Create notification for a user
 */
function createNotification(int $userId, string $title, string $message, string $type = 'info'): void {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO notifications (user_id, title, message, type) VALUES (?,?,?,?)");
    $stmt->execute([$userId, $title, $message, $type]);
}

/**
 * Get user's credit card
 */
function getUserCard(int $userId): ?array {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM credit_cards WHERE user_id = ? ORDER BY id DESC LIMIT 1");
    $stmt->execute([$userId]);
    return $stmt->fetch() ?: null;
}

/**
 * Get all cards for user
 */
function getUserCards(int $userId): array {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM credit_cards WHERE user_id = ? ORDER BY id DESC");
    $stmt->execute([$userId]);
    return $stmt->fetchAll();
}

/**
 * Get user transactions
 */
function getUserTransactions(int $userId, int $limit = 10, int $offset = 0): array {
    global $pdo;
    $stmt = $pdo->prepare("
        SELECT t.*, c.card_number 
        FROM transactions t 
        JOIN credit_cards c ON t.card_id = c.id 
        WHERE t.user_id = ? 
        ORDER BY t.transaction_date DESC 
        LIMIT ? OFFSET ?
    ");
    $stmt->execute([$userId, $limit, $offset]);
    return $stmt->fetchAll();
}

/**
 * Get transaction count for user
 */
function getUserTransactionCount(int $userId): int {
    global $pdo;
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM transactions WHERE user_id = ?");
    $stmt->execute([$userId]);
    return (int)$stmt->fetchColumn();
}

/**
 * Generate unique reference number
 */
function generateReference(string $prefix = 'TXN'): string {
    return $prefix . date('Ymd') . strtoupper(substr(uniqid(), -6));
}

/**
 * Get current bill for user's card
 */
function getCurrentBill(int $userId, int $cardId): ?array {
    global $pdo;
    $stmt = $pdo->prepare("
        SELECT * FROM bills 
        WHERE user_id = ? AND card_id = ? 
        ORDER BY bill_year DESC, bill_month DESC 
        LIMIT 1
    ");
    $stmt->execute([$userId, $cardId]);
    return $stmt->fetch() ?: null;
}

/**
 * Get spending by category for user
 */
function getSpendingByCategory(int $userId, int $months = 1): array {
    global $pdo;
    $stmt = $pdo->prepare("
        SELECT category, SUM(amount) as total 
        FROM transactions 
        WHERE user_id = ? AND transaction_type = 'debit' 
          AND transaction_date >= DATE_SUB(NOW(), INTERVAL ? MONTH)
          AND status != 'failed'
        GROUP BY category 
        ORDER BY total DESC
    ");
    $stmt->execute([$userId, $months]);
    return $stmt->fetchAll();
}

/**
 * Get monthly spending trend
 */
function getMonthlySpending(int $userId, int $months = 6): array {
    global $pdo;
    $stmt = $pdo->prepare("
        SELECT 
            YEAR(transaction_date) as year,
            MONTH(transaction_date) as month,
            DATE_FORMAT(transaction_date, '%b %Y') as label,
            SUM(CASE WHEN transaction_type = 'debit' THEN amount ELSE 0 END) as spending,
            SUM(CASE WHEN transaction_type IN ('payment','credit') THEN amount ELSE 0 END) as payments
        FROM transactions 
        WHERE user_id = ? AND transaction_date >= DATE_SUB(NOW(), INTERVAL ? MONTH)
        GROUP BY YEAR(transaction_date), MONTH(transaction_date)
        ORDER BY year ASC, month ASC
    ");
    $stmt->execute([$userId, $months]);
    return $stmt->fetchAll();
}

/**
 * Admin: Get total stats
 */
function getAdminStats(): array {
    global $pdo;
    $stats = [];

    $stats['total_users'] = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='user'")->fetchColumn();
    $stats['active_users'] = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='user' AND status='active'")->fetchColumn();
    $stats['blocked_users'] = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='user' AND status='blocked'")->fetchColumn();
    $stats['total_cards'] = (int)$pdo->query("SELECT COUNT(*) FROM credit_cards")->fetchColumn();
    $stats['active_cards'] = (int)$pdo->query("SELECT COUNT(*) FROM credit_cards WHERE status='active'")->fetchColumn();
    $stats['total_transactions'] = (int)$pdo->query("SELECT COUNT(*) FROM transactions")->fetchColumn();
    $stats['suspicious_transactions'] = (int)$pdo->query("SELECT COUNT(*) FROM transactions WHERE is_suspicious=1 OR status='flagged'")->fetchColumn();
    $stats['total_revenue'] = (float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE status='success'")->fetchColumn();
    $stats['open_complaints'] = (int)$pdo->query("SELECT COUNT(*) FROM complaints WHERE status='open'")->fetchColumn();
    $stats['total_outstanding'] = (float)$pdo->query("SELECT COALESCE(SUM(outstanding_balance),0) FROM credit_cards")->fetchColumn();

    return $stats;
}

/**
 * Admin: Monthly revenue data
 */
function getAdminMonthlyRevenue(int $months = 6): array {
    global $pdo;
    $stmt = $pdo->prepare("
        SELECT 
            DATE_FORMAT(payment_date, '%b %Y') as label,
            SUM(amount) as revenue,
            COUNT(*) as count
        FROM payments 
        WHERE status='success' AND payment_date >= DATE_SUB(NOW(), INTERVAL ? MONTH)
        GROUP BY YEAR(payment_date), MONTH(payment_date)
        ORDER BY payment_date ASC
    ");
    $stmt->execute([$months]);
    return $stmt->fetchAll();
}

/**
 * Time ago helper
 */
function timeAgo(string $datetime): string {
    $time = strtotime($datetime);
    $diff = time() - $time;
    if ($diff < 60) return 'Just now';
    if ($diff < 3600) return floor($diff / 60) . ' mins ago';
    if ($diff < 86400) return floor($diff / 3600) . ' hrs ago';
    if ($diff < 604800) return floor($diff / 86400) . ' days ago';
    return date('d M Y', $time);
}

/**
 * Get category icon
 */
function getCategoryIcon(string $category): string {
    $icons = [
        'shopping'      => '🛍️',
        'food'          => '🍔',
        'travel'        => '✈️',
        'entertainment' => '🎬',
        'utilities'     => '💡',
        'healthcare'    => '🏥',
        'fuel'          => '⛽',
        'education'     => '📚',
        'other'         => '💳',
    ];
    return $icons[$category] ?? '💳';
}

/**
 * Get transaction badge class
 */
function getStatusBadge(string $status): string {
    $map = [
        'success'   => 'badge-success',
        'pending'   => 'badge-warning',
        'failed'    => 'badge-danger',
        'flagged'   => 'badge-danger',
        'active'    => 'badge-success',
        'blocked'   => 'badge-danger',
        'open'      => 'badge-warning',
        'resolved'  => 'badge-success',
        'in_progress' => 'badge-info',
        'paid'      => 'badge-success',
        'unpaid'    => 'badge-warning',
        'overdue'   => 'badge-danger',
    ];
    return $map[$status] ?? 'badge-secondary';
}
