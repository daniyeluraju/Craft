<?php
require_once '../includes/auth.php';
require_role('admin');

// Dashboard stats
$stats = [
    'users'    => db_fetch("SELECT COUNT(*) as c FROM users")['c'],
    'products' => db_fetch("SELECT COUNT(*) as c FROM products WHERE status='approved'")['c'],
    'orders'   => db_fetch("SELECT COUNT(*) as c FROM orders")['c'],
    'revenue'  => db_fetch("SELECT SUM(final_amount) as c FROM orders WHERE payment_status='paid'")['c'] ?? 0,
    'pending_products' => db_fetch("SELECT COUNT(*) as c FROM products WHERE status='pending'")['c'],
    'unread_messages'  => db_fetch("SELECT COUNT(*) as c FROM contact_messages WHERE is_read=0")['c'],
];

// Recent orders
$recent_orders = db_fetch_all("
    SELECT o.*, u.name as customer_name
    FROM orders o JOIN users u ON o.user_id=u.id
    ORDER BY o.created_at DESC LIMIT 8
");

// Sales data for chart (last 7 days)
$sales_data = db_fetch_all("
    SELECT DATE(created_at) as date, SUM(final_amount) as total, COUNT(*) as count
    FROM orders WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    GROUP BY DATE(created_at) ORDER BY date ASC
");

// Top products
$top_products = db_fetch_all("
    SELECT p.name, SUM(oi.quantity) as sold, SUM(oi.subtotal) as revenue
    FROM order_items oi JOIN products p ON oi.product_id=p.id
    GROUP BY oi.product_id ORDER BY sold DESC LIMIT 5
");

// Category distribution
$cat_dist = db_fetch_all("
    SELECT c.name, COUNT(p.id) as count
    FROM categories c LEFT JOIN products p ON p.category_id=c.id AND p.status='approved'
    GROUP BY c.id
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard – CraftStore</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/main.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<div class="dashboard-layout">
    <?php include '../includes/sidebar.php'; ?>
    <div class="dashboard-main">
        <!-- Topbar -->
        <div class="dashboard-topbar">
            <div style="display:flex;align-items:center;gap:1rem">
                <button class="btn btn-ghost btn-icon" id="sidebarOpenBtn"><i class="fas fa-bars"></i></button>
                <h1 class="topbar-title">Admin Dashboard</h1>
            </div>
            <div class="topbar-actions">
                <?php if ($stats['pending_products'] > 0): ?>
                <a href="/Craft/admin/products.php?status=pending" class="btn btn-secondary btn-sm">
                    <i class="fas fa-clock"></i> <?= $stats['pending_products'] ?> Pending
                </a>
                <?php endif; ?>
                <button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button>
                <div class="nav-user-menu">
                    <button class="user-avatar-btn">
                        <div class="avatar-circle"><?= strtoupper(substr($_SESSION['user_name'],0,1)) ?></div>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="user-dropdown">
                        <div class="dropdown-header"><strong><?= htmlspecialchars($_SESSION['user_name']) ?></strong><span class="role-badge admin">Admin</span></div>
                        <a href="/Craft/logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> Logout</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="dashboard-content">
            <!-- Stats -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon purple"><i class="fas fa-users"></i></div>
                    <div>
                        <p class="stat-value"><?= number_format($stats['users']) ?></p>
                        <p class="stat-label">Total Users</p>
                        <span class="stat-change up"><i class="fas fa-arrow-up"></i> Active platform</span>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon amber"><i class="fas fa-box"></i></div>
                    <div>
                        <p class="stat-value"><?= number_format($stats['products']) ?></p>
                        <p class="stat-label">Active Products</p>
                        <span class="stat-change" style="color:var(--secondary)"><i class="fas fa-clock"></i> <?= $stats['pending_products'] ?> pending</span>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon green"><i class="fas fa-shopping-bag"></i></div>
                    <div>
                        <p class="stat-value"><?= number_format($stats['orders']) ?></p>
                        <p class="stat-label">Total Orders</p>
                        <span class="stat-change up"><i class="fas fa-arrow-up"></i> Growing</span>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon blue"><i class="fas fa-rupee-sign"></i></div>
                    <div>
                        <p class="stat-value">₹<?= number_format($stats['revenue'], 0) ?></p>
                        <p class="stat-label">Total Revenue</p>
                        <span class="stat-change up"><i class="fas fa-arrow-up"></i> Paid orders</span>
                    </div>
                </div>
            </div>

            <!-- Charts Row -->
            <div style="display:grid;grid-template-columns:2fr 1fr;gap:1.5rem;margin-bottom:1.5rem">
                <div class="chart-card">
                    <div class="chart-card-header">
                        <h3 class="chart-card-title"><i class="fas fa-chart-line" style="color:var(--primary);margin-right:.4rem"></i>Sales Overview (Last 30 Days)</h3>
                        <span style="font-size:.8rem;color:var(--text-muted)">Daily revenue trend</span>
                    </div>
                    <div class="chart-container"><canvas id="salesChart"></canvas></div>
                </div>
                <div class="chart-card">
                    <div class="chart-card-header">
                        <h3 class="chart-card-title"><i class="fas fa-chart-pie" style="color:var(--secondary);margin-right:.4rem"></i>Category Split</h3>
                    </div>
                    <div class="chart-container"><canvas id="catChart"></canvas></div>
                </div>
            </div>

            <!-- Recent Orders + Top Products -->
            <div style="display:grid;grid-template-columns:1.5fr 1fr;gap:1.5rem;margin-bottom:1.5rem">
                <!-- Recent Orders -->
                <div class="table-wrapper">
                    <div class="table-header">
                        <h3>Recent Orders</h3>
                        <a href="/Craft/admin/orders.php" class="btn btn-ghost btn-sm">View All</a>
                    </div>
                    <table class="data-table">
                        <thead><tr><th>Order #</th><th>Customer</th><th>Amount</th><th>Status</th></tr></thead>
                        <tbody>
                        <?php foreach ($recent_orders as $ord): ?>
                        <tr>
                            <td><a href="/Craft/admin/orders.php?id=<?= $ord['id'] ?>" style="color:var(--primary);font-weight:600"><?= $ord['order_number'] ?></a></td>
                            <td><?= htmlspecialchars($ord['customer_name']) ?></td>
                            <td style="font-weight:700">₹<?= number_format($ord['final_amount']) ?></td>
                            <td><span class="status-badge status-<?= $ord['status'] ?>"><?= ucfirst($ord['status']) ?></span></td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Top Products -->
                <div class="chart-card">
                    <div class="chart-card-header">
                        <h3 class="chart-card-title">Top Selling Products</h3>
                    </div>
                    <?php foreach ($top_products as $i => $tp): ?>
                    <div style="display:flex;align-items:center;gap:.75rem;padding:.75rem 0;border-bottom:1px solid var(--border)">
                        <div style="width:28px;height:28px;border-radius:8px;background:linear-gradient(135deg,var(--primary),var(--primary-light));color:white;display:flex;align-items:center;justify-content:center;font-size:.75rem;font-weight:800;flex-shrink:0"><?= $i+1 ?></div>
                        <div style="flex:1;min-width:0">
                            <p style="font-size:.85rem;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($tp['name']) ?></p>
                            <p style="font-size:.75rem;color:var(--text-muted)"><?= $tp['sold'] ?> sold</p>
                        </div>
                        <span style="font-size:.82rem;font-weight:700;color:var(--accent);flex-shrink:0">₹<?= number_format($tp['revenue']) ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Quick Actions -->
            <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:1rem">
                <?php
                $quick = [
                    ['icon'=>'fa-users','label'=>'Manage Users','href'=>'/Craft/admin/users.php','color'=>'var(--primary)'],
                    ['icon'=>'fa-box','label'=>'Approve Products','href'=>'/Craft/admin/products.php','color'=>'var(--secondary)'],
                    ['icon'=>'fa-shopping-bag','label'=>'View Orders','href'=>'/Craft/admin/orders.php','color'=>'var(--accent)'],
                    ['icon'=>'fa-envelope','label'=>"Messages ($stats[unread_messages])",'href'=>'/Craft/admin/messages.php','color'=>'var(--info)'],
                ];
                foreach ($quick as $q): ?>
                <a href="<?= $q['href'] ?>" style="display:flex;flex-direction:column;align-items:center;gap:.6rem;padding:1.5rem;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-md);text-align:center;transition:var(--transition);color:var(--text)" onmouseover="this.style.transform='translateY(-3px)';this.style.borderColor='<?= $q['color'] ?>'" onmouseout="this.style.transform='';this.style.borderColor='var(--border)'">
                    <div style="width:48px;height:48px;border-radius:12px;background:<?= $q['color'] ?>20;display:flex;align-items:center;justify-content:center"><i class="fas <?= $q['icon'] ?>" style="color:<?= $q['color'] ?>;font-size:1.2rem"></i></div>
                    <span style="font-size:.85rem;font-weight:600"><?= $q['label'] ?></span>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<div id="sidebarOverlay" style="position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:850;display:none" onclick="document.getElementById('dashboardSidebar').classList.remove('open');this.style.display='none'"></div>
<script>
document.getElementById('sidebarOpenBtn')?.addEventListener('click', function() {
    document.getElementById('dashboardSidebar').classList.toggle('open');
    const overlay = document.getElementById('sidebarOverlay');
    overlay.style.display = document.getElementById('dashboardSidebar').classList.contains('open') ? 'block' : 'none';
});

// Sales Chart
const salesData = <?= json_encode(array_values($sales_data)) ?>;
const salesLabels = salesData.map(d => new Date(d.date).toLocaleDateString('en-IN',{month:'short',day:'numeric'}));
const salesValues = salesData.map(d => parseFloat(d.total));

new Chart(document.getElementById('salesChart'), {
    type: 'line',
    data: {
        labels: salesLabels,
        datasets: [{
            label: 'Revenue (₹)',
            data: salesValues,
            borderColor: '#7C3AED',
            backgroundColor: 'rgba(124,58,237,0.08)',
            borderWidth: 2.5,
            pointBackgroundColor: '#7C3AED',
            pointRadius: 4,
            tension: 0.4,
            fill: true,
        }]
    },
    options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
            x: { grid: { display: false }, ticks: { font: { size: 11 }, maxTicksLimit: 8 } },
            y: { grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { font: { size: 11 }, callback: v => '₹'+v.toLocaleString('en-IN') } }
        }
    }
});

// Category Chart
const catData = <?= json_encode(array_values($cat_dist)) ?>;
new Chart(document.getElementById('catChart'), {
    type: 'doughnut',
    data: {
        labels: catData.map(c => c.name),
        datasets: [{
            data: catData.map(c => parseInt(c.count)),
            backgroundColor: ['#7C3AED','#F59E0B','#10B981','#EF4444','#3B82F6','#8B5CF6'],
            borderWidth: 0,
        }]
    },
    options: {
        responsive: true, maintainAspectRatio: false,
        plugins: {
            legend: { position: 'bottom', labels: { font: { size: 11 }, padding: 12 } }
        }
    }
});
</script>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body></html>
