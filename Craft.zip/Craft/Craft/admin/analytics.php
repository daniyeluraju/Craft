<?php
require_once '../includes/auth.php';
require_role('admin');

// ── Summary KPIs ───────────────────────────────────
$total_revenue  = db_fetch("SELECT COALESCE(SUM(final_amount),0) as v FROM orders WHERE payment_status='paid'")['v'];
$total_orders   = db_fetch("SELECT COUNT(*) as v FROM orders")['v'];
$total_users    = db_fetch("SELECT COUNT(*) as v FROM users")['v'];
$total_products = db_fetch("SELECT COUNT(*) as v FROM products WHERE status='approved'")['v'];
$avg_order      = $total_orders > 0 ? $total_revenue / $total_orders : 0;
$pending_orders = db_fetch("SELECT COUNT(*) as v FROM orders WHERE status='pending'")['v'];

// ── Revenue last 30 days (daily) ────────────────────
$daily_revenue = db_fetch_all(
    "SELECT DATE(created_at) as d, SUM(final_amount) as revenue, COUNT(*) as orders
     FROM orders
     WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 29 DAY)
     GROUP BY DATE(created_at)
     ORDER BY d ASC"
);

// Fill missing dates
$date_map = [];
foreach ($daily_revenue as $row) $date_map[$row['d']] = $row;
$filled_days   = [];
$filled_rev    = [];
$filled_orders = [];
for ($i = 29; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i days"));
    $filled_days[]   = date('d M', strtotime($d));
    $filled_rev[]    = isset($date_map[$d]) ? floatval($date_map[$d]['revenue']) : 0;
    $filled_orders[] = isset($date_map[$d]) ? intval($date_map[$d]['orders'])    : 0;
}

// ── Orders by status ───────────────────────────────
$order_status = db_fetch_all(
    "SELECT status, COUNT(*) as count FROM orders GROUP BY status"
);

// ── Category performance ───────────────────────────
$cat_perf = db_fetch_all(
    "SELECT c.name, COUNT(p.id) as products, COALESCE(SUM(oi.subtotal),0) as revenue
     FROM categories c
     LEFT JOIN products p ON p.category_id=c.id AND p.status='approved'
     LEFT JOIN order_items oi ON oi.product_id=p.id
     GROUP BY c.id
     ORDER BY revenue DESC"
);

// ── Top sellers ────────────────────────────────────
$top_sellers = db_fetch_all(
    "SELECT u.name, COUNT(DISTINCT o.id) as orders, SUM(oi.subtotal) as revenue
     FROM users u
     JOIN products p ON p.seller_id=u.id
     JOIN order_items oi ON oi.product_id=p.id
     JOIN orders o ON o.id=oi.order_id AND o.payment_status='paid'
     GROUP BY u.id
     ORDER BY revenue DESC
     LIMIT 5"
);

// ── Monthly comparison ─────────────────────────────
$monthly = db_fetch_all(
    "SELECT DATE_FORMAT(created_at,'%b %Y') as month,
            DATE_FORMAT(created_at,'%Y-%m') as ym,
            SUM(final_amount) as revenue, COUNT(*) as orders
     FROM orders
     WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 5 MONTH)
     GROUP BY DATE_FORMAT(created_at,'%Y-%m')
     ORDER BY ym ASC"
);

// ── Payment method split ───────────────────────────
$payment_split = db_fetch_all(
    "SELECT payment_method, COUNT(*) as count, SUM(final_amount) as total
     FROM orders GROUP BY payment_method"
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Analytics – Admin | CraftStore</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/main.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<div class="dashboard-layout">
<?php include '../includes/sidebar.php'; ?>

<div class="dashboard-main">
  <div class="dashboard-topbar">
    <div style="display:flex;align-items:center;gap:1rem">
      <button class="btn btn-ghost btn-icon" id="sidebarOpenBtn"><i class="fas fa-bars"></i></button>
      <h1 class="topbar-title">Analytics & Reports</h1>
    </div>
    <div class="topbar-actions">
      <span style="font-size:.82rem;color:var(--text-muted)"><i class="fas fa-sync-alt"></i> Live data</span>
      <button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button>
    </div>
  </div>

  <div class="dashboard-content">

    <!-- KPI Cards -->
    <div class="stats-grid" style="margin-bottom:1.5rem">
      <?php
      $kpis = [
        ['icon'=>'fa-rupee-sign','color'=>'purple','label'=>'Total Revenue','value'=>'₹'.number_format($total_revenue),'sub'=>'From paid orders'],
        ['icon'=>'fa-shopping-bag','color'=>'amber','label'=>'Total Orders','value'=>number_format($total_orders),'sub'=>"$pending_orders pending"],
        ['icon'=>'fa-users','color'=>'green','label'=>'Registered Users','value'=>number_format($total_users),'sub'=>'All roles'],
        ['icon'=>'fa-box','color'=>'blue','label'=>'Active Products','value'=>number_format($total_products),'sub'=>'Approved listings'],
      ];
      foreach ($kpis as $k): ?>
      <div class="stat-card">
        <div class="stat-icon <?= $k['color'] ?>"><i class="fas <?= $k['icon'] ?>"></i></div>
        <div>
          <p class="stat-value"><?= $k['value'] ?></p>
          <p class="stat-label"><?= $k['label'] ?></p>
          <span class="stat-change" style="color:var(--text-muted)"><?= $k['sub'] ?></span>
        </div>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- Revenue Chart (30-day) -->
    <div class="chart-card" style="margin-bottom:1.5rem">
      <div class="chart-card-header" style="display:flex;justify-content:space-between;align-items:center">
        <h3 class="chart-card-title"><i class="fas fa-chart-line" style="color:var(--primary);margin-right:.4rem"></i>Revenue – Last 30 Days</h3>
        <div style="display:flex;gap:.6rem">
          <button class="btn btn-ghost btn-sm" id="showRevBtn" onclick="switchChart('revenue')">Revenue</button>
          <button class="btn btn-ghost btn-sm" id="showOrdBtn" onclick="switchChart('orders')">Orders</button>
        </div>
      </div>
      <div style="height:260px"><canvas id="revenueChart"></canvas></div>
    </div>

    <!-- Row: Category + Orders status + Payment split -->
    <div style="display:grid;grid-template-columns:1.5fr 1fr 1fr;gap:1.5rem;margin-bottom:1.5rem">

      <!-- Category Performance -->
      <div class="chart-card">
        <div class="chart-card-header">
          <h3 class="chart-card-title"><i class="fas fa-th-large" style="color:var(--secondary);margin-right:.4rem"></i>Category Revenue</h3>
        </div>
        <div style="height:220px"><canvas id="catChart"></canvas></div>
      </div>

      <!-- Order Status Doughnut -->
      <div class="chart-card">
        <div class="chart-card-header">
          <h3 class="chart-card-title"><i class="fas fa-chart-pie" style="color:var(--accent);margin-right:.4rem"></i>Order Status</h3>
        </div>
        <div style="height:220px"><canvas id="statusChart"></canvas></div>
      </div>

      <!-- Payment Methods -->
      <div class="chart-card">
        <div class="chart-card-header">
          <h3 class="chart-card-title"><i class="fas fa-credit-card" style="color:var(--info);margin-right:.4rem"></i>Payment Methods</h3>
        </div>
        <div style="height:220px"><canvas id="payChart"></canvas></div>
      </div>
    </div>

    <!-- Row: Monthly comparison + Top sellers -->
    <div style="display:grid;grid-template-columns:1.5fr 1fr;gap:1.5rem">

      <!-- Monthly bar chart -->
      <div class="chart-card">
        <div class="chart-card-header">
          <h3 class="chart-card-title"><i class="fas fa-chart-bar" style="color:var(--primary);margin-right:.4rem"></i>Monthly Revenue Comparison</h3>
        </div>
        <div style="height:240px"><canvas id="monthlyChart"></canvas></div>
      </div>

      <!-- Top Sellers -->
      <div class="chart-card">
        <div class="chart-card-header">
          <h3 class="chart-card-title"><i class="fas fa-medal" style="color:var(--secondary);margin-right:.4rem"></i>Top Sellers</h3>
        </div>
        <?php if (empty($top_sellers)): ?>
        <div class="empty-state" style="padding:2rem">
          <p class="empty-subtitle">No seller revenue data yet</p>
        </div>
        <?php else: foreach ($top_sellers as $i => $ts): ?>
        <div style="display:flex;align-items:center;gap:.85rem;padding:.9rem 0;border-bottom:1px solid var(--border)">
          <div style="width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--secondary));color:white;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.8rem;flex-shrink:0">
            <?= $i+1 ?>
          </div>
          <div style="flex:1;min-width:0">
            <p style="font-weight:700;font-size:.88rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($ts['name']) ?></p>
            <p style="font-size:.75rem;color:var(--text-muted)"><?= $ts['orders'] ?> paid orders</p>
          </div>
          <div style="text-align:right;flex-shrink:0">
            <p style="font-weight:800;color:var(--accent);font-size:.9rem">₹<?= number_format($ts['revenue']) ?></p>
          </div>
        </div>
        <?php endforeach; endif; ?>
      </div>
    </div>

  </div><!-- /dashboard-content -->
</div><!-- /dashboard-main -->
</div><!-- /dashboard-layout -->

<div id="sidebarOverlay" style="position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:850;display:none"
  onclick="document.getElementById('dashboardSidebar').classList.remove('open');this.style.display='none'"></div>

<script>
document.getElementById('sidebarOpenBtn')?.addEventListener('click',function(){
  document.getElementById('dashboardSidebar').classList.toggle('open');
  document.getElementById('sidebarOverlay').style.display =
    document.getElementById('dashboardSidebar').classList.contains('open') ? 'block' : 'none';
});

/* ── Chart.js defaults ── */
Chart.defaults.font.family = "'Outfit',sans-serif";
Chart.defaults.color       = '#94A3B8';

const days    = <?= json_encode($filled_days) ?>;
const revData = <?= json_encode($filled_rev) ?>;
const ordData = <?= json_encode($filled_orders) ?>;

/* Revenue / Orders toggle line chart */
let revChart = null;
function buildRevenueChart(type){
  const ctx = document.getElementById('revenueChart').getContext('2d');
  if (revChart) revChart.destroy();
  const isRev = type === 'revenue';
  revChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: days,
      datasets: [{
        label: isRev ? 'Revenue (₹)' : 'Orders',
        data: isRev ? revData : ordData,
        borderColor: isRev ? '#7C3AED' : '#10B981',
        backgroundColor: isRev ? 'rgba(124,58,237,0.09)' : 'rgba(16,185,129,0.09)',
        borderWidth: 2.5, pointRadius: 3.5, tension: 0.4, fill: true,
      }]
    },
    options: {
      responsive:true, maintainAspectRatio:false,
      plugins:{ legend:{display:false} },
      scales:{
        x:{ grid:{display:false}, ticks:{font:{size:10},maxTicksLimit:10} },
        y:{ grid:{color:'rgba(0,0,0,0.05)'}, ticks:{font:{size:10}, callback: v=> isRev?'₹'+v.toLocaleString('en-IN'):v}}
      }
    }
  });
}
function switchChart(type){ buildRevenueChart(type); }
buildRevenueChart('revenue');

/* Category bar chart */
const catData = <?= json_encode(array_values($cat_perf)) ?>;
new Chart(document.getElementById('catChart'),{
  type:'bar',
  data:{
    labels: catData.map(c=>c.name),
    datasets:[{
      label:'Revenue (₹)',
      data: catData.map(c=>parseFloat(c.revenue)),
      backgroundColor:['#7C3AED','#F59E0B','#10B981','#EF4444','#3B82F6','#8B5CF6'],
      borderRadius:6, borderSkipped:false,
    }]
  },
  options:{
    responsive:true, maintainAspectRatio:false,
    plugins:{legend:{display:false}},
    scales:{
      x:{grid:{display:false},ticks:{font:{size:10}}},
      y:{grid:{color:'rgba(0,0,0,0.05)'},ticks:{font:{size:10},callback:v=>'₹'+v.toLocaleString('en-IN')}}
    }
  }
});

/* Order status doughnut */
const statusData = <?= json_encode(array_values($order_status)) ?>;
new Chart(document.getElementById('statusChart'),{
  type:'doughnut',
  data:{
    labels:statusData.map(s=>s.status.charAt(0).toUpperCase()+s.status.slice(1)),
    datasets:[{
      data:statusData.map(s=>parseInt(s.count)),
      backgroundColor:['#F59E0B','#3B82F6','#7C3AED','#10B981','#6366F1','#EF4444'],
      borderWidth:0,
    }]
  },
  options:{
    responsive:true, maintainAspectRatio:false,
    plugins:{legend:{position:'bottom',labels:{font:{size:10},padding:8}}}
  }
});

/* Payment method bar */
const payData = <?= json_encode(array_values($payment_split)) ?>;
new Chart(document.getElementById('payChart'),{
  type:'bar',
  data:{
    labels:payData.map(p=>p.payment_method.toUpperCase()),
    datasets:[{
      label:'Orders',
      data:payData.map(p=>parseInt(p.count)),
      backgroundColor:['#7C3AED','#10B981','#F59E0B','#3B82F6'],
      borderRadius:6, borderSkipped:false,
    }]
  },
  options:{
    responsive:true, maintainAspectRatio:false,
    plugins:{legend:{display:false}},
    scales:{x:{grid:{display:false},ticks:{font:{size:10}}},y:{grid:{color:'rgba(0,0,0,0.05)'},ticks:{stepSize:1,font:{size:10}}}}
  }
});

/* Monthly comparison */
const monthlyData = <?= json_encode(array_values($monthly)) ?>;
new Chart(document.getElementById('monthlyChart'),{
  type:'bar',
  data:{
    labels:monthlyData.map(m=>m.month),
    datasets:[{
      label:'Revenue (₹)',
      data:monthlyData.map(m=>parseFloat(m.revenue)),
      backgroundColor:'rgba(124,58,237,0.7)',
      borderRadius:8, borderSkipped:false,
    },{
      label:'Orders',
      data:monthlyData.map(m=>parseInt(m.orders)*200), // scale for visibility
      backgroundColor:'rgba(245,158,11,0.5)',
      borderRadius:8, borderSkipped:false,
      yAxisID:'y1',
    }]
  },
  options:{
    responsive:true, maintainAspectRatio:false,
    plugins:{legend:{position:'bottom',labels:{font:{size:10},padding:12}}},
    scales:{
      x:{grid:{display:false},ticks:{font:{size:10}}},
      y:{grid:{color:'rgba(0,0,0,0.05)'},ticks:{font:{size:10},callback:v=>'₹'+v.toLocaleString('en-IN')}},
      y1:{display:false},
    }
  }
});
</script>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body>
</html>
