<?php
require_once '../includes/auth.php';
require_role('admin');

$error   = '';
$success = '';

// ── Handle POST actions ─────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $pid    = intval($_POST['pid'] ?? 0);

    if ($action === 'approve' && $pid) {
        db_query("UPDATE products SET status='approved', updated_at=NOW() WHERE id=?", [$pid]);
        $success = 'Product approved and is now live!';
    }
    elseif ($action === 'reject' && $pid) {
        db_query("UPDATE products SET status='rejected', updated_at=NOW() WHERE id=?", [$pid]);
        $success = 'Product rejected.';
    }
    elseif ($action === 'delete' && $pid) {
        try {
            global $pdo;
            $pdo->exec('SET FOREIGN_KEY_CHECKS=0');
            $pdo->exec("DELETE FROM reviews     WHERE product_id=$pid");
            $pdo->exec("DELETE FROM cart        WHERE product_id=$pid");
            $pdo->exec("DELETE FROM wishlist    WHERE product_id=$pid");
            $pdo->exec("DELETE FROM order_items WHERE product_id=$pid");
            $pdo->exec("DELETE FROM products    WHERE id=$pid");
            $pdo->exec('SET FOREIGN_KEY_CHECKS=1');
            $success = 'Product deleted successfully.';
        } catch (Exception $e) {
            $pdo->exec('SET FOREIGN_KEY_CHECKS=1');
            $error = 'Delete failed: ' . $e->getMessage();
        }
    }
    elseif ($action === 'edit_product' && $pid) {
        $name       = sanitize($_POST['name']        ?? '');
        $price      = floatval($_POST['price']       ?? 0);
        $sale_price = !empty($_POST['sale_price']) ? floatval($_POST['sale_price']) : null;
        $stock      = intval($_POST['stock']         ?? 0);
        $cat_id     = intval($_POST['category_id']   ?? 0);
        $status     = sanitize($_POST['status']      ?? 'pending');
        $desc       = sanitize($_POST['description'] ?? '');
        $featured   = isset($_POST['is_featured']) ? 1 : 0;
        $trending   = isset($_POST['is_trending']) ? 1 : 0;

        if (!$name || !$price || !$cat_id) {
            $error = 'Name, price and category are required.';
        } else {
            db_query(
                "UPDATE products SET name=?,price=?,sale_price=?,stock=?,category_id=?,status=?,description=?,is_featured=?,is_trending=?,updated_at=NOW() WHERE id=?",
                [$name, $price, $sale_price, $stock, $cat_id, $status, $desc, $featured, $trending, $pid]
            );
            $success = 'Product updated successfully!';
        }
    }
    elseif ($action === 'toggle_featured' && $pid) {
        $p = db_fetch("SELECT is_featured FROM products WHERE id=?", [$pid]);
        db_query("UPDATE products SET is_featured=? WHERE id=?", [$p['is_featured'] ? 0 : 1, $pid]);
        $success = 'Featured status updated.';
    }
}

// ── Filters ─────────────────────────────────────────
$status_filter = sanitize($_GET['status'] ?? 'all');
$where  = $status_filter !== 'all' ? "WHERE p.status=?" : "WHERE 1=1";
$params = $status_filter !== 'all' ? [$status_filter] : [];

$products = db_fetch_all(
    "SELECT p.*, c.name as cat_name, u.name as seller_name
     FROM products p
     JOIN categories c ON p.category_id=c.id
     JOIN users u ON p.seller_id=u.id
     $where ORDER BY p.created_at DESC",
    $params
);

$categories = db_fetch_all("SELECT * FROM categories WHERE is_active=1 ORDER BY name");

// Status counts
$counts = [];
foreach (['pending','approved','rejected'] as $s) {
    $counts[$s] = db_fetch("SELECT COUNT(*) as c FROM products WHERE status=?",[$s])['c'];
}
$counts['all'] = array_sum($counts);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Products – Admin | CraftStore</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/main.css">
</head>
<body>
<div class="dashboard-layout">
<?php include '../includes/sidebar.php'; ?>

<div class="dashboard-main">
  <div class="dashboard-topbar">
    <div style="display:flex;align-items:center;gap:1rem">
      <button class="btn btn-ghost btn-icon" id="sidebarOpenBtn"><i class="fas fa-bars"></i></button>
      <h1 class="topbar-title">Product Management</h1>
    </div>
    <div class="topbar-actions">
      <?php if ($counts['pending'] > 0): ?>
      <a href="?status=pending" class="btn btn-secondary btn-sm">
        <i class="fas fa-clock"></i> <?= $counts['pending'] ?> Pending Review
      </a>
      <?php endif; ?>
      <button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button>
    </div>
  </div>

  <div class="dashboard-content">
    <!-- Alerts -->
    <?php if ($success): ?>
    <div style="background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.3);border-radius:10px;padding:.9rem 1.1rem;margin-bottom:1.25rem;display:flex;gap:.6rem;color:var(--accent)">
      <i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?>
    </div>
    <?php endif; ?>
    <?php if ($error): ?>
    <div style="background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);border-radius:10px;padding:.9rem 1.1rem;margin-bottom:1.25rem;display:flex;gap:.6rem;color:var(--danger)">
      <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?>
    </div>
    <?php endif; ?>

    <!-- Filter tabs -->
    <div style="display:flex;gap:.5rem;margin-bottom:1.5rem;flex-wrap:wrap">
      <?php foreach(['all','pending','approved','rejected'] as $s): ?>
      <a href="?status=<?= $s ?>" style="padding:.45rem 1.15rem;border-radius:50px;font-size:.83rem;font-weight:600;transition:all .2s;<?= $status_filter===$s ? 'background:var(--primary);color:white;' : 'background:var(--surface);border:1px solid var(--border);color:var(--text-muted);' ?>">
        <?= ucfirst($s) ?>
        <span style="margin-left:.3rem;background:rgba(255,255,255,0.2);border-radius:50px;padding:.05rem .42rem;font-size:.72rem"><?= $counts[$s] ?></span>
      </a>
      <?php endforeach; ?>
    </div>

    <!-- Table -->
    <div class="table-wrapper">
      <div class="table-header">
        <h3>Products (<?= count($products) ?>)</h3>
        <input type="text" id="prodSearch" placeholder="Search products…" oninput="filterTable(this.value)"
          style="padding:.45rem .75rem;border:1px solid var(--border);border-radius:8px;background:var(--surface);color:var(--text);font-size:.85rem;font-family:var(--font)">
      </div>
      <table class="data-table" id="prodTable">
        <thead>
          <tr><th>#</th><th>Product</th><th>Category</th><th>Seller</th><th>Price</th><th>Stock</th><th>Status</th><th>Actions</th></tr>
        </thead>
        <tbody>
        <?php foreach ($products as $i => $p):
          $dp = $p['sale_price'] ?? $p['price'];
        ?>
        <tr data-name="<?= strtolower($p['name']) ?>">
          <td style="color:var(--text-muted);font-size:.78rem"><?= $i+1 ?></td>
          <td>
            <div style="display:flex;align-items:center;gap:.7rem">
              <div style="width:44px;height:44px;border-radius:10px;background:rgba(124,58,237,.1);display:flex;align-items:center;justify-content:center;flex-shrink:0;overflow:hidden">
                <?php if (!empty($p['featured_image'])): ?>
                <img src="<?= SITE_URL . '/assets/uploads' . $p['featured_image'] ?>" alt="" style="width:100%;height:100%;object-fit:cover;">
                <?php else: ?>
                <img src="<?= SITE_URL ?>/assets/img/default-product.svg" alt="" style="width:100%;height:100%;object-fit:cover;">
                <?php endif; ?>
              </div>
              <div>
                <p style="font-weight:600;font-size:.88rem"><?= htmlspecialchars(substr($p['name'],0,32)) ?></p>
                <p style="font-size:.72rem;color:var(--text-muted)"><?= date('d M Y', strtotime($p['created_at'])) ?></p>
              </div>
            </div>
          </td>
          <td style="font-size:.85rem"><?= htmlspecialchars($p['cat_name']) ?></td>
          <td style="font-size:.85rem"><?= htmlspecialchars($p['seller_name']) ?></td>
          <td>
            <span style="font-weight:800;color:var(--primary)">₹<?= number_format($dp) ?></span>
            <?php if ($p['sale_price']): ?>
            <br><small style="color:var(--text-muted);text-decoration:line-through;font-size:.72rem">₹<?= number_format($p['price']) ?></small>
            <?php endif; ?>
          </td>
          <td>
            <span style="font-weight:600;color:<?= $p['stock']>0 ? 'var(--accent)' : 'var(--danger)' ?>">
              <?= $p['stock'] ?>
            </span>
          </td>
          <td><span class="status-badge status-<?= $p['status'] ?>"><?= ucfirst($p['status']) ?></span></td>
          <td>
            <div style="display:flex;gap:.3rem;flex-wrap:wrap">
              <!-- View -->
              <a href="<?= SITE_URL ?>/public/product.php?id=<?= $p['id'] ?>" target="_blank"
                class="btn btn-ghost btn-sm btn-icon" title="View on store"><i class="fas fa-eye"></i></a>

              <!-- Edit -->
              <button class="btn btn-ghost btn-sm btn-icon" title="Edit"
                onclick='openEditProduct(<?= json_encode([
                  "id"=>$p["id"],"name"=>$p["name"],"price"=>$p["price"],"sale_price"=>$p["sale_price"],
                  "stock"=>$p["stock"],"category_id"=>$p["category_id"],"status"=>$p["status"],
                  "description"=>$p["description"],"is_featured"=>$p["is_featured"],"is_trending"=>$p["is_trending"]
                ]) ?>)'>
                <i class="fas fa-edit" style="color:var(--info)"></i>
              </button>

              <!-- Approve (pending/rejected) -->
              <?php if ($p['status'] !== 'approved'): ?>
              <form method="POST" style="display:inline">
                <input type="hidden" name="pid" value="<?= $p['id'] ?>">
                <button name="action" value="approve" class="btn btn-success btn-sm btn-icon" title="Approve">
                  <i class="fas fa-check"></i>
                </button>
              </form>
              <?php endif; ?>

              <!-- Reject (approved) -->
              <?php if ($p['status'] !== 'rejected'): ?>
              <form method="POST" style="display:inline">
                <input type="hidden" name="pid" value="<?= $p['id'] ?>">
                <button name="action" value="reject" class="btn btn-ghost btn-sm btn-icon" title="Reject" style="color:var(--secondary)">
                  <i class="fas fa-times-circle"></i>
                </button>
              </form>
              <?php endif; ?>

              <!-- Delete – custom modal -->
              <form method="POST" style="display:inline" id="del-prod-<?= $p['id'] ?>">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="pid"    value="<?= $p['id'] ?>">
                <button type="button" class="btn btn-danger btn-sm btn-icon" title="Delete"
                  onclick="askDeleteProd(<?= $p['id'] ?>, '<?= htmlspecialchars($p['name'], ENT_QUOTES) ?>')">  
                  <i class="fas fa-trash"></i>
                </button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($products)): ?>
        <tr><td colspan="8" style="text-align:center;padding:3rem;color:var(--text-muted)">
          <i class="fas fa-inbox" style="font-size:2rem;display:block;margin-bottom:.75rem"></i>No products found
        </td></tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
</div>

<!-- ── EDIT PRODUCT MODAL ── -->
<div class="modal-overlay" id="editProductModal">
  <div class="modal" style="max-width:580px">
    <div class="modal-header">
      <h2 class="modal-title"><i class="fas fa-box-open" style="color:var(--primary);margin-right:.4rem"></i>Edit Product</h2>
      <button class="modal-close" onclick="closeModal('editProductModal')"><i class="fas fa-times"></i></button>
    </div>
    <form method="POST" id="editProductForm">
      <div class="modal-body">
        <input type="hidden" name="action" value="edit_product">
        <input type="hidden" name="pid" id="ep_id">

        <div class="form-group">
          <label class="form-label">Product Name *</label>
          <input type="text" name="name" id="ep_name" class="form-control" required>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem">
          <div class="form-group">
            <label class="form-label">Category *</label>
            <select name="category_id" id="ep_cat" class="form-control" required>
              <?php foreach($categories as $cat): ?>
              <option value="<?= $cat['id'] ?>"><?= htmlspecialchars($cat['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Status</label>
            <select name="status" id="ep_status" class="form-control">
              <option value="pending">Pending</option>
              <option value="approved">Approved</option>
              <option value="rejected">Rejected</option>
            </select>
          </div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:.75rem">
          <div class="form-group">
            <label class="form-label">Price (₹) *</label>
            <input type="number" name="price" id="ep_price" class="form-control" min="1" step="0.01" required>
          </div>
          <div class="form-group">
            <label class="form-label">Sale Price (₹)</label>
            <input type="number" name="sale_price" id="ep_sale" class="form-control" min="0" step="0.01" placeholder="Optional">
          </div>
          <div class="form-group">
            <label class="form-label">Stock *</label>
            <input type="number" name="stock" id="ep_stock" class="form-control" min="0" required>
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">Description</label>
          <textarea name="description" id="ep_desc" class="form-control" rows="3"></textarea>
        </div>

        <div style="display:flex;gap:1.5rem">
          <label style="display:flex;align-items:center;gap:.5rem;cursor:pointer;font-size:.88rem">
            <input type="checkbox" name="is_featured" id="ep_featured" style="accent-color:var(--primary)"> Featured
          </label>
          <label style="display:flex;align-items:center;gap:.5rem;cursor:pointer;font-size:.88rem">
            <input type="checkbox" name="is_trending" id="ep_trending" style="accent-color:var(--secondary)"> Trending
          </label>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" onclick="closeModal('editProductModal')">Cancel</button>
        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Changes</button>
      </div>
    </form>
  </div>
</div>

<div id="sidebarOverlay" style="position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:850;display:none"
  onclick="document.getElementById('dashboardSidebar').classList.remove('open');this.style.display='none'"></div>

<!-- ═══ DELETE CONFIRM MODAL ═══ -->
<div class="modal-overlay" id="delProdModal">
  <div class="modal" style="max-width:400px;text-align:center">
    <div class="modal-body" style="padding:2.5rem 2rem">
      <div style="width:70px;height:70px;border-radius:50%;background:rgba(239,68,68,.12);margin:0 auto 1.25rem;display:flex;align-items:center;justify-content:center">
        <i class="fas fa-trash-alt" style="font-size:1.8rem;color:var(--danger)"></i>
      </div>
      <h3 style="font-size:1.1rem;font-weight:800;margin-bottom:.5rem">Delete Product?</h3>
      <p style="font-weight:700;color:var(--danger);margin-bottom:.75rem" id="delProdName"></p>
      <p style="font-size:.82rem;color:var(--text-muted);margin-bottom:2rem">This removes the product from all carts, wishlists, and order history. <strong>Cannot be undone.</strong></p>
      <div style="display:flex;gap:.75rem;justify-content:center">
        <button type="button" class="btn btn-ghost" onclick="document.getElementById('delProdModal').classList.remove('open')">
          <i class="fas fa-times"></i> Cancel
        </button>
        <button type="button" class="btn btn-danger" id="delProdConfirmBtn">
          <i class="fas fa-trash"></i> Yes, Delete
        </button>
      </div>
    </div>
  </div>
</div>

<script>
document.getElementById('sidebarOpenBtn')?.addEventListener('click',function(){
  document.getElementById('dashboardSidebar').classList.toggle('open');
  document.getElementById('sidebarOverlay').style.display =
    document.getElementById('dashboardSidebar').classList.contains('open') ? 'block' : 'none';
});

function filterTable(q){
  q = q.toLowerCase();
  document.querySelectorAll('#prodTable tbody tr').forEach(row=>{
    row.style.display = (row.dataset.name||'').includes(q) ? '' : 'none';
  });
}

function openEditProduct(d){
  document.getElementById('ep_id').value       = d.id;
  document.getElementById('ep_name').value     = d.name;
  document.getElementById('ep_price').value    = d.price;
  document.getElementById('ep_sale').value     = d.sale_price || '';
  document.getElementById('ep_stock').value    = d.stock;
  document.getElementById('ep_cat').value      = d.category_id;
  document.getElementById('ep_status').value   = d.status;
  document.getElementById('ep_desc').value     = d.description || '';
  document.getElementById('ep_featured').checked = !!parseInt(d.is_featured);
  document.getElementById('ep_trending').checked = !!parseInt(d.is_trending);
  document.getElementById('editProductModal').classList.add('open');
}

function closeModal(id){ document.getElementById(id).classList.remove('open'); }

let _delProdId = null;
function askDeleteProd(pid, name) {
  _delProdId = pid;
  document.getElementById('delProdName').textContent = name;
  document.getElementById('delProdModal').classList.add('open');
}
document.getElementById('delProdConfirmBtn').addEventListener('click', function() {
  if (_delProdId) {
    document.getElementById('delProdModal').classList.remove('open');
    document.getElementById('del-prod-' + _delProdId).submit();
  }
});
// Close modal on backdrop click
document.querySelectorAll('.modal-overlay').forEach(o => {
  o.addEventListener('click', function(e){ if(e.target===this) this.classList.remove('open'); });
});
</script>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body>
</html>
