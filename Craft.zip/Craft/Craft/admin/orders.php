<?php
require_once '../includes/auth.php';
require_role('admin');

$error = $success = '';

// ── Handle status update ─────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action   = $_POST['action'] ?? '';
    $order_id = intval($_POST['order_id'] ?? 0);

    if ($action === 'update_status' && $order_id) {
        $status = sanitize($_POST['status'] ?? '');
        $pay    = sanitize($_POST['payment_status'] ?? '');
        if ($status) {
            db_query("UPDATE orders SET status=?, updated_at=NOW() WHERE id=?", [$status, $order_id]);
            db_query("UPDATE order_items SET status=? WHERE order_id=?", [$status, $order_id]);
        }
        if ($pay) {
            db_query("UPDATE orders SET payment_status=? WHERE id=?", [$pay, $order_id]);
        }
        $success = "Order #{$order_id} updated successfully.";
    }
    elseif ($action === 'delete' && $order_id) {
        db_query("DELETE FROM order_items WHERE order_id=?", [$order_id]);
        db_query("DELETE FROM payments    WHERE order_id=?", [$order_id]);
        db_query("DELETE FROM orders      WHERE id=?", [$order_id]);
        $success = "Order deleted.";
    }
}

// ── Filter ──────────────────────────────────────
$sf     = sanitize($_GET['status'] ?? 'all');
$where  = $sf !== 'all' ? "WHERE o.status=?" : "WHERE 1=1";
$params = $sf !== 'all' ? [$sf] : [];

$orders = db_fetch_all(
    "SELECT o.*, u.name as customer_name, u.email as customer_email,
            COUNT(oi.id) as item_count, SUM(oi.subtotal) as items_total
     FROM orders o
     JOIN users u ON u.id=o.user_id
     LEFT JOIN order_items oi ON oi.order_id=o.id
     $where
     GROUP BY o.id
     ORDER BY o.created_at DESC",
    $params
);

$status_list = ['pending','confirmed','processing','shipped','delivered','cancelled'];

$counts = [];
foreach ($status_list as $s) {
    $counts[$s] = db_fetch("SELECT COUNT(*) as c FROM orders WHERE status=?",[$s])['c'];
}
$counts['all'] = db_fetch("SELECT COUNT(*) as c FROM orders")['c'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Orders – Admin | CraftStore</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/main.css">
</head>
<body>
<div class="dashboard-layout">
<?php include '../includes/sidebar.php'; ?>

<div class="dashboard-main">
  <div class="dashboard-topbar">
    <div style="display:flex;align-items:center;gap:1rem">
      <button class="btn btn-ghost btn-icon" id="sidebarOpenBtn"><i class="fas fa-bars"></i></button>
      <h1 class="topbar-title">Order Management</h1>
    </div>
    <div class="topbar-actions"><button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button></div>
  </div>

  <div class="dashboard-content">
    <?php if ($success): ?>
    <div style="background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.3);border-radius:10px;padding:.9rem 1.1rem;margin-bottom:1.25rem;display:flex;gap:.6rem;color:var(--accent)">
      <i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?>
    </div>
    <?php endif; ?>

    <!-- Filter Tabs -->
    <div style="display:flex;gap:.45rem;margin-bottom:1.5rem;flex-wrap:wrap">
      <?php foreach(array_merge(['all'],$status_list) as $s): ?>
      <a href="?status=<?= $s ?>" style="padding:.42rem 1rem;border-radius:50px;font-size:.8rem;font-weight:600;transition:all .2s;<?= $sf===$s?'background:var(--primary);color:white;':'background:var(--surface);border:1px solid var(--border);color:var(--text-muted);' ?>">
        <?= ucfirst($s) ?>
        <span style="margin-left:.25rem;background:rgba(255,255,255,0.2);border-radius:50px;padding:.05rem .4rem;font-size:.7rem"><?= $counts[$s] ?? 0 ?></span>
      </a>
      <?php endforeach; ?>
    </div>

    <!-- Table -->
    <div class="table-wrapper">
      <div class="table-header">
        <h3>Orders (<?= count($orders) ?>)</h3>
        <input type="text" id="orderSearch" placeholder="Search order #, customer…" oninput="filterOrders(this.value)"
          style="padding:.45rem .75rem;border:1px solid var(--border);border-radius:8px;background:var(--surface);color:var(--text);font-size:.85rem;font-family:var(--font)">
      </div>
      <table class="data-table" id="ordersTable">
        <thead>
          <tr><th>Order #</th><th>Customer</th><th>Items</th><th>Amount</th><th>Method</th><th>Payment</th><th>Status</th><th>Date</th><th>Actions</th></tr>
        </thead>
        <tbody>
        <?php foreach ($orders as $o): ?>
        <tr data-order="<?= strtolower($o['order_number']) ?>" data-customer="<?= strtolower($o['customer_name']) ?>">
          <td>
            <button class="btn btn-ghost btn-sm" onclick='openOrderDetail(<?= json_encode($o) ?>)'
              style="color:var(--primary);font-weight:700;font-size:.85rem;text-decoration:underline;padding:.2rem .4rem">
              <?= htmlspecialchars($o['order_number']) ?>
            </button>
          </td>
          <td>
            <div>
              <p style="font-weight:600;font-size:.88rem"><?= htmlspecialchars($o['customer_name']) ?></p>
              <p style="font-size:.72rem;color:var(--text-muted)"><?= htmlspecialchars($o['customer_email']) ?></p>
            </div>
          </td>
          <td style="font-size:.85rem"><?= $o['item_count'] ?></td>
          <td style="font-weight:800;color:var(--primary)">₹<?= number_format($o['final_amount']) ?></td>
          <td style="font-size:.8rem;text-transform:uppercase;font-weight:600"><?= $o['payment_method'] ?></td>
          <td>
            <span style="font-size:.75rem;font-weight:700;color:<?= $o['payment_status']==='paid'?'var(--accent)':'var(--danger)' ?>">
              <?= ucfirst($o['payment_status']) ?>
            </span>
          </td>
          <td><span class="status-badge status-<?= $o['status'] ?>"><?= ucfirst($o['status']) ?></span></td>
          <td style="font-size:.78rem;color:var(--text-muted)"><?= date('d M Y', strtotime($o['created_at'])) ?></td>
          <td>
            <div style="display:flex;gap:.3rem">
              <!-- Edit -->
              <button class="btn btn-ghost btn-sm btn-icon" title="Update Status"
                onclick='openEditOrder(<?= json_encode(["id"=>$o["id"],"order_number"=>$o["order_number"],"status"=>$o["status"],"payment_status"=>$o["payment_status"]]) ?>)'>
                <i class="fas fa-edit" style="color:var(--info)"></i>
              </button>
              <!-- Delete -->
              <form method="POST" style="display:inline"
                onsubmit="return confirm('Delete order <?= htmlspecialchars($o['order_number'], ENT_QUOTES) ?>?\nThis cannot be undone.')">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                <button type="submit" class="btn btn-danger btn-sm btn-icon" title="Delete">
                  <i class="fas fa-trash"></i>
                </button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($orders)): ?>
        <tr><td colspan="9" style="text-align:center;padding:3rem;color:var(--text-muted)">
          <i class="fas fa-box-open" style="font-size:2rem;display:block;margin-bottom:.75rem"></i>No orders found
        </td></tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
</div>

<!-- ── EDIT ORDER STATUS MODAL ── -->
<div class="modal-overlay" id="editOrderModal">
  <div class="modal" style="max-width:420px">
    <div class="modal-header">
      <h2 class="modal-title"><i class="fas fa-clipboard-list" style="color:var(--primary);margin-right:.4rem"></i>Update Order</h2>
      <button class="modal-close" onclick="closeModal('editOrderModal')"><i class="fas fa-times"></i></button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="action" value="update_status">
        <input type="hidden" name="order_id" id="eo_id">

        <div style="background:var(--surface-2);border-radius:10px;padding:.85rem 1rem;margin-bottom:1.25rem">
          <p style="font-size:.8rem;color:var(--text-muted);margin-bottom:.2rem">Order Number</p>
          <p style="font-weight:800;color:var(--primary)" id="eo_number"></p>
        </div>

        <div class="form-group">
          <label class="form-label">Order Status</label>
          <select name="status" id="eo_status" class="form-control">
            <?php foreach($status_list as $s): ?>
            <option value="<?= $s ?>"><?= ucfirst($s) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="form-group">
          <label class="form-label">Payment Status</label>
          <select name="payment_status" id="eo_pay" class="form-control">
            <option value="pending">Pending</option>
            <option value="paid">Paid</option>
            <option value="failed">Failed</option>
            <option value="refunded">Refunded</option>
          </select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" onclick="closeModal('editOrderModal')">Cancel</button>
        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Update Order</button>
      </div>
    </form>
  </div>
</div>

<!-- ── ORDER DETAIL MODAL ── -->
<div class="modal-overlay" id="orderDetailModal">
  <div class="modal" style="max-width:600px">
    <div class="modal-header">
      <h2 class="modal-title"><i class="fas fa-receipt" style="color:var(--secondary);margin-right:.4rem"></i>Order Details</h2>
      <button class="modal-close" onclick="closeModal('orderDetailModal')"><i class="fas fa-times"></i></button>
    </div>
    <div class="modal-body" id="orderDetailBody"></div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal('orderDetailModal')">Close</button>
    </div>
  </div>
</div>

<div id="sidebarOverlay" style="position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:850;display:none"
  onclick="document.getElementById('dashboardSidebar').classList.remove('open');this.style.display='none'"></div>

<script>
document.getElementById('sidebarOpenBtn')?.addEventListener('click',function(){
  document.getElementById('dashboardSidebar').classList.toggle('open');
  document.getElementById('sidebarOverlay').style.display =
    document.getElementById('dashboardSidebar').classList.contains('open') ? 'block' : 'none';
});

function closeModal(id){ document.getElementById(id).classList.remove('open'); }

function filterOrders(q){
  q = q.toLowerCase();
  document.querySelectorAll('#ordersTable tbody tr').forEach(row=>{
    row.style.display =
      (row.dataset.order||'').includes(q)||(row.dataset.customer||'').includes(q) ? '' : 'none';
  });
}

function openEditOrder(d){
  document.getElementById('eo_id').value      = d.id;
  document.getElementById('eo_number').textContent = d.order_number;
  document.getElementById('eo_status').value  = d.status;
  document.getElementById('eo_pay').value     = d.payment_status;
  document.getElementById('editOrderModal').classList.add('open');
}

function openOrderDetail(o){
  const f = v => '₹' + parseFloat(v||0).toLocaleString('en-IN');
  document.getElementById('orderDetailBody').innerHTML = `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem;margin-bottom:1.25rem">
      <div style="background:var(--surface-2);border-radius:10px;padding:1rem">
        <p style="font-size:.72rem;text-transform:uppercase;letter-spacing:.05em;color:var(--text-muted);margin-bottom:.35rem">Order Info</p>
        <p style="font-weight:800;color:var(--primary);margin-bottom:.25rem">${o.order_number}</p>
        <p style="font-size:.83rem;color:var(--text-muted)">${new Date(o.created_at).toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'})}</p>
      </div>
      <div style="background:var(--surface-2);border-radius:10px;padding:1rem">
        <p style="font-size:.72rem;text-transform:uppercase;letter-spacing:.05em;color:var(--text-muted);margin-bottom:.35rem">Customer</p>
        <p style="font-weight:700;margin-bottom:.2rem">${o.customer_name}</p>
        <p style="font-size:.8rem;color:var(--text-muted)">${o.customer_email}</p>
      </div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:.75rem;margin-bottom:1.25rem">
      <div style="background:var(--surface-2);border-radius:10px;padding:1rem;text-align:center">
        <p style="font-size:.72rem;color:var(--text-muted);margin-bottom:.35rem">Amount</p>
        <p style="font-weight:900;color:var(--primary)">${f(o.final_amount)}</p>
      </div>
      <div style="background:var(--surface-2);border-radius:10px;padding:1rem;text-align:center">
        <p style="font-size:.72rem;color:var(--text-muted);margin-bottom:.35rem">Payment</p>
        <p style="font-weight:700;text-transform:uppercase">${o.payment_method}</p>
        <span style="font-size:.72rem;font-weight:700;color:${o.payment_status==='paid'?'var(--accent)':'var(--danger)'}">${o.payment_status.toUpperCase()}</span>
      </div>
      <div style="background:var(--surface-2);border-radius:10px;padding:1rem;text-align:center">
        <p style="font-size:.72rem;color:var(--text-muted);margin-bottom:.35rem">Status</p>
        <span class="status-badge status-${o.status}">${o.status.charAt(0).toUpperCase()+o.status.slice(1)}</span>
      </div>
    </div>
    <div style="background:var(--surface-2);border-radius:10px;padding:1rem;margin-bottom:1.25rem">
      <p style="font-size:.72rem;text-transform:uppercase;letter-spacing:.05em;color:var(--text-muted);margin-bottom:.5rem">Shipping Address</p>
      <p style="font-size:.88rem;font-weight:600">${o.shipping_name || ''}, ${o.shipping_phone || ''}</p>
      <p style="font-size:.83rem;color:var(--text-muted)">${o.shipping_address||''}, ${o.shipping_city||''}, ${o.shipping_state||''} – ${o.shipping_pincode||''}</p>
    </div>
    <div style="display:flex;justify-content:space-between;font-size:.88rem;border-top:1px solid var(--border);padding-top:.85rem">
      <span>Subtotal: <strong>${f(o.total_amount)}</strong></span>
      <span>Shipping: <strong style="color:${parseFloat(o.shipping_amount||0)===0?'var(--accent)':'var(--text)'}">${parseFloat(o.shipping_amount||0)===0?'FREE':f(o.shipping_amount)}</strong></span>
      <span>Total: <strong style="color:var(--primary)">${f(o.final_amount)}</strong></span>
    </div>
  `;
  document.getElementById('orderDetailModal').classList.add('open');
}
</script>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body>
</html>
