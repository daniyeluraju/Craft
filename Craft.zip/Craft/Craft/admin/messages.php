<?php
require_once '../includes/auth.php';
require_role('admin');

$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $mid    = intval($_POST['mid'] ?? 0);

    if ($action === 'delete' && $mid) {
        db_query("DELETE FROM contact_messages WHERE id=?", [$mid]);
        $success = 'Message deleted.';
    }
    elseif ($action === 'mark_read' && $mid) {
        db_query("UPDATE contact_messages SET is_read=1 WHERE id=?", [$mid]);
    }
    elseif ($action === 'mark_all_read') {
        db_query("UPDATE contact_messages SET is_read=1");
        $success = 'All messages marked as read.';
    }
    elseif ($action === 'delete_all') {
        db_query("DELETE FROM contact_messages WHERE is_read=1");
        $success = 'All read messages deleted.';
    }
}

$filter  = sanitize($_GET['filter'] ?? 'all');
$where   = match($filter) {
    'unread' => 'WHERE is_read=0',
    'read'   => 'WHERE is_read=1',
    default  => ''
};
$messages   = db_fetch_all("SELECT * FROM contact_messages $where ORDER BY created_at DESC");
$unread_cnt = db_fetch("SELECT COUNT(*) as c FROM contact_messages WHERE is_read=0")['c'];
$total_cnt  = db_fetch("SELECT COUNT(*) as c FROM contact_messages")['c'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Messages – Admin | CraftStore</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/main.css">
</head>
<body>
<div class="dashboard-layout">
<?php include '../includes/sidebar.php'; ?>

<div class="dashboard-main">
  <div class="dashboard-topbar">
    <div style="display:flex;align-items:center;gap:1rem">
      <button class="btn btn-ghost btn-icon" id="sidebarOpenBtn"><i class="fas fa-bars"></i></button>
      <h1 class="topbar-title">Contact Messages</h1>
      <?php if ($unread_cnt > 0): ?>
      <span style="background:var(--danger);color:white;border-radius:50px;padding:.15rem .6rem;font-size:.75rem;font-weight:800"><?= $unread_cnt ?> new</span>
      <?php endif; ?>
    </div>
    <div class="topbar-actions">
      <?php if ($unread_cnt > 0): ?>
      <form method="POST" style="display:inline">
        <input type="hidden" name="action" value="mark_all_read">
        <button type="submit" class="btn btn-ghost btn-sm"><i class="fas fa-check-double"></i> Mark All Read</button>
      </form>
      <?php endif; ?>
      <form method="POST" style="display:inline"
        onsubmit="return confirm('Delete all read messages?')">
        <input type="hidden" name="action" value="delete_all">
        <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i> Clear Read</button>
      </form>
      <button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button>
    </div>
  </div>

  <div class="dashboard-content">

    <?php if ($success): ?>
    <div style="background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.3);border-radius:10px;padding:.9rem 1.1rem;margin-bottom:1.25rem;display:flex;gap:.6rem;color:var(--accent)">
      <i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?>
    </div>
    <?php endif; ?>

    <!-- Stats + Filter tabs -->
    <div style="display:flex;align-items:center;gap:1rem;margin-bottom:1.5rem;flex-wrap:wrap">
      <div style="display:flex;gap:.45rem">
        <?php foreach(['all'=>"All ($total_cnt)",'unread'=>"Unread ($unread_cnt)",'read'=>'Read'] as $f=>$label): ?>
        <a href="?filter=<?= $f ?>" style="padding:.42rem 1rem;border-radius:50px;font-size:.82rem;font-weight:600;transition:all .2s;<?= $filter===$f?'background:var(--primary);color:white;':'background:var(--surface);border:1px solid var(--border);color:var(--text-muted);' ?>">
          <?= $label ?>
        </a>
        <?php endforeach; ?>
      </div>
      <div style="margin-left:auto;position:relative">
        <i class="fas fa-search" style="position:absolute;left:.75rem;top:50%;transform:translateY(-50%);color:var(--text-muted);font-size:.8rem"></i>
        <input type="text" placeholder="Search messages…" oninput="filterMessages(this.value)"
          style="padding:.42rem .75rem .42rem 2.1rem;border:1px solid var(--border);border-radius:8px;background:var(--surface);color:var(--text);font-size:.85rem;font-family:var(--font)">
      </div>
    </div>

    <?php if (empty($messages)): ?>
    <div class="empty-state">
      <div class="empty-icon"><i class="fas fa-envelope-open"></i></div>
      <h3 class="empty-title">No Messages Found</h3>
      <p class="empty-subtitle">Contact form submissions will appear here</p>
    </div>
    <?php else: ?>
    <div id="messagesContainer" style="display:flex;flex-direction:column;gap:.85rem">
      <?php foreach ($messages as $msg): ?>
      <div class="message-card" id="msg-<?= $msg['id'] ?>"
        style="background:var(--surface);border:1px solid <?= !$msg['is_read'] ? 'var(--primary)' : 'var(--border)' ?>;border-radius:var(--radius-md);overflow:hidden;transition:var(--transition)"
        data-name="<?= strtolower($msg['name']) ?>" data-email="<?= strtolower($msg['email']) ?>" data-msg="<?= strtolower($msg['message']) ?>">

        <!-- Header -->
        <div style="padding:1.1rem 1.5rem;background:<?= !$msg['is_read'] ? 'rgba(124,58,237,.05)' : 'var(--surface-2)' ?>;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:.75rem">
          <div style="display:flex;align-items:center;gap:.85rem">
            <div style="width:42px;height:42px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--secondary));color:white;display:flex;align-items:center;justify-content:center;font-weight:800;flex-shrink:0">
              <?= strtoupper(substr($msg['name'],0,1)) ?>
            </div>
            <div>
              <div style="display:flex;align-items:center;gap:.5rem">
                <strong style="font-size:.92rem"><?= htmlspecialchars($msg['name']) ?></strong>
                <?php if (!$msg['is_read']): ?>
                <span style="background:var(--primary);color:white;border-radius:50px;padding:.08rem .5rem;font-size:.65rem;font-weight:800">NEW</span>
                <?php endif; ?>
              </div>
              <a href="mailto:<?= htmlspecialchars($msg['email']) ?>" style="font-size:.8rem;color:var(--text-muted)"><?= htmlspecialchars($msg['email']) ?></a>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:.75rem">
            <?php if ($msg['subject']): ?>
            <span class="tag"><?= htmlspecialchars($msg['subject']) ?></span>
            <?php endif; ?>
            <span style="font-size:.75rem;color:var(--text-muted)"><?= date('d M Y, h:i A', strtotime($msg['created_at'])) ?></span>
          </div>
        </div>

        <!-- Body -->
        <div style="padding:1.1rem 1.5rem">
          <p style="font-size:.9rem;color:var(--text-muted);line-height:1.7"><?= nl2br(htmlspecialchars($msg['message'])) ?></p>
        </div>

        <!-- Actions -->
        <div style="padding:.85rem 1.5rem;border-top:1px solid var(--border);display:flex;align-items:center;gap:.75rem;flex-wrap:wrap">
          <a href="mailto:<?= htmlspecialchars($msg['email']) ?>?subject=Re: <?= urlencode($msg['subject'] ?: 'Your Message – CraftStore') ?>&body=Hi <?= urlencode($msg['name']) ?>,%0D%0A%0D%0AThank you for contacting us...%0D%0A%0D%0ARegards,%0D%0ACraftStore Team"
            class="btn btn-primary btn-sm" onclick="markRead(<?= $msg['id'] ?>)">
            <i class="fas fa-reply"></i> Reply via Email
          </a>

          <?php if (!$msg['is_read']): ?>
          <form method="POST" style="display:inline">
            <input type="hidden" name="action" value="mark_read">
            <input type="hidden" name="mid" value="<?= $msg['id'] ?>">
            <button type="submit" class="btn btn-ghost btn-sm">
              <i class="fas fa-check"></i> Mark Read
            </button>
          </form>
          <?php endif; ?>

          <form method="POST" style="display:inline;margin-left:auto"
            onsubmit="return confirm('Delete this message from <?= htmlspecialchars($msg['name'], ENT_QUOTES) ?>?')">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="mid" value="<?= $msg['id'] ?>">
            <button type="submit" class="btn btn-danger btn-sm btn-icon" title="Delete message">
              <i class="fas fa-trash"></i>
            </button>
          </form>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</div>
</div>

<div id="sidebarOverlay" style="position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:850;display:none"
  onclick="document.getElementById('dashboardSidebar').classList.remove('open');this.style.display='none'"></div>

<script>
document.getElementById('sidebarOpenBtn')?.addEventListener('click',function(){
  document.getElementById('dashboardSidebar').classList.toggle('open');
  document.getElementById('sidebarOverlay').style.display =
    document.getElementById('dashboardSidebar').classList.contains('open') ? 'block' : 'none';
});

function filterMessages(q){
  q = q.toLowerCase();
  document.querySelectorAll('.message-card').forEach(card=>{
    const match = (card.dataset.name||'').includes(q) ||
                  (card.dataset.email||'').includes(q) ||
                  (card.dataset.msg||'').includes(q);
    card.style.display = match ? '' : 'none';
  });
}

function markRead(id){
  fetch('/Craft/admin/messages.php',{
    method:'POST',
    headers:{'Content-Type':'application/x-www-form-urlencoded'},
    body:'action=mark_read&mid='+id
  });
}
</script>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body>
</html>
