<?php
require_once '../includes/auth.php';
require_login();
$uid = get_user_id();
$user = get_current_user_data();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = sanitize($_POST['name'] ?? '');
    $phone   = sanitize($_POST['phone'] ?? '');
    $address = sanitize($_POST['address'] ?? '');
    
    if ($name) {
        db_query("UPDATE users SET name=?, phone=?, address=?, updated_at=NOW() WHERE id=?", [$name, $phone, $address, $uid]);
        $_SESSION['user_name'] = $name;
        if (!empty($_POST['password'])) {
            if (strlen($_POST['password']) >= 6 && $_POST['password'] === $_POST['confirm_password']) {
                db_query("UPDATE users SET password=? WHERE id=?", [password_hash($_POST['password'], PASSWORD_DEFAULT), $uid]);
            }
        }
        redirect_with_message('/Craft/'.get_role().'/profile.php', 'Profile updated successfully!', 'success');
    }
}
$user = get_current_user_data();
$flash = get_flash_message();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Profile – CraftStore</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/main.css">
</head>
<body>
<div class="dashboard-layout">
    <?php include '../includes/sidebar.php'; ?>
    <div class="dashboard-main">
        <div class="dashboard-topbar">
            <div style="display:flex;align-items:center;gap:1rem">
                <button class="btn btn-ghost btn-icon" id="sidebarOpenBtn"><i class="fas fa-bars"></i></button>
                <h1 class="topbar-title">My Profile</h1>
            </div>
            <div class="topbar-actions"><button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button></div>
        </div>
        <div class="dashboard-content">
            <?php if ($flash): ?>
            <div style="background:rgba(16,185,129,0.08);border:1px solid rgba(16,185,129,0.25);border-radius:10px;padding:1rem;margin-bottom:1.25rem;color:var(--accent);display:flex;gap:.5rem"><i class="fas fa-check-circle"></i> <?= $flash['message'] ?></div>
            <?php endif; ?>

            <div style="display:grid;grid-template-columns:280px 1fr;gap:1.5rem;align-items:start">
                <!-- Profile Card -->
                <div style="background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);padding:2rem;text-align:center">
                    <div style="width:90px;height:90px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--secondary));display:flex;align-items:center;justify-content:center;font-size:2.2rem;font-weight:900;color:white;margin:0 auto 1.25rem">
                        <?= strtoupper(substr($user['name'],0,1)) ?>
                    </div>
                    <h2 style="font-size:1.15rem;font-weight:800;margin-bottom:.25rem"><?= htmlspecialchars($user['name']) ?></h2>
                    <p style="font-size:.82rem;color:var(--text-muted);margin-bottom:.75rem"><?= htmlspecialchars($user['email']) ?></p>
                    <span class="role-badge <?= $user['role_name'] ?>" style="font-size:.78rem"><?= ucfirst($user['role_name']) ?></span>
                    <div style="margin-top:1.5rem;padding-top:1.25rem;border-top:1px solid var(--border)">
                        <?php if ($user['phone']): ?>
                        <p style="font-size:.82rem;color:var(--text-muted);display:flex;align-items:center;gap:.4rem;justify-content:center;margin-bottom:.4rem">
                            <i class="fas fa-phone"></i> <?= htmlspecialchars($user['phone']) ?>
                        </p>
                        <?php endif; ?>
                        <p style="font-size:.78rem;color:var(--text-muted)">Member since <?= date('M Y', strtotime($user['created_at'])) ?></p>
                    </div>
                </div>

                <!-- Edit Form -->
                <div style="background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);padding:1.75rem">
                    <h3 style="font-size:1rem;font-weight:700;margin-bottom:1.5rem">Edit Profile Information</h3>
                    <form method="POST">
                        <div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem">
                            <div class="form-group">
                                <label class="form-label">Full Name *</label>
                                <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($user['name']) ?>" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Phone</label>
                                <input type="tel" name="phone" class="form-control" value="<?= htmlspecialchars($user['phone'] ?? '') ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Email Address</label>
                            <input type="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" disabled style="opacity:.6">
                            <p class="form-hint">Email cannot be changed</p>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Address</label>
                            <textarea name="address" class="form-control" rows="3"><?= htmlspecialchars($user['address'] ?? '') ?></textarea>
                        </div>

                        <h3 style="font-size:.95rem;font-weight:700;margin:1.5rem 0 1rem;padding-top:1.5rem;border-top:1px solid var(--border)">Change Password</h3>
                        <div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem">
                            <div class="form-group">
                                <label class="form-label">New Password</label>
                                <input type="password" name="password" class="form-control" placeholder="Leave blank to keep current">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Confirm Password</label>
                                <input type="password" name="confirm_password" class="form-control" placeholder="Repeat new password">
                            </div>
                        </div>

                        <div style="display:flex;gap:1rem;margin-top:1.25rem">
                            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Changes</button>
                            <a href="/Craft/<?= get_role() ?>/index.php" class="btn btn-ghost"><i class="fas fa-arrow-left"></i> Back</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="sidebarOverlay" style="position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:850;display:none" onclick="document.getElementById('dashboardSidebar').classList.remove('open');this.style.display='none'"></div>
<script>document.getElementById('sidebarOpenBtn')?.addEventListener('click', function() { document.getElementById('dashboardSidebar').classList.toggle('open'); document.getElementById('sidebarOverlay').style.display = document.getElementById('dashboardSidebar').classList.contains('open') ? 'block' : 'none'; });</script>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body></html>
