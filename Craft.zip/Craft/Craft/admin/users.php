<?php
require_once '../includes/auth.php';
require_role('admin');

$error = $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action  = $_POST['action']  ?? '';
    $user_id = intval($_POST['user_id'] ?? 0);

    /* ── ADD USER ── */
    if ($action === 'add_user') {
        $name     = sanitize($_POST['name']      ?? '');
        $email    = sanitize($_POST['email']     ?? '');
        $phone    = sanitize($_POST['phone']     ?? '');
        $password = $_POST['password']           ?? '';
        $role     = sanitize($_POST['role_name'] ?? 'customer');

        if (!$name || !$email || !$password) { $error = 'Name, email and password are required.'; }
        elseif (strlen($password) < 6)        { $error = 'Password must be at least 6 characters.'; }
        else {
            if (db_fetch("SELECT id FROM users WHERE email=?", [$email])) { $error = 'Email already registered.'; }
            else {
                $role_row = db_fetch("SELECT id FROM roles WHERE name=?", [$role]);
                if (!$role_row) { $error = 'Invalid role.'; }
                else {
                    db_query("INSERT INTO users (role_id,name,email,password,phone,is_active,created_at) VALUES (?,?,?,?,?,1,NOW())",
                        [$role_row['id'], $name, $email, password_hash($password, PASSWORD_DEFAULT), $phone]);
                    $uid = db_last_id();
                    if ($role === 'seller') {
                        db_query("INSERT INTO seller_profiles (user_id,shop_name) VALUES (?,?)", [$uid, "$name's Shop"]);
                    }
                    $success = "User \"$name\" added!";
                }
            }
        }
    }

    /* ── DELETE USER ── */
    elseif ($action === 'delete' && $user_id) {
        if ($user_id == get_user_id()) { $error = 'Cannot delete your own account.'; }
        else {
            $tgt = db_fetch("SELECT u.*, r.name as rname FROM users u JOIN roles r ON u.role_id=r.id WHERE u.id=?", [$user_id]);
            if (!$tgt)                    { $error = 'User not found.'; }
            elseif ($tgt['rname']==='admin') { $error = 'Cannot delete admin accounts.'; }
            else {
                global $pdo;
                $pdo->exec("SET FOREIGN_KEY_CHECKS=0");
                $pdo->exec("DELETE FROM cart           WHERE user_id=$user_id");
                $pdo->exec("DELETE FROM wishlist       WHERE user_id=$user_id");
                $pdo->exec("DELETE FROM reviews        WHERE user_id=$user_id");
                $pdo->exec("DELETE FROM notifications  WHERE user_id=$user_id");
                $pdo->exec("DELETE FROM payments       WHERE user_id=$user_id");
                $pdo->exec("DELETE FROM seller_profiles WHERE user_id=$user_id");
                $pdo->exec("UPDATE orders      SET user_id=1 WHERE user_id=$user_id");
                $pdo->exec("UPDATE order_items SET seller_id=1 WHERE seller_id=$user_id");
                $pdo->exec("UPDATE products    SET status='rejected' WHERE seller_id=$user_id");
                $pdo->exec("DELETE FROM users  WHERE id=$user_id");
                $pdo->exec("SET FOREIGN_KEY_CHECKS=1");
                $success = "User deleted.";
            }
        }
    }

    /* ── TOGGLE STATUS ── */
    elseif ($action === 'toggle_active' && $user_id) {
        $u = db_fetch("SELECT is_active FROM users WHERE id=?", [$user_id]);
        if ($u) { db_query("UPDATE users SET is_active=? WHERE id=?", [$u['is_active']?0:1, $user_id]); $success='Status updated.'; }
    }

    /* ── EDIT USER ── */
    elseif ($action === 'edit_user' && $user_id) {
        $name  = sanitize($_POST['name']  ?? '');
        $email = sanitize($_POST['email'] ?? '');
        $phone = sanitize($_POST['phone'] ?? '');
        $role  = sanitize($_POST['role_name'] ?? '');
        if (!$name||!$email) { $error='Name and email required.'; }
        else {
            $rr = db_fetch("SELECT id FROM roles WHERE name=?",[$role]);
            if ($rr) {
                db_query("UPDATE users SET name=?,email=?,phone=?,role_id=?,updated_at=NOW() WHERE id=?",[$name,$email,$phone,$rr['id'],$user_id]);
                if (!empty($_POST['new_password']) && strlen($_POST['new_password'])>=6) {
                    db_query("UPDATE users SET password=? WHERE id=?",[password_hash($_POST['new_password'],PASSWORD_DEFAULT),$user_id]);
                }
                $success='User updated.';
            }
        }
    }
}

$users  = db_fetch_all("SELECT u.*, r.name as role_name FROM users u JOIN roles r ON u.role_id=r.id ORDER BY u.created_at DESC");
$rcounts= db_fetch_all("SELECT r.name, COUNT(u.id) as c FROM roles r LEFT JOIN users u ON u.role_id=r.id GROUP BY r.id");
$rmeta  = ['admin'=>['fa-user-shield','red'],'seller'=>['fa-store','amber'],'customer'=>['fa-user','green']];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Users – Admin | CraftStore</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/main.css">
<style>
  /* Inline delete-confirm row */
  .del-confirm-row { display:none;background:rgba(239,68,68,.06);border-top:1px solid rgba(239,68,68,.2) }
  .del-confirm-row.show { display:table-row }
  .del-confirm-cell { padding:.75rem 1rem!important }
</style>
</head>
<body>
<div class="dashboard-layout">
<?php include '../includes/sidebar.php'; ?>

<div class="dashboard-main">
  <div class="dashboard-topbar">
    <div style="display:flex;align-items:center;gap:1rem">
      <button class="btn btn-ghost btn-icon" id="sidebarOpenBtn"><i class="fas fa-bars"></i></button>
      <h1 class="topbar-title">User Management</h1>
    </div>
    <div class="topbar-actions">
      <button class="btn btn-primary btn-sm" id="openAddUserBtn">
        <i class="fas fa-user-plus"></i> Add New User
      </button>
      <button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button>
    </div>
  </div>

  <div class="dashboard-content">
    <?php if ($success): ?>
    <div style="background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.3);border-radius:10px;padding:.9rem 1.1rem;margin-bottom:1.25rem;display:flex;align-items:center;gap:.6rem;color:var(--accent)">
      <i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?>
    </div>
    <?php endif; ?>
    <?php if ($error): ?>
    <div style="background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);border-radius:10px;padding:.9rem 1.1rem;margin-bottom:1.25rem;display:flex;align-items:center;gap:.6rem;color:var(--danger)">
      <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?>
    </div>
    <?php endif; ?>

    <!-- Stats -->
    <div class="stats-grid" style="grid-template-columns:repeat(3,1fr);margin-bottom:1.5rem">
      <?php foreach($rcounts as $rc): [$ico,$col]=$rmeta[$rc['name']]??['fa-user','purple']; ?>
      <div class="stat-card">
        <div class="stat-icon <?=$col?>"><i class="fas <?=$ico?>"></i></div>
        <div><p class="stat-value"><?=$rc['c']?></p><p class="stat-label"><?=ucfirst($rc['name'])?>s</p></div>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- Table -->
    <div class="table-wrapper">
      <div class="table-header">
        <h3>All Users (<?=count($users)?>)</h3>
        <div style="position:relative">
          <i class="fas fa-search" style="position:absolute;left:.75rem;top:50%;transform:translateY(-50%);color:var(--text-muted);font-size:.82rem"></i>
          <input type="text" placeholder="Search…" oninput="filterUsers(this.value)"
            style="padding:.45rem .75rem .45rem 2.2rem;border:1px solid var(--border);border-radius:8px;background:var(--surface);color:var(--text);font-family:var(--font);font-size:.85rem">
        </div>
      </div>

      <table class="data-table" id="usersTable">
        <thead>
          <tr><th>#</th><th>User</th><th>Email</th><th>Role</th><th>Phone</th><th>Joined</th><th>Status</th><th>Actions</th></tr>
        </thead>
        <tbody>
        <?php foreach($users as $i=>$u): ?>
        <!-- Main row -->
        <tr data-uid="<?=$u['id']?>" data-name="<?=strtolower($u['name'])?>" data-email="<?=strtolower($u['email'])?>">
          <td style="color:var(--text-muted);font-size:.8rem"><?=$i+1?></td>
          <td>
            <div style="display:flex;align-items:center;gap:.6rem">
              <div style="width:36px;height:36px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--secondary));display:flex;align-items:center;justify-content:center;color:white;font-weight:700;font-size:.85rem;flex-shrink:0">
                <?=strtoupper(substr($u['name'],0,1))?>
              </div>
              <span style="font-weight:600;font-size:.88rem"><?=htmlspecialchars($u['name'])?></span>
            </div>
          </td>
          <td style="font-size:.85rem"><?=htmlspecialchars($u['email'])?></td>
          <td><span class="role-badge <?=$u['role_name']?>"><?=ucfirst($u['role_name'])?></span></td>
          <td style="font-size:.85rem"><?=$u['phone']?:'–'?></td>
          <td style="font-size:.8rem;color:var(--text-muted)"><?=date('d M Y',strtotime($u['created_at']))?></td>
          <td>
            <span style="font-size:.78rem;font-weight:600;color:<?=$u['is_active']?'var(--accent)':'var(--danger)'?>">
              <i class="fas fa-circle" style="font-size:.45rem;vertical-align:middle"></i>
              <?=$u['is_active']?'Active':'Inactive'?>
            </span>
          </td>
          <td>
            <div style="display:flex;gap:.35rem;align-items:center">
            <?php if($u['role_name']!=='admin'): ?>
              <!-- Edit -->
              <button class="btn btn-ghost btn-sm btn-icon" title="Edit"
                onclick='fillEditUser(<?=json_encode(["id"=>$u["id"],"name"=>$u["name"],"email"=>$u["email"],"phone"=>$u["phone"],"role_name"=>$u["role_name"]])?>)'>
                <i class="fas fa-edit" style="color:var(--info)"></i>
              </button>

              <!-- Toggle status -->
              <form method="POST" style="display:inline">
                <input type="hidden" name="action"  value="toggle_active">
                <input type="hidden" name="user_id" value="<?=$u['id']?>">
                <button type="submit" class="btn btn-ghost btn-sm btn-icon" title="<?=$u['is_active']?'Deactivate':'Activate'?>">
                  <i class="fas fa-<?=$u['is_active']?'ban':'check-circle'?>" style="color:var(--secondary)"></i>
                </button>
              </form>

              <!-- Delete (reveals confirm row) -->
              <button class="btn btn-danger btn-sm btn-icon" title="Delete"
                onclick="showDelRow(<?=$u['id']?>)"
                id="del-btn-<?=$u['id']?>">
                <i class="fas fa-trash"></i>
              </button>
            <?php else: ?>
              <span style="font-size:.75rem;color:var(--text-muted)">Protected</span>
            <?php endif; ?>
            </div>
          </td>
        </tr>
        <!-- Confirm-delete row (hidden by default) -->
        <?php if($u['role_name']!=='admin'): ?>
        <tr class="del-confirm-row" id="del-row-<?=$u['id']?>">
          <td class="del-confirm-cell" colspan="8">
            <div style="display:flex;align-items:center;gap:1rem;flex-wrap:wrap">
              <i class="fas fa-exclamation-triangle" style="color:var(--danger)"></i>
              <span style="font-size:.88rem;font-weight:600">
                Delete <strong><?=htmlspecialchars($u['name'])?></strong>? This cannot be undone.
              </span>
              <!-- The actual delete form -->
              <form method="POST" style="display:inline">
                <input type="hidden" name="action"  value="delete">
                <input type="hidden" name="user_id" value="<?=$u['id']?>">
                <button type="submit" class="btn btn-danger btn-sm">
                  <i class="fas fa-trash"></i> Yes, Delete
                </button>
              </form>
              <button type="button" class="btn btn-ghost btn-sm" onclick="hideDelRow(<?=$u['id']?>)">
                Cancel
              </button>
            </div>
          </td>
        </tr>
        <?php endif; ?>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div><!-- /table-wrapper -->
  </div><!-- /dashboard-content -->
</div><!-- /dashboard-main -->
</div><!-- /layout -->

<!-- ══ ADD USER MODAL ══ -->
<div class="modal-overlay" id="addUserModal" style="pointer-events:none;opacity:0;visibility:hidden">
  <div class="modal" style="max-width:500px">
    <div class="modal-header">
      <h2 class="modal-title"><i class="fas fa-user-plus" style="color:var(--accent);margin-right:.4rem"></i>Add New User</h2>
      <button class="modal-close" id="closeAddUserModal"><i class="fas fa-times"></i></button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="action" value="add_user">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem">
          <div class="form-group">
            <label class="form-label">Full Name *</label>
            <input type="text" name="name" class="form-control" required>
          </div>
          <div class="form-group">
            <label class="form-label">Phone</label>
            <input type="tel" name="phone" class="form-control">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Email *</label>
          <input type="email" name="email" class="form-control" required>
        </div>
        <div class="form-group">
          <label class="form-label">Role</label>
          <select name="role_name" class="form-control">
            <option value="customer">Customer</option>
            <option value="seller">Seller</option>
            <option value="admin">Admin</option>
          </select>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem">
          <div class="form-group">
            <label class="form-label">Password *</label>
            <input type="password" name="password" class="form-control" required minlength="6" placeholder="Min 6 chars">
          </div>
          <div class="form-group">
            <label class="form-label">Confirm Password *</label>
            <input type="password" name="confirm_password" class="form-control" required minlength="6">
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" id="cancelAddUser">Cancel</button>
        <button type="submit" class="btn btn-primary"><i class="fas fa-user-plus"></i> Create User</button>
      </div>
    </form>
  </div>
</div>

<!-- ══ EDIT USER MODAL ══ -->
<div class="modal-overlay" id="editUserModal" style="pointer-events:none;opacity:0;visibility:hidden">
  <div class="modal" style="max-width:480px">
    <div class="modal-header">
      <h2 class="modal-title"><i class="fas fa-user-edit" style="color:var(--info);margin-right:.4rem"></i>Edit User</h2>
      <button class="modal-close" id="closeEditUserModal"><i class="fas fa-times"></i></button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="action"  value="edit_user">
        <input type="hidden" name="user_id" id="eu_id">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem">
          <div class="form-group">
            <label class="form-label">Full Name *</label>
            <input type="text" name="name" id="eu_name" class="form-control" required>
          </div>
          <div class="form-group">
            <label class="form-label">Phone</label>
            <input type="tel" name="phone" id="eu_phone" class="form-control">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Email *</label>
          <input type="email" name="email" id="eu_email" class="form-control" required>
        </div>
        <div class="form-group">
          <label class="form-label">Role</label>
          <select name="role_name" id="eu_role" class="form-control">
            <option value="customer">Customer</option>
            <option value="seller">Seller</option>
            <option value="admin">Admin</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">New Password <small style="color:var(--text-muted)">(blank = keep current)</small></label>
          <input type="password" name="new_password" class="form-control" placeholder="Min 6 chars">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" id="cancelEditUser">Cancel</button>
        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Changes</button>
      </div>
    </form>
  </div>
</div>

<div id="sidebarOverlay" style="position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:850;display:none"
  onclick="document.getElementById('dashboardSidebar').classList.remove('open');this.style.display='none'"></div>

<script>
/* -- Sidebar -- */
document.getElementById('sidebarOpenBtn')?.addEventListener('click', function () {
  document.getElementById('dashboardSidebar').classList.toggle('open');
  document.getElementById('sidebarOverlay').style.display =
    document.getElementById('dashboardSidebar').classList.contains('open') ? 'block' : 'none';
});

/* -- Modal open / close (manual style to avoid CSS issues) -- */
function showModal(id) {
  const m = document.getElementById(id);
  m.style.pointerEvents = 'auto';
  m.style.opacity       = '1';
  m.style.visibility    = 'visible';
  m.classList.add('open');
}
function hideModal(id) {
  const m = document.getElementById(id);
  m.style.pointerEvents = 'none';
  m.style.opacity       = '0';
  m.style.visibility    = 'hidden';
  m.classList.remove('open');
}

document.getElementById('openAddUserBtn').addEventListener('click',  ()=> showModal('addUserModal'));
document.getElementById('closeAddUserModal').addEventListener('click', ()=> hideModal('addUserModal'));
document.getElementById('cancelAddUser').addEventListener('click',    ()=> hideModal('addUserModal'));
document.getElementById('closeEditUserModal').addEventListener('click',()=> hideModal('editUserModal'));
document.getElementById('cancelEditUser').addEventListener('click',   ()=> hideModal('editUserModal'));

/* Backdrop click */
['addUserModal','editUserModal'].forEach(id => {
  document.getElementById(id).addEventListener('click', function(e){
    if (e.target === this) hideModal(id);
  });
});

/* -- Delete confirm rows -- */
function showDelRow(uid) {
  // Hide any open confirm rows first
  document.querySelectorAll('.del-confirm-row.show').forEach(r => r.classList.remove('show'));
  document.getElementById('del-row-' + uid).classList.add('show');
}
function hideDelRow(uid) {
  document.getElementById('del-row-' + uid).classList.remove('show');
}

/* -- Table search -- */
function filterUsers(q) {
  q = q.toLowerCase();
  document.querySelectorAll('#usersTable tbody tr[data-uid]').forEach(row => {
    const match = (row.dataset.name||'').includes(q)||(row.dataset.email||'').includes(q);
    // Show/hide the main row and its sibling confirm row
    row.style.display = match ? '' : 'none';
    const next = row.nextElementSibling;
    if (next && next.classList.contains('del-confirm-row')) {
      next.style.display = match ? '' : 'none';
    }
  });
}

/* -- Edit user -- */
function fillEditUser(d) {
  document.getElementById('eu_id').value    = d.id;
  document.getElementById('eu_name').value  = d.name;
  document.getElementById('eu_email').value = d.email;
  document.getElementById('eu_phone').value = d.phone || '';
  document.getElementById('eu_role').value  = d.role_name;
  showModal('editUserModal');
}
</script>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body>
</html>
