<?php
require_once '../includes/auth.php';
require_role('admin');

$error = $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $name        = sanitize($_POST['name'] ?? '');
        $description = sanitize($_POST['description'] ?? '');
        $icon        = sanitize($_POST['icon'] ?? 'fa-tag');
        $is_active   = isset($_POST['is_active']) ? 1 : 0;

        if (!$name) { $error = 'Category name is required.'; }
        else {
            $slug = strtolower(preg_replace('/[^a-zA-Z0-9]+/','-', $name)).'-'.time();
            $exists = db_fetch("SELECT id FROM categories WHERE name=?", [$name]);
            if ($exists) { $error = 'A category with this name already exists.'; }
            else {
                db_query("INSERT INTO categories (name,slug,description,icon,is_active) VALUES (?,?,?,?,?)",
                    [$name, $slug, $description, $icon, $is_active]);
                $success = "Category \"$name\" created successfully!";
            }
        }
    }
    elseif ($action === 'edit') {
        $cid         = intval($_POST['cid'] ?? 0);
        $name        = sanitize($_POST['name'] ?? '');
        $description = sanitize($_POST['description'] ?? '');
        $icon        = sanitize($_POST['icon'] ?? 'fa-tag');
        $is_active   = isset($_POST['is_active']) ? 1 : 0;

        if (!$cid || !$name) { $error = 'Category name is required.'; }
        else {
            db_query("UPDATE categories SET name=?,description=?,icon=?,is_active=?,updated_at=NOW() WHERE id=?",
                [$name, $description, $icon, $is_active, $cid]);
            $success = "Category updated successfully!";
        }
    }
    elseif ($action === 'delete') {
        $cid = intval($_POST['cid'] ?? 0);
        $prod_count = db_fetch("SELECT COUNT(*) as c FROM products WHERE category_id=?", [$cid])['c'];
        if ($prod_count > 0) {
            $error = "Cannot delete: this category has $prod_count product(s). Reassign them first.";
        } else {
            db_query("DELETE FROM categories WHERE id=?", [$cid]);
            $success = "Category deleted.";
        }
    }
    elseif ($action === 'toggle') {
        $cid = intval($_POST['cid'] ?? 0);
        $cat = db_fetch("SELECT is_active FROM categories WHERE id=?", [$cid]);
        if ($cat) {
            db_query("UPDATE categories SET is_active=? WHERE id=?", [$cat['is_active']?0:1, $cid]);
            $success = "Category status toggled.";
        }
    }
}

$categories = db_fetch_all(
    "SELECT c.*, COUNT(p.id) as product_count
     FROM categories c
     LEFT JOIN products p ON p.category_id=c.id AND p.status='approved'
     GROUP BY c.id
     ORDER BY c.name ASC"
);

$icon_opts = [
    'fa-paint-brush'=>'Paint Brush','fa-gem'=>'Gem','fa-home'=>'Home',
    'fa-ring'=>'Ring','fa-wine-glass'=>'Vase','fa-cut'=>'Scissors',
    'fa-tshirt'=>'Shirt','fa-leaf'=>'Leaf','fa-star'=>'Star',
    'fa-heart'=>'Heart','fa-tree'=>'Tree','fa-tag'=>'Tag',
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Categories – Admin | CraftStore</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/main.css">
</head>
<body>
<div class="dashboard-layout">
<?php include '../includes/sidebar.php'; ?>

<div class="dashboard-main">
  <div class="dashboard-topbar">
    <div style="display:flex;align-items:center;gap:1rem">
      <button class="btn btn-ghost btn-icon" id="sidebarOpenBtn"><i class="fas fa-bars"></i></button>
      <h1 class="topbar-title">Category Management</h1>
    </div>
    <div class="topbar-actions">
      <button class="btn btn-primary btn-sm" onclick="openAddModal()">
        <i class="fas fa-plus"></i> Add Category
      </button>
      <button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button>
    </div>
  </div>

  <div class="dashboard-content">
    <?php if ($success): ?>
    <div style="background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.3);border-radius:10px;padding:.9rem 1.1rem;margin-bottom:1.25rem;display:flex;gap:.6rem;color:var(--accent)">
      <i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?>
    </div>
    <?php endif; ?>
    <?php if ($error): ?>
    <div style="background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);border-radius:10px;padding:.9rem 1.1rem;margin-bottom:1.25rem;display:flex;gap:.6rem;color:var(--danger)">
      <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?>
    </div>
    <?php endif; ?>

    <!-- Category Cards -->
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:1.25rem;margin-bottom:2rem">
      <?php foreach ($categories as $cat): ?>
      <div style="background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);padding:1.5rem;transition:var(--transition)"
        onmouseover="this.style.boxShadow='var(--shadow-lg)';this.style.borderColor='var(--primary-light)'"
        onmouseout="this.style.boxShadow='';this.style.borderColor='var(--border)'">
        <div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:1rem">
          <div style="display:flex;align-items:center;gap:.85rem">
            <div style="width:50px;height:50px;border-radius:14px;background:linear-gradient(135deg,var(--primary),var(--primary-light));display:flex;align-items:center;justify-content:center">
              <i class="fas <?= htmlspecialchars($cat['icon'] ?? 'fa-tag') ?>" style="color:white;font-size:1.1rem"></i>
            </div>
            <div>
              <h3 style="font-size:.98rem;font-weight:800;margin-bottom:.2rem"><?= htmlspecialchars($cat['name']) ?></h3>
              <span style="font-size:.72rem;font-weight:700;color:<?= $cat['is_active']?'var(--accent)':'var(--danger)' ?>">
                <?= $cat['is_active'] ? '● Active' : '● Inactive' ?>
              </span>
            </div>
          </div>
          <div style="display:flex;gap:.3rem">
            <!-- Edit -->
            <button class="btn btn-ghost btn-sm btn-icon" title="Edit"
              onclick='openEditModal(<?= json_encode([
                "id"=>$cat["id"],"name"=>$cat["name"],"description"=>$cat["description"],"icon"=>$cat["icon"],"is_active"=>$cat["is_active"]
              ]) ?>)'>
              <i class="fas fa-edit" style="color:var(--info)"></i>
            </button>
            <!-- Toggle -->
            <form method="POST" style="display:inline">
              <input type="hidden" name="action" value="toggle">
              <input type="hidden" name="cid" value="<?= $cat['id'] ?>">
              <button type="submit" class="btn btn-ghost btn-sm btn-icon"
                title="<?= $cat['is_active'] ? 'Deactivate' : 'Activate' ?>">
                <i class="fas fa-<?= $cat['is_active'] ? 'eye-slash' : 'eye' ?>" style="color:var(--secondary)"></i>
              </button>
            </form>
            <!-- Delete -->
            <form method="POST" style="display:inline"
              onsubmit="return confirm('Delete category \"<?= htmlspecialchars($cat['name'], ENT_QUOTES) ?>\"?')">
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="cid" value="<?= $cat['id'] ?>">
              <button type="submit" class="btn btn-danger btn-sm btn-icon" title="Delete">
                <i class="fas fa-trash"></i>
              </button>
            </form>
          </div>
        </div>

        <?php if ($cat['description']): ?>
        <p style="font-size:.83rem;color:var(--text-muted);margin-bottom:.85rem;line-height:1.5"><?= htmlspecialchars(substr($cat['description'],0,80)) ?></p>
        <?php endif; ?>

        <div style="display:flex;align-items:center;justify-content:space-between;padding-top:.85rem;border-top:1px solid var(--border)">
          <span style="font-size:.82rem;color:var(--text-muted)">
            <i class="fas fa-box" style="margin-right:.3rem"></i><?= $cat['product_count'] ?> product<?= $cat['product_count']!=1?'s':'' ?>
          </span>
          <a href="/Craft/public/shop.php?category=<?= $cat['id'] ?>" target="_blank"
            style="font-size:.78rem;color:var(--primary);font-weight:600" title="View in shop">
            View in shop <i class="fas fa-external-link-alt"></i>
          </a>
        </div>
      </div>
      <?php endforeach; ?>

      <!-- Add New Card -->
      <div style="background:var(--surface-2);border:2px dashed var(--border);border-radius:var(--radius-lg);padding:1.5rem;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:.6rem;cursor:pointer;min-height:180px;transition:var(--transition)"
        onclick="openAddModal()"
        onmouseover="this.style.borderColor='var(--primary)';this.style.background='rgba(124,58,237,.04)'"
        onmouseout="this.style.borderColor='var(--border)';this.style.background='var(--surface-2)'">
        <div style="width:48px;height:48px;border-radius:14px;background:rgba(124,58,237,.08);display:flex;align-items:center;justify-content:center">
          <i class="fas fa-plus" style="color:var(--primary);font-size:1.1rem"></i>
        </div>
        <p style="font-weight:700;font-size:.88rem;color:var(--text-muted)">Add New Category</p>
      </div>
    </div>

    <!-- Table view -->
    <div class="table-wrapper">
      <div class="table-header"><h3>All Categories (<?= count($categories) ?>)</h3></div>
      <table class="data-table">
        <thead><tr><th>#</th><th>Name</th><th>Slug</th><th>Products</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody>
        <?php foreach($categories as $i=>$cat): ?>
        <tr>
          <td style="color:var(--text-muted)"><?= $i+1 ?></td>
          <td>
            <div style="display:flex;align-items:center;gap:.6rem">
              <div style="width:32px;height:32px;border-radius:8px;background:linear-gradient(135deg,var(--primary),var(--primary-light));display:flex;align-items:center;justify-content:center;flex-shrink:0">
                <i class="fas <?= htmlspecialchars($cat['icon']??'fa-tag') ?>" style="color:white;font-size:.75rem"></i>
              </div>
              <strong style="font-size:.88rem"><?= htmlspecialchars($cat['name']) ?></strong>
            </div>
          </td>
          <td style="font-size:.8rem;color:var(--text-muted);font-family:monospace"><?= htmlspecialchars($cat['slug']) ?></td>
          <td><strong style="color:var(--primary)"><?= $cat['product_count'] ?></strong></td>
          <td><span class="status-badge <?= $cat['is_active']?'status-approved':'status-cancelled' ?>"><?= $cat['is_active']?'Active':'Inactive' ?></span></td>
          <td>
            <div style="display:flex;gap:.3rem">
              <button class="btn btn-ghost btn-sm btn-icon"
                onclick='openEditModal(<?= json_encode(["id"=>$cat["id"],"name"=>$cat["name"],"description"=>$cat["description"],"icon"=>$cat["icon"],"is_active"=>$cat["is_active"]]) ?>)'>
                <i class="fas fa-edit" style="color:var(--info)"></i>
              </button>
              <form method="POST" style="display:inline"
                onsubmit="return confirm('Delete this category?')">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="cid" value="<?= $cat['id'] ?>">
                <button type="submit" class="btn btn-danger btn-sm btn-icon"><i class="fas fa-trash"></i></button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
</div>

<!-- ── ADD MODAL ── -->
<div class="modal-overlay" id="addCatModal">
  <div class="modal" style="max-width:460px">
    <div class="modal-header">
      <h2 class="modal-title"><i class="fas fa-plus-circle" style="color:var(--accent);margin-right:.4rem"></i>Add New Category</h2>
      <button class="modal-close" onclick="closeModal('addCatModal')"><i class="fas fa-times"></i></button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="action" value="add">
        <div class="form-group">
          <label class="form-label">Category Name *</label>
          <input type="text" name="name" class="form-control" placeholder="e.g. Pottery" required>
        </div>
        <div class="form-group">
          <label class="form-label">Description</label>
          <textarea name="description" class="form-control" rows="2" placeholder="Short description…"></textarea>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem">
          <div class="form-group">
            <label class="form-label">Icon (Font Awesome)</label>
            <select name="icon" class="form-control" id="addIconSel" onchange="previewIcon(this.value,'addIconPreview')">
              <?php foreach($icon_opts as $k=>$v): ?>
              <option value="<?= $k ?>"><?= $v ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group" style="display:flex;align-items:flex-end;padding-bottom:.25rem">
            <div style="width:48px;height:48px;border-radius:12px;background:linear-gradient(135deg,var(--primary),var(--primary-light));display:flex;align-items:center;justify-content:center" id="addIconPreview">
              <i class="fas fa-tag" style="color:white" id="addIconEl"></i>
            </div>
          </div>
        </div>
        <label style="display:flex;align-items:center;gap:.5rem;cursor:pointer;font-size:.88rem">
          <input type="checkbox" name="is_active" value="1" checked style="accent-color:var(--primary)"> Active (visible on shop)
        </label>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" onclick="closeModal('addCatModal')">Cancel</button>
        <button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i> Create Category</button>
      </div>
    </form>
  </div>
</div>

<!-- ── EDIT MODAL ── -->
<div class="modal-overlay" id="editCatModal">
  <div class="modal" style="max-width:460px">
    <div class="modal-header">
      <h2 class="modal-title"><i class="fas fa-edit" style="color:var(--info);margin-right:.4rem"></i>Edit Category</h2>
      <button class="modal-close" onclick="closeModal('editCatModal')"><i class="fas fa-times"></i></button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="action" value="edit">
        <input type="hidden" name="cid" id="ec_id">
        <div class="form-group">
          <label class="form-label">Category Name *</label>
          <input type="text" name="name" id="ec_name" class="form-control" required>
        </div>
        <div class="form-group">
          <label class="form-label">Description</label>
          <textarea name="description" id="ec_desc" class="form-control" rows="2"></textarea>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem">
          <div class="form-group">
            <label class="form-label">Icon</label>
            <select name="icon" id="ec_icon" class="form-control" onchange="previewIcon(this.value,'editIconPreview')">
              <?php foreach($icon_opts as $k=>$v): ?>
              <option value="<?= $k ?>"><?= $v ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group" style="display:flex;align-items:flex-end;padding-bottom:.25rem">
            <div style="width:48px;height:48px;border-radius:12px;background:linear-gradient(135deg,var(--primary),var(--primary-light));display:flex;align-items:center;justify-content:center" id="editIconPreview">
              <i class="fas fa-tag" style="color:white" id="editIconEl"></i>
            </div>
          </div>
        </div>
        <label style="display:flex;align-items:center;gap:.5rem;cursor:pointer;font-size:.88rem">
          <input type="checkbox" name="is_active" value="1" id="ec_active" style="accent-color:var(--primary)"> Active
        </label>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" onclick="closeModal('editCatModal')">Cancel</button>
        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Changes</button>
      </div>
    </form>
  </div>
</div>

<div id="sidebarOverlay" style="position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:850;display:none"
  onclick="document.getElementById('dashboardSidebar').classList.remove('open');this.style.display='none'"></div>

<script>
document.getElementById('sidebarOpenBtn')?.addEventListener('click',function(){
  document.getElementById('dashboardSidebar').classList.toggle('open');
  document.getElementById('sidebarOverlay').style.display =
    document.getElementById('dashboardSidebar').classList.contains('open') ? 'block' : 'none';
});

function closeModal(id){ document.getElementById(id).classList.remove('open'); }
function openAddModal(){ document.getElementById('addCatModal').classList.add('open'); }

function openEditModal(d){
  document.getElementById('ec_id').value    = d.id;
  document.getElementById('ec_name').value  = d.name;
  document.getElementById('ec_desc').value  = d.description || '';
  document.getElementById('ec_icon').value  = d.icon || 'fa-tag';
  document.getElementById('ec_active').checked = !!parseInt(d.is_active);
  previewIcon(d.icon || 'fa-tag', 'editIconPreview');
  document.getElementById('editCatModal').classList.add('open');
}

function previewIcon(icon, previewId){
  const el = document.querySelector('#'+previewId+' i');
  if (el) { el.className = 'fas '+icon+' '; el.style.color = 'white'; }
}
</script>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body>
</html>
