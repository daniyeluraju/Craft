<?php
require_once '../includes/auth.php';

// Filters
$category_id = intval($_GET['category'] ?? 0);
$min_price   = floatval($_GET['min_price'] ?? 0);
$max_price   = floatval($_GET['max_price'] ?? 99999);
$sort        = sanitize($_GET['sort'] ?? 'newest');
$search      = sanitize($_GET['search'] ?? '');
$page        = max(1, intval($_GET['page'] ?? 1));
$per_page    = 12;
$offset      = ($page - 1) * $per_page;

// Build query
$where  = ["p.status='approved'"];
$params = [];

if ($category_id) { $where[] = "p.category_id = ?"; $params[] = $category_id; }
if ($search)       { $where[] = "MATCH(p.name,p.description) AGAINST(? IN BOOLEAN MODE)"; $params[] = $search . '*'; }
if ($min_price > 0) { $where[] = "COALESCE(p.sale_price,p.price) >= ?"; $params[] = $min_price; }
if ($max_price < 99999) { $where[] = "COALESCE(p.sale_price,p.price) <= ?"; $params[] = $max_price; }

$where_clause = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$order_clause = match($sort) {
    'price_low'  => 'ORDER BY COALESCE(p.sale_price,p.price) ASC',
    'price_high' => 'ORDER BY COALESCE(p.sale_price,p.price) DESC',
    'rating'     => 'ORDER BY avg_r DESC',
    'popular'    => 'ORDER BY p.views DESC',
    default      => 'ORDER BY p.created_at DESC',
};

// Total count
$count_sql = "SELECT COUNT(*) as total FROM products p $where_clause";
$total_rows = db_fetch($count_sql, $params)['total'] ?? 0;
$total_pages = ceil($total_rows / $per_page);

// Products
$products_sql = "
    SELECT p.*, c.name as cat_name,
           COALESCE(p.sale_price, p.price) as effective_price,
           (SELECT AVG(r.rating) FROM reviews r WHERE r.product_id = p.id AND r.is_approved=1) as avg_r,
           (SELECT COUNT(*) FROM reviews r WHERE r.product_id = p.id AND r.is_approved=1) as review_count
    FROM products p
    JOIN categories c ON p.category_id = c.id
    $where_clause
    $order_clause
    LIMIT $per_page OFFSET $offset
";
$products = db_fetch_all($products_sql, $params);

$categories = db_fetch_all("SELECT * FROM categories WHERE is_active=1");
$active_cat = $category_id ? db_fetch("SELECT name FROM categories WHERE id=?", [$category_id]) : null;
$page_title = 'Shop – ' . ($active_cat ? $active_cat['name'] . ' | ' : '') . 'CraftStore';
?>
<?php include '../includes/navbar.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $page_title ?></title>
<meta name="description" content="Browse hundreds of handcrafted art, jewelry, home decor, and more on CraftStore.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/main.css">
</head>
<body class="page-body">

<!-- Shop Header -->
<div style="background:linear-gradient(135deg,var(--primary-dark),var(--primary));padding:3rem 0 2.5rem;margin-bottom:0">
    <div class="container">
        <h1 style="color:white;font-size:clamp(1.8rem,4vw,2.8rem);margin-bottom:.5rem">Shop All <?= $active_cat ? htmlspecialchars($active_cat['name']) : 'Products' ?></h1>
        <p style="color:rgba(255,255,255,0.75);font-size:1rem">Discover <?= $total_rows ?> handcrafted items from talented artisans</p>
        <nav style="margin-top:1rem;font-size:.83rem;color:rgba(255,255,255,0.6)">
            <a href="<?= SITE_URL ?>/public/index.php" style="color:rgba(255,255,255,0.7)">Home</a>
            <span style="margin:0 .5rem">/</span>
            <span style="color:white">Shop</span>
        </nav>
    </div>
</div>

<div class="container section-sm">
    <div class="shop-layout">
        <!-- ── Sidebar Filters ── -->
        <aside class="filter-sidebar">
            <form method="GET" id="filterForm">
                <?php if ($search): ?><input type="hidden" name="search" value="<?= htmlspecialchars($search) ?>"><?php endif; ?>
                <input type="hidden" name="sort" id="sortHidden" value="<?= htmlspecialchars($sort) ?>">

                <div class="filter-card">
                    <h3 class="filter-title"><i class="fas fa-th" style="color:var(--primary);margin-right:.4rem"></i>Categories</h3>
                    <div class="filter-option">
                        <input type="radio" name="category" id="cat_all" value="0" <?= !$category_id ? 'checked' : '' ?> onchange="document.getElementById('filterForm').submit()">
                        <label for="cat_all">All Categories</label>
                    </div>
                    <?php foreach ($categories as $cat): ?>
                    <div class="filter-option">
                        <input type="radio" name="category" id="cat_<?= $cat['id'] ?>" value="<?= $cat['id'] ?>" <?= $category_id == $cat['id'] ? 'checked' : '' ?> onchange="document.getElementById('filterForm').submit()">
                        <label for="cat_<?= $cat['id'] ?>"><?= htmlspecialchars($cat['name']) ?></label>
                    </div>
                    <?php endforeach; ?>
                </div>

                <div class="filter-card">
                    <h3 class="filter-title"><i class="fas fa-rupee-sign" style="color:var(--secondary);margin-right:.4rem"></i>Price Range</h3>
                    <div class="price-range">
                        <input type="range" id="maxPriceRange" min="0" max="10000" value="<?= min($max_price, 10000) ?>" step="100" oninput="document.getElementById('maxPriceDisplay').textContent='₹'+this.value; document.querySelector('[name=max_price]').value=this.value">
                        <div class="price-display">
                            <span>₹0</span>
                            <span id="maxPriceDisplay">₹<?= min($max_price < 99999 ? $max_price : 10000, 10000) ?></span>
                        </div>
                    </div>
                    <input type="hidden" name="min_price" value="0">
                    <input type="hidden" name="max_price" value="<?= $max_price < 99999 ? $max_price : 10000 ?>">
                    <button type="submit" class="btn btn-primary btn-sm w-full" style="margin-top:.75rem">Apply Filter</button>
                </div>

                <div class="filter-card">
                    <h3 class="filter-title"><i class="fas fa-star" style="color:var(--secondary);margin-right:.4rem"></i>Min. Rating</h3>
                    <?php foreach ([4,3,2,1] as $r): ?>
                    <div class="filter-option">
                        <input type="radio" name="min_rating" id="rating_<?= $r ?>" value="<?= $r ?>" onchange="document.getElementById('filterForm').submit()">
                        <label for="rating_<?= $r ?>">
                            <?php for($i=1;$i<=5;$i++): ?>
                            <i class="fas fa-star" style="color:<?= $i<=$r ? 'var(--secondary)' : 'var(--border)' ?>;font-size:.75rem"></i>
                            <?php endfor; ?> & up
                        </label>
                    </div>
                    <?php endforeach; ?>
                </div>

                <?php if ($category_id || $search || $min_price || $max_price < 99999): ?>
                <a href="<?= SITE_URL ?>/public/shop.php" class="btn btn-ghost btn-sm w-full">
                    <i class="fas fa-times"></i> Clear Filters
                </a>
                <?php endif; ?>
            </form>
        </aside>

        <!-- ── Products Area ── -->
        <div>
            <div class="shop-header">
                <p class="results-count">
                    Showing <strong><?= count($products) ?></strong> of <strong><?= $total_rows ?></strong> products
                    <?= $search ? 'for "<strong>' . htmlspecialchars($search) . '</strong>"' : '' ?>
                </p>
                <select class="sort-select" id="sortSelect" onchange="applySort(this.value)">
                    <option value="newest"     <?= $sort==='newest'     ? 'selected':'' ?>>Newest First</option>
                    <option value="price_low"  <?= $sort==='price_low'  ? 'selected':'' ?>>Price: Low to High</option>
                    <option value="price_high" <?= $sort==='price_high' ? 'selected':'' ?>>Price: High to Low</option>
                    <option value="rating"     <?= $sort==='rating'     ? 'selected':'' ?>>Top Rated</option>
                    <option value="popular"    <?= $sort==='popular'    ? 'selected':'' ?>>Most Popular</option>
                </select>
            </div>

            <?php if (empty($products)): ?>
            <div class="empty-state">
                <div class="empty-icon"><i class="fas fa-search"></i></div>
                <h3 class="empty-title">No products found</h3>
                <p class="empty-subtitle">Try adjusting your filters or search term</p>
                <a href="<?= SITE_URL ?>/public/shop.php" class="btn btn-primary">Browse All Products</a>
            </div>
            <?php else: ?>
            <div class="product-grid">
                <?php foreach ($products as $p):
                    $discount = $p['sale_price'] ? round((($p['price']-$p['sale_price'])/$p['price'])*100) : 0;
                    $display  = $p['sale_price'] ?? $p['price'];
                ?>
                <div class="product-card">
                    <div class="product-image">
                        <?php if (!empty($p['featured_image'])): ?>
                        <img src="<?= SITE_URL . '/assets/uploads' . $p['featured_image'] ?>" alt="<?= htmlspecialchars($p['name']) ?>" style="width:100%;height:100%;object-fit:cover;position:absolute;inset:0">
                        <?php else: ?>
                        <img src="<?= SITE_URL ?>/assets/img/default-product.svg" alt="Default Product" style="width:100%;height:100%;object-fit:cover;position:absolute;inset:0">
                        <?php endif; ?>
                        <div class="product-badges">
                            <?php if ($p['is_featured']): ?><span class="badge-pill badge-featured">Featured</span><?php endif; ?>
                            <?php if ($discount > 0): ?><span class="badge-pill badge-sale"><?= $discount ?>% OFF</span><?php endif; ?>
                            <?php if ($p['is_trending']): ?><span class="badge-pill badge-trending">Trending</span><?php endif; ?>
                        </div>
                        <div class="product-actions">
                            <button class="product-action-btn" onclick="toggleWishlist(<?= $p['id'] ?>, this)">
                                <i class="fas fa-heart"></i>
                            </button>
                            <a href="<?= SITE_URL ?>/public/product.php?id=<?= $p['id'] ?>" class="product-action-btn">
                                <i class="fas fa-eye"></i>
                            </a>
                        </div>
                    </div>
                    <div class="product-info">
                        <p class="product-category"><?= htmlspecialchars($p['cat_name']) ?></p>
                        <h3 class="product-name"><?= htmlspecialchars($p['name']) ?></h3>
                        <div class="product-rating">
                            <?= star_rating($p['avg_r'] ?? 0) ?>
                            <span class="rating-count">(<?= $p['review_count'] ?>)</span>
                        </div>
                        <div class="product-price">
                            <span class="price-current"><?= format_price($display) ?></span>
                            <?php if ($p['sale_price']): ?>
                            <span class="price-original"><?= format_price($p['price']) ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="product-footer">
                        <?php if (is_logged_in() && is_customer()): ?>
                        <button class="btn btn-primary btn-sm btn-add-cart" onclick="addToCart(<?= $p['id'] ?>)">
                            <i class="fas fa-cart-plus"></i> Add to Cart
                        </button>
                        <?php else: ?>
                        <a href="<?= SITE_URL ?>/public/product.php?id=<?= $p['id'] ?>" class="btn btn-primary btn-sm btn-add-cart">
                            <i class="fas fa-eye"></i> View
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php if ($page > 1): ?>
                <a href="?page=<?= $page-1 ?>&category=<?= $category_id ?>&sort=<?= $sort ?>&search=<?= urlencode($search) ?>" class="page-btn"><i class="fas fa-chevron-left"></i></a>
                <?php endif; ?>
                <?php for ($i = max(1, $page-2); $i <= min($total_pages, $page+2); $i++): ?>
                <a href="?page=<?= $i ?>&category=<?= $category_id ?>&sort=<?= $sort ?>&search=<?= urlencode($search) ?>" class="page-btn <?= $i==$page ? 'active' : '' ?>"><?= $i ?></a>
                <?php endfor; ?>
                <?php if ($page < $total_pages): ?>
                <a href="?page=<?= $page+1 ?>&category=<?= $category_id ?>&sort=<?= $sort ?>&search=<?= urlencode($search) ?>" class="page-btn"><i class="fas fa-chevron-right"></i></a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<footer class="footer">
    <div class="container">
        <div class="footer-bottom" style="border-top:none;padding-top:0">
            <p>© 2024 CraftStore. All rights reserved.</p>
            <div class="footer-bottom-links">
                <a href="<?= SITE_URL ?>/public/index.php">Home</a>
                <a href="<?= SITE_URL ?>/public/contact.php">Contact</a>
            </div>
        </div>
    </div>
</footer>

<script>
function applySort(val) {
    document.getElementById('sortHidden').value = val;
    document.getElementById('filterForm').submit();
}
</script>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body>
</html>
