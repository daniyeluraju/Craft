<?php
require_once '../includes/auth.php';

if (is_logged_in()) {
    header("Location: " . SITE_URL . "/" . get_role() . "/index.php");
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($email) || empty($password)) {
        $error = 'Please fill in all fields.';
    } else {
        $user = login_user($email, $password);
        if ($user) {
            $redirect = match($user['role_name']) {
                'admin'    => SITE_URL . '/admin/index.php',
                'seller'   => SITE_URL . '/seller/index.php',
                'customer' => SITE_URL . '/customer/index.php',
                default    => SITE_URL . '/public/index.php',
            };
            header("Location: $redirect");
            exit;
        } else {
            $error = 'Invalid email or password. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login – CraftStore</title>
<meta name="description" content="Login to CraftStore to shop handcrafted art, manage your store, or administer the platform.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/main.css">
</head>
<body>
<div class="auth-page" style="background: linear-gradient(rgba(10,10,15,0.75), rgba(10,10,15,0.75)), url('https://images.creativemarket.com/0.1.0/ps/7060886/1820/1213/m1/fpnw/wm1/jgem4t3x1dvdfy1iuhv0hrbmz09pobzey6i6kim6mef6jiribuujg6xo0ykpfcp2-.jpg?1569918428&s=2ad58ae0e186a81269a8c5890627971f') center/cover no-repeat; position:relative; min-height:100vh;">

    <div class="auth-card">
        <div class="auth-logo">
            <a href="<?= SITE_URL ?>/public/index.php">
                <div class="logo-icon" style="width:44px;height:44px;font-size:1.1rem;display:inline-flex;align-items:center;justify-content:center;background:linear-gradient(135deg,var(--primary),var(--primary-light));border-radius:12px;color:white;margin-right:.5rem"><i class="fas fa-palette"></i></div>
                <span style="color:white;font-size:1.4rem;font-weight:800">Craft<span style="color:var(--primary-light)">Store</span></span>
            </a>
        </div>
        <h1 class="auth-title">Welcome Back! 👋</h1>
        <p class="auth-subtitle">Sign in to continue your artistic journey</p>

        <?php if ($error): ?>
        <div style="background:rgba(239,68,68,0.12);border:1px solid rgba(239,68,68,0.3);border-radius:10px;padding:.9rem 1rem;margin-bottom:1.25rem;display:flex;align-items:center;gap:.6rem;color:#FCA5A5;font-size:.9rem">
            <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?>
        </div>
        <?php endif; ?>

        <form method="POST" id="loginForm">
            <div class="form-group">
                <label class="form-label" for="email">Email Address</label>
                <div style="position:relative">
                    <i class="fas fa-envelope" style="position:absolute;left:1rem;top:50%;transform:translateY(-50%);color:rgba(255,255,255,0.35)"></i>
                    <input type="email" name="email" id="email" class="form-control" placeholder="you@example.com" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" style="padding-left:2.6rem" required>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label" for="password">Password</label>
                <div style="position:relative">
                    <i class="fas fa-lock" style="position:absolute;left:1rem;top:50%;transform:translateY(-50%);color:rgba(255,255,255,0.35)"></i>
                    <input type="password" name="password" id="password" class="form-control" placeholder="••••••••" style="padding-left:2.6rem;padding-right:2.6rem" required>
                    <button type="button" id="togglePassword" style="position:absolute;right:1rem;top:50%;transform:translateY(-50%);background:none;color:rgba(255,255,255,0.35);border:none;cursor:pointer">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
            </div>
            <div style="display:flex;justify-content:flex-end;margin-bottom:1.25rem">
                <a href="#" style="font-size:.83rem;color:var(--primary-light)">Forgot password?</a>
            </div>
            <button type="submit" class="btn btn-primary w-full btn-lg" style="border-radius:12px">
                <i class="fas fa-sign-in-alt"></i> Sign In
            </button>
        </form>

        <div class="auth-divider"><span>OR DEMO LOGIN</span></div>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:.5rem;margin-bottom:1.25rem">
            <button onclick="fillDemo('admin@craftstore.com','password')" style="padding:.6rem .5rem;border-radius:10px;border:1px solid rgba(239,68,68,0.3);background:rgba(239,68,68,0.08);color:#FCA5A5;font-size:.78rem;font-weight:700;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:.3rem">
                <i class="fas fa-user-shield"></i> Admin
            </button>
            <button onclick="fillDemo('seller@craftstore.com','password')" style="padding:.6rem .5rem;border-radius:10px;border:1px solid rgba(245,158,11,0.3);background:rgba(245,158,11,0.08);color:#FCD34D;font-size:.78rem;font-weight:700;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:.3rem">
                <i class="fas fa-store"></i> Seller
            </button>
            <button onclick="fillDemo('customer@craftstore.com','password')" style="padding:.6rem .5rem;border-radius:10px;border:1px solid rgba(16,185,129,0.3);background:rgba(16,185,129,0.08);color:#6EE7B7;font-size:.78rem;font-weight:700;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:.3rem">
                <i class="fas fa-user"></i> Customer
            </button>
        </div>

        <p class="auth-footer">
            Don't have an account? <a href="<?= SITE_URL ?>/public/register.php">Create one free</a>
        </p>
    </div>
</div>

<script>
document.getElementById('togglePassword')?.addEventListener('click', function() {
    const pwd = document.getElementById('password');
    const icon = this.querySelector('i');
    if (pwd.type === 'password') { pwd.type = 'text'; icon.className = 'fas fa-eye-slash'; }
    else { pwd.type = 'password'; icon.className = 'fas fa-eye'; }
});
function fillDemo(email, pass) {
    document.getElementById('email').value = email;
    document.getElementById('password').value = pass;
    document.getElementById('loginForm').submit();
}
</script>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body>
</html>
