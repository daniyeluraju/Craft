<?php
require_once '../includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = sanitize($_POST['name'] ?? '');
    $email   = sanitize($_POST['email'] ?? '');
    $subject = sanitize($_POST['subject'] ?? '');
    $message = sanitize($_POST['message'] ?? '');
    
    if ($name && $email && $message) {
        db_query(
            "INSERT INTO contact_messages (name, email, subject, message) VALUES (?, ?, ?, ?)",
            [$name, $email, $subject, $message]
        );
        $success = true;
    }
}
?>
<?php include '../includes/navbar.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Contact Us – CraftStore</title>
<meta name="description" content="Get in touch with CraftStore for support, partnership inquiries, or any questions about handcrafted art.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/main.css">
</head>
<body class="page-body">

<!-- Header -->
<div style="background:linear-gradient(135deg,var(--primary-dark),var(--primary));padding:3.5rem 0 3rem">
    <div class="container" style="text-align:center">
        <h1 style="color:white;font-size:clamp(2rem,4vw,3rem);margin-bottom:.75rem">Get in Touch</h1>
        <p style="color:rgba(255,255,255,0.75);font-size:1rem;max-width:500px;margin:0 auto">We'd love to hear from you. Our team usually responds within 24 hours.</p>
    </div>
</div>

<div class="container section-sm">
    <div style="display:grid;grid-template-columns:1fr 1.5fr;gap:3rem;align-items:start">
        <!-- Contact Info -->
        <div>
            <h2 style="font-size:1.4rem;font-weight:800;margin-bottom:1.5rem">Contact Information</h2>
            <?php
            $info_items = [
                ['icon'=>'fa-envelope','color'=>'var(--primary)','title'=>'Email Us','value'=>'support@craftstore.com'],
                ['icon'=>'fa-phone','color'=>'var(--accent)','title'=>'Call Us','value'=>'+91 98765 43210'],
                ['icon'=>'fa-map-marker-alt','color'=>'var(--secondary)','title'=>'Visit Us','value'=>'Craft Hub, Connaught Place, New Delhi – 110001'],
                ['icon'=>'fa-clock','color'=>'var(--info)','title'=>'Working Hours','value'=>'Mon–Sat: 9am – 6pm IST'],
            ];
            foreach ($info_items as $item): ?>
            <div style="display:flex;align-items:flex-start;gap:1rem;margin-bottom:1.5rem">
                <div style="width:48px;height:48px;border-radius:12px;background:rgba(124,58,237,0.1);display:flex;align-items:center;justify-content:center;flex-shrink:0">
                    <i class="fas <?= $item['icon'] ?>" style="color:<?= $item['color'] ?>;font-size:1.1rem"></i>
                </div>
                <div>
                    <p style="font-size:.78rem;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:var(--text-muted);margin-bottom:.2rem"><?= $item['title'] ?></p>
                    <p style="font-weight:500;font-size:.92rem"><?= $item['value'] ?></p>
                </div>
            </div>
            <?php endforeach; ?>

            <!-- Map placeholder -->
            <div style="background:linear-gradient(135deg,rgba(124,58,237,0.1),rgba(245,158,11,0.05));border:1px solid var(--border);border-radius:var(--radius-md);height:220px;display:flex;flex-direction:column;align-items:center;justify-content:center;margin-top:1.5rem">
                <i class="fas fa-map-marked-alt" style="font-size:3rem;color:rgba(124,58,237,0.4);margin-bottom:1rem"></i>
                <p style="color:var(--text-muted);font-size:.88rem">New Delhi, India</p>
            </div>
        </div>

        <!-- Contact Form -->
        <div>
            <div style="background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);padding:2rem">
                <h2 style="font-size:1.3rem;font-weight:800;margin-bottom:1.5rem">Send us a Message</h2>
                
                <?php if (!empty($success)): ?>
                <div style="background:rgba(16,185,129,0.1);border:1px solid rgba(16,185,129,0.3);border-radius:10px;padding:1rem;margin-bottom:1.25rem;display:flex;align-items:center;gap:.6rem;color:var(--accent)">
                    <i class="fas fa-check-circle"></i>
                    <p>Thank you! Your message has been sent. We'll get back to you soon.</p>
                </div>
                <?php endif; ?>

                <form method="POST" id="contactForm">
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem">
                        <div class="form-group">
                            <label class="form-label" for="contact_name">Your Name *</label>
                            <input type="text" name="name" id="contact_name" class="form-control" placeholder="John Doe" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="contact_email">Email *</label>
                            <input type="email" name="email" id="contact_email" class="form-control" placeholder="you@example.com" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="contact_subject">Subject</label>
                        <select name="subject" id="contact_subject" class="form-control">
                            <option value="">Select a topic</option>
                            <option value="Order Issue">Order Issue</option>
                            <option value="Seller Inquiry">Seller Inquiry</option>
                            <option value="Product Query">Product Query</option>
                            <option value="Returns & Refunds">Returns & Refunds</option>
                            <option value="Partnership">Partnership</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="contact_message">Message *</label>
                        <textarea name="message" id="contact_message" class="form-control" rows="6" placeholder="Describe your query in detail..." required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary btn-lg w-full">
                        <i class="fas fa-paper-plane"></i> Send Message
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<footer class="footer">
    <div class="container"><div class="footer-bottom" style="border-top:none">
        <p>© 2024 CraftStore. All rights reserved.</p>
        <div class="footer-bottom-links"><a href="<?= SITE_URL ?>/public/index.php">Home</a><a href="<?= SITE_URL ?>/public/shop.php">Shop</a></div>
    </div></div>
</footer>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body></html>
