<?php
require_once '../includes/auth.php';
?>
<?php include '../includes/navbar.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>About Us – CraftStore</title>
<meta name="description" content="Learn about CraftStore's mission to promote Indian artisans and handcrafted products.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/main.css">
</head>
<body class="page-body">

<!-- Hero -->
<div style="background:linear-gradient(135deg,#1a0533,#2d1065,#0f1729);padding:5rem 0 4rem;position:relative;overflow:hidden">
    <div style="position:absolute;inset:0;background:radial-gradient(ellipse at 30% 50%,rgba(124,58,237,0.3),transparent 60%)"></div>
    <div class="container" style="text-align:center;position:relative;z-index:1">
        <div class="section-badge" style="display:inline-flex;margin-bottom:1.25rem"><i class="fas fa-heart"></i> Our Story</div>
        <h1 style="color:white;font-size:clamp(2.2rem,5vw,3.5rem);margin-bottom:1rem">Celebrating India's<br><span style="background:linear-gradient(135deg,#F59E0B,#9D5CF6);-webkit-background-clip:text;-webkit-text-fill-color:transparent">Artistic Heritage</span></h1>
        <p style="color:rgba(255,255,255,0.72);font-size:1.05rem;max-width:580px;margin:0 auto;line-height:1.7">CraftStore was born from a simple belief: every handmade piece tells a story, and every artisan deserves to be heard.</p>
    </div>
</div>

<!-- Mission -->
<section class="section">
    <div class="container">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:4rem;align-items:center">
            <div>
                <div class="section-badge"><i class="fas fa-bullseye"></i> Our Mission</div>
                <h2 style="margin:1rem 0 1.25rem">Empowering Artisans, Delighting Customers</h2>
                <p style="color:var(--text-muted);line-height:1.8;margin-bottom:1.25rem">We bridge the gap between India's talented craftsmen and art lovers across the country. By providing a modern digital marketplace, we help artisans earn a fair income while preserving centuries-old traditions.</p>
                <p style="color:var(--text-muted);line-height:1.8;margin-bottom:1.5rem">Every purchase on CraftStore directly supports a real artisan family, enabling them to continue their craft and pass it on to future generations.</p>
                <div style="display:flex;gap:1rem">
                    <a href="<?= SITE_URL ?>/public/shop.php" class="btn btn-primary"><i class="fas fa-shopping-bag"></i> Shop Now</a>
                    <a href="<?= SITE_URL ?>/public/register.php?role=seller" class="btn btn-outline"><i class="fas fa-store"></i> Join as Seller</a>
                </div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem">
                <?php
                $mission_stats = [
                    ['icon'=>'fa-users','color'=>'var(--primary)','bg'=>'rgba(124,58,237,0.1)','num'=>'500+','label'=>'Artisans Empowered'],
                    ['icon'=>'fa-shopping-bag','color'=>'var(--secondary)','bg'=>'rgba(245,158,11,0.1)','num'=>'10K+','label'=>'Products Sold'],
                    ['icon'=>'fa-smile','color'=>'var(--accent)','bg'=>'rgba(16,185,129,0.1)','num'=>'8K+','label'=>'Happy Customers'],
                    ['icon'=>'fa-map-marker-alt','color'=>'var(--info)','bg'=>'rgba(59,130,246,0.1)','num'=>'28+','label'=>'States Covered'],
                ];
                foreach ($mission_stats as $s): ?>
                <div style="background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-md);padding:1.75rem;text-align:center;transition:var(--transition)" onmouseover="this.style.transform='translateY(-4px)'" onmouseout="this.style.transform=''">
                    <div style="width:56px;height:56px;background:<?= $s['bg'] ?>;border-radius:14px;display:flex;align-items:center;justify-content:center;margin:0 auto 1rem">
                        <i class="fas <?= $s['icon'] ?>" style="color:<?= $s['color'] ?>;font-size:1.3rem"></i>
                    </div>
                    <p style="font-size:1.8rem;font-weight:900;margin-bottom:.25rem"><?= $s['num'] ?></p>
                    <p style="font-size:.82rem;color:var(--text-muted)"><?= $s['label'] ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>

<!-- Benefits -->
<section class="section" style="background:var(--surface)">
    <div class="container">
        <div class="section-header">
            <div class="section-badge"><i class="fas fa-gem"></i> Why Handmade</div>
            <h2 class="section-title">Benefits of <span>Handcrafted</span> Products</h2>
            <p class="section-subtitle">Handmade isn't just a product category—it's a commitment to quality, culture, and compassion.</p>
        </div>
        <div class="features-grid">
            <?php
            $benefits = [
                ['icon'=>'fa-fingerprint','title'=>'Truly Unique','desc'=>'Each handcrafted piece is one-of-a-kind. No two items are exactly alike, giving you something truly personal.'],
                ['icon'=>'fa-leaf','title'=>'Eco-Friendly','desc'=>'Handmade products use sustainable materials and processes, leaving a much smaller environmental footprint.'],
                ['icon'=>'fa-heart','title'=>'Made with Love','desc'=>'Artisans pour their heart into every creation. You can feel the passion and dedication in each piece.'],
                ['icon'=>'fa-award','title'=>'Superior Quality','desc'=>'Handcrafted items are made with careful attention to detail, resulting in superior quality that lasts longer.'],
                ['icon'=>'fa-hands-helping','title'=>'Support Communities','desc'=>'Your purchase sustains traditional crafts and supports artisan communities across India.'],
                ['icon'=>'fa-history','title'=>'Cultural Heritage','desc'=>'Own a piece of India\'s rich artistic heritage. Handcrafted items carry centuries of tradition and culture.'],
            ];
            foreach ($benefits as $b): ?>
            <div class="feature-card">
                <div class="feature-icon"><i class="fas <?= $b['icon'] ?>"></i></div>
                <h3 class="feature-title"><?= $b['title'] ?></h3>
                <p class="feature-desc"><?= $b['desc'] ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Team -->
<section class="section">
    <div class="container">
        <div class="section-header">
            <div class="section-badge"><i class="fas fa-users"></i> The Team</div>
            <h2 class="section-title">Meet the <span>Founders</span></h2>
        </div>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:1.75rem">
            <?php
            $team = [
                ['name'=>'Arjun Mehta','role'=>'CEO & Co-Founder','desc'=>'Passionate about connecting artisans with modern markets.','color'=>'var(--primary)'],
                ['name'=>'Priya Sharma','role'=>'Head of Artisan Relations','desc'=>'Works directly with craftsmen to onboard their creations.','color'=>'var(--secondary)'],
                ['name'=>'Rohan Gupta','role'=>'CTO','desc'=>'Builds the technology that powers every transaction.','color'=>'var(--accent)'],
            ];
            foreach ($team as $m): ?>
            <div style="text-align:center;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);padding:2rem 1.5rem;transition:var(--transition)" onmouseover="this.style.transform='translateY(-6px)';this.style.boxShadow='var(--shadow-lg)'" onmouseout="this.style.transform='';this.style.boxShadow=''">
                <div style="width:80px;height:80px;border-radius:50%;background:linear-gradient(135deg,<?= $m['color'] ?>,rgba(124,58,237,0.3));display:flex;align-items:center;justify-content:center;margin:0 auto 1.25rem;font-size:1.8rem;font-weight:900;color:white">
                    <?= strtoupper(substr($m['name'],0,1)) ?>
                </div>
                <h3 style="font-size:1.05rem;font-weight:800;margin-bottom:.3rem"><?= $m['name'] ?></h3>
                <p style="font-size:.78rem;font-weight:700;color:<?= $m['color'] ?>;margin-bottom:.6rem;text-transform:uppercase;letter-spacing:.05em"><?= $m['role'] ?></p>
                <p style="font-size:.85rem;color:var(--text-muted);line-height:1.5"><?= $m['desc'] ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<footer class="footer">
    <div class="container"><div class="footer-bottom" style="border-top:none">
        <p>© 2024 CraftStore. All rights reserved.</p>
        <div class="footer-bottom-links"><a href="<?= SITE_URL ?>/public/index.php">Home</a><a href="<?= SITE_URL ?>/public/shop.php">Shop</a></div>
    </div></div>
</footer>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body></html>
