<?php
require_once '../includes/auth.php';

$id = intval($_GET['id'] ?? 0);
if (!$id) { header("Location: shop.php"); exit; }

$product = db_fetch("
    SELECT p.*, c.name as cat_name, c.slug as cat_slug,
           u.name as seller_name, sp.shop_name, sp.rating as seller_rating
    FROM products p
    JOIN categories c ON p.category_id = c.id
    JOIN users u ON p.seller_id = u.id
    LEFT JOIN seller_profiles sp ON sp.user_id = u.id
    WHERE p.id = ? AND p.status = 'approved'
", [$id]);

if (!$product) { header("Location: shop.php"); exit; }

// Update views
db_query("UPDATE products SET views = views+1 WHERE id=?", [$id]);

$reviews    = db_fetch_all("SELECT r.*, u.name as reviewer_name FROM reviews r JOIN users u ON r.user_id=u.id WHERE r.product_id=? AND r.is_approved=1 ORDER BY r.created_at DESC", [$id]);
$avg_rating = get_product_rating($id);
$related    = db_fetch_all("SELECT p.*, c.name as cat_name FROM products p JOIN categories c ON p.category_id=c.id WHERE p.category_id=? AND p.id!=? AND p.status='approved' ORDER BY RAND() LIMIT 4", [$product['category_id'], $id]);

$in_wishlist = false;
if (is_logged_in()) {
    $wl = db_fetch("SELECT id FROM wishlist WHERE user_id=? AND product_id=?", [get_user_id(), $id]);
    $in_wishlist = !empty($wl);
}

$display_price = $product['sale_price'] ?? $product['price'];
$discount = $product['sale_price'] ? round((($product['price']-$product['sale_price'])/$product['price'])*100) : 0;
?>
<?php include '../includes/navbar.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($product['name']) ?> – CraftStore</title>
<meta name="description" content="<?= htmlspecialchars(substr($product['description'], 0, 160)) ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/main.css">
</head>
<body class="page-body">

<div class="container section-sm">
    <!-- Breadcrumb -->
    <nav style="font-size:.83rem;color:var(--text-muted);margin-bottom:1.5rem">
        <a href="<?= SITE_URL ?>/public/index.php" style="color:var(--text-muted)">Home</a>
        <span style="margin:0 .4rem">/</span>
        <a href="<?= SITE_URL ?>/public/shop.php" style="color:var(--text-muted)">Shop</a>
        <span style="margin:0 .4rem">/</span>
        <a href="<?= SITE_URL ?>/public/shop.php?category=<?= $product['category_id'] ?>" style="color:var(--text-muted)"><?= htmlspecialchars($product['cat_name']) ?></a>
        <span style="margin:0 .4rem">/</span>
        <span style="color:var(--text)"><?= htmlspecialchars(substr($product['name'],0,40)) ?></span>
    </nav>

    <!-- Product Detail -->
    <div class="product-detail-layout" style="margin-bottom:3rem">
        <!-- Gallery -->
        <div class="product-gallery">
            <?php 
                $images = !empty($product['images']) ? json_decode($product['images'], true) : [];
                $main_img = !empty($images) ? SITE_URL . '/assets/uploads' . $images[0] : '';
            ?>
            <div class="gallery-main">
                <?php if ($main_img): ?>
                <img id="mainGalleryImage" src="<?= $main_img ?>" alt="<?= htmlspecialchars($product['name']) ?>" style="width:100%;height:100%;object-fit:cover;border-radius:var(--radius-lg);">
                <?php else: ?>
                <img src="<?= SITE_URL ?>/assets/img/default-product.svg" alt="Default Product" style="width:100%;height:100%;object-fit:cover;border-radius:var(--radius-lg);">
                <?php endif; ?>
            </div>
            
            <div class="gallery-thumbs">
                <?php if (!empty($images)): foreach ($images as $idx => $img_path): 
                    $full_img = SITE_URL . '/assets/uploads' . $img_path;
                ?>
                <div class="gallery-thumb <?= $idx === 0 ? 'active' : '' ?>" onclick="switchGalleryImage(this, '<?= $full_img ?>')">
                    <img src="<?= $full_img ?>" alt="Thumbnail" style="width:100%;height:100%;object-fit:cover;border-radius:calc(var(--radius-md) - 2px);">
                </div>
                <?php endforeach; else: ?>
                    <?php for ($t = 0; $t < 4; $t++): ?>
                    <div class="gallery-thumb <?= $t===0 ? 'active' : '' ?>">
                        <img src="<?= SITE_URL ?>/assets/img/default-product.svg" alt="Thumbnail Placeholder" style="width:100%;height:100%;object-fit:cover;border-radius:calc(var(--radius-md) - 2px);">
                    </div>
                    <?php endfor; ?>
                <?php endif; ?>
            </div>
            <script>
            function switchGalleryImage(el, src) {
                document.getElementById('mainGalleryImage').src = src;
                document.querySelectorAll('.gallery-thumb').forEach(t => t.classList.remove('active'));
                el.classList.add('active');
            }
            </script>
        </div>

        <!-- Info -->
        <div class="product-detail-info">
            <p class="product-detail-category"><?= htmlspecialchars($product['cat_name']) ?></p>
            <h1 class="product-detail-title"><?= htmlspecialchars($product['name']) ?></h1>

            <!-- Rating -->
            <div style="display:flex;align-items:center;gap:.75rem;margin-bottom:.75rem">
                <?= star_rating($avg_rating['avg_rating'] ?? 0) ?>
                <span style="font-size:.88rem;color:var(--text-muted)">(<?= $avg_rating['total'] ?> reviews)</span>
                <span style="font-size:.83rem;color:var(--text-muted)">|</span>
                <span style="font-size:.83rem;color:var(--accent)"><i class="fas fa-eye"></i> <?= number_format($product['views']) ?> views</span>
            </div>

            <!-- Price -->
            <div class="product-detail-price">
                <span class="detail-price-current"><?= format_price($display_price) ?></span>
                <?php if ($product['sale_price']): ?>
                <span class="detail-price-original"><?= format_price($product['price']) ?></span>
                <span class="detail-discount"><?= $discount ?>% OFF</span>
                <?php endif; ?>
            </div>

            <!-- Stock -->
            <div style="display:flex;align-items:center;gap:.5rem;margin-bottom:1.5rem">
                <?php if ($product['stock'] > 0): ?>
                <span style="color:var(--accent);font-weight:700;font-size:.88rem"><i class="fas fa-check-circle"></i> In Stock</span>
                <span style="color:var(--text-muted);font-size:.82rem">(<?= $product['stock'] ?> available)</span>
                <?php else: ?>
                <span style="color:var(--danger);font-weight:700;font-size:.88rem"><i class="fas fa-times-circle"></i> Out of Stock</span>
                <?php endif; ?>
            </div>

            <!-- Description -->
            <div style="background:var(--surface-2);border-radius:12px;padding:1.25rem;margin-bottom:1.5rem">
                <h3 style="font-size:.9rem;font-weight:700;margin-bottom:.6rem">Description</h3>
                <p style="font-size:.9rem;color:var(--text-muted);line-height:1.7"><?= nl2br(htmlspecialchars($product['description'])) ?></p>
            </div>

            <!-- Actions -->
            <?php if ($product['stock'] > 0): ?>
            <div class="product-detail-actions">
                <div class="quantity-selector">
                    <button class="qty-btn" data-action="decrease">−</button>
                    <input type="number" class="qty-input" id="qtyInput" value="1" min="1" max="<?= $product['stock'] ?>">
                    <button class="qty-btn" data-action="increase">+</button>
                </div>
                <?php if (is_logged_in() && is_customer()): ?>
                <button class="btn btn-primary" onclick="addToCart(<?= $id ?>, parseInt(document.getElementById('qtyInput').value))">
                    <i class="fas fa-cart-plus"></i> Add to Cart
                </button>
                <a href="<?= SITE_URL ?>/customer/checkout.php?buy_now=<?= $id ?>" class="btn btn-secondary">
                    <i class="fas fa-bolt"></i> Buy Now
                </a>
                <?php else: ?>
                <a href="<?= SITE_URL ?>/public/login.php" class="btn btn-primary">
                    <i class="fas fa-sign-in-alt"></i> Login to Buy
                </a>
                <?php endif; ?>
                <button class="btn btn-ghost btn-icon" onclick="toggleWishlist(<?= $id ?>, this)" title="Add to Wishlist">
                    <i class="fas fa-heart <?= $in_wishlist ? 'text-danger' : '' ?>"></i>
                </button>
            </div>
            <?php endif; ?>

            <!-- Seller Info -->
            <div style="background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:1rem;margin-top:1rem">
                <div style="display:flex;align-items:center;gap:.75rem">
                    <div style="width:44px;height:44px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--secondary));display:flex;align-items:center;justify-content:center;color:white;font-weight:800;font-size:1rem">
                        <?= strtoupper(substr($product['seller_name'],0,1)) ?>
                    </div>
                    <div>
                        <strong style="font-size:.9rem"><?= htmlspecialchars($product['shop_name'] ?? $product['seller_name']) ?></strong>
                        <span style="display:block;font-size:.75rem;color:var(--text-muted)">Verified Artisan</span>
                    </div>
                    <div style="margin-left:auto;text-align:right">
                        <span style="font-size:.8rem;color:var(--secondary);font-weight:700"><i class="fas fa-star"></i> <?= number_format($product['seller_rating'] ?? 4.8, 1) ?></span>
                    </div>
                </div>
            </div>

            <!-- Delivery info -->
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem;margin-top:1rem">
                <div style="display:flex;align-items:center;gap:.6rem;padding:.75rem;background:var(--surface-2);border-radius:10px;font-size:.82rem">
                    <i class="fas fa-shipping-fast" style="color:var(--primary);width:16px"></i>
                    <div><strong>Free Delivery</strong><span style="display:block;color:var(--text-muted)">Orders above ₹500</span></div>
                </div>
                <div style="display:flex;align-items:center;gap:.6rem;padding:.75rem;background:var(--surface-2);border-radius:10px;font-size:.82rem">
                    <i class="fas fa-shield-alt" style="color:var(--accent);width:16px"></i>
                    <div><strong>Easy Returns</strong><span style="display:block;color:var(--text-muted)">7-day return policy</span></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Reviews -->
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:2rem;margin-bottom:3rem">
        <div>
            <h2 style="font-size:1.3rem;font-weight:800;margin-bottom:1.5rem">Customer Reviews</h2>
            <!-- Rating summary -->
            <div style="background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-md);padding:1.5rem;margin-bottom:1.25rem;display:flex;align-items:center;gap:2rem">
                <div style="text-align:center">
                    <span style="font-size:3rem;font-weight:900;color:var(--primary)"><?= number_format($avg_rating['avg_rating'] ?? 0, 1) ?></span>
                    <div><?= star_rating($avg_rating['avg_rating'] ?? 0) ?></div>
                    <span style="font-size:.75rem;color:var(--text-muted)"><?= $avg_rating['total'] ?> reviews</span>
                </div>
                <div style="flex:1">
                    <?php for($r=5;$r>=1;$r--):
                        $rcount = count(array_filter($reviews, fn($rv) => $rv['rating'] == $r));
                        $pct = $avg_rating['total'] > 0 ? ($rcount / $avg_rating['total']) * 100 : 0;
                    ?>
                    <div style="display:flex;align-items:center;gap:.5rem;margin-bottom:.3rem">
                        <span style="font-size:.75rem;width:10px"><?= $r ?></span>
                        <i class="fas fa-star" style="color:var(--secondary);font-size:.7rem"></i>
                        <div style="flex:1;height:6px;background:var(--surface-2);border-radius:3px;overflow:hidden">
                            <div style="width:<?= $pct ?>%;height:100%;background:var(--secondary);border-radius:3px"></div>
                        </div>
                        <span style="font-size:.73rem;color:var(--text-muted);width:20px"><?= $rcount ?></span>
                    </div>
                    <?php endfor; ?>
                </div>
            </div>

            <?php if (empty($reviews)): ?>
            <div class="empty-state" style="padding:2rem">
                <div class="empty-icon"><i class="fas fa-star"></i></div>
                <p class="empty-subtitle">No reviews yet. Be the first to review!</p>
            </div>
            <?php else: ?>
            <?php foreach ($reviews as $rev): ?>
            <div class="review-card">
                <div class="review-header">
                    <div class="reviewer">
                        <div class="reviewer-avatar"><?= strtoupper(substr($rev['reviewer_name'],0,1)) ?></div>
                        <div>
                            <p class="reviewer-name"><?= htmlspecialchars($rev['reviewer_name']) ?></p>
                            <p class="reviewer-date"><?= date('d M Y', strtotime($rev['created_at'])) ?></p>
                        </div>
                    </div>
                    <?= star_rating($rev['rating']) ?>
                </div>
                <?php if ($rev['title']): ?><p class="review-title"><?= htmlspecialchars($rev['title']) ?></p><?php endif; ?>
                <p class="review-text"><?= htmlspecialchars($rev['comment']) ?></p>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- Write Review -->
        <div>
            <h2 style="font-size:1.3rem;font-weight:800;margin-bottom:1.5rem">Write a Review</h2>
            <?php if (is_logged_in() && is_customer()): ?>
            <div style="background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-md);padding:1.5rem">
                <form id="reviewForm">
                    <input type="hidden" name="product_id" value="<?= $id ?>">
                    <div class="form-group">
                        <label class="form-label">Your Rating</label>
                        <div id="starRatingInput" style="display:flex;gap:.5rem;margin-bottom:.25rem">
                            <input type="hidden" name="rating" id="ratingVal" value="0">
                            <?php for($i=1;$i<=5;$i++): ?>
                            <i class="fas fa-star star-input" data-value="<?= $i ?>" style="font-size:1.5rem;color:var(--border);cursor:pointer;transition:var(--transition)" onclick="setRating(<?= $i ?>)"></i>
                            <?php endfor; ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="rev_title">Review Title</label>
                        <input type="text" name="title" id="rev_title" class="form-control" placeholder="Summarize your experience">
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="rev_comment">Your Review</label>
                        <textarea name="comment" id="rev_comment" class="form-control" placeholder="Share your experience..." rows="5" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary w-full"><i class="fas fa-paper-plane"></i> Submit Review</button>
                </form>
            </div>
            <?php else: ?>
            <div style="background:var(--surface-2);border-radius:var(--radius-md);padding:2rem;text-align:center">
                <i class="fas fa-lock" style="font-size:2rem;color:var(--text-muted);margin-bottom:1rem"></i>
                <p style="color:var(--text-muted);margin-bottom:1rem">Please login to write a review</p>
                <a href="<?= SITE_URL ?>/public/login.php" class="btn btn-primary"><i class="fas fa-sign-in-alt"></i> Login to Review</a>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Related Products -->
    <?php if (!empty($related)): ?>
    <h2 style="font-size:1.4rem;font-weight:800;margin-bottom:1.5rem">You Might Also Like</h2>
    <div class="product-grid">
        <?php foreach ($related as $rp): $rd = $rp['sale_price'] ?? $rp['price']; ?>
        <div class="product-card">
            <div class="product-image">
                <?php if (!empty($rp['featured_image'])): ?>
                <img src="<?= SITE_URL . '/assets/uploads' . $rp['featured_image'] ?>" alt="<?= htmlspecialchars($rp['name']) ?>" style="width:100%;height:100%;object-fit:cover;position:absolute;inset:0">
                <?php else: ?>
                <img src="<?= SITE_URL ?>/assets/img/default-product.svg" alt="Default Product" style="width:100%;height:100%;object-fit:cover;position:absolute;inset:0">
                <?php endif; ?>
            </div>
            <div class="product-info">
                <p class="product-category"><?= htmlspecialchars($rp['cat_name']) ?></p>
                <h3 class="product-name"><?= htmlspecialchars($rp['name']) ?></h3>
                <div class="product-price"><span class="price-current"><?= format_price($rd) ?></span></div>
            </div>
            <div class="product-footer">
                <a href="<?= SITE_URL ?>/public/product.php?id=<?= $rp['id'] ?>" class="btn btn-primary btn-sm btn-add-cart">View Product</a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

<script>
function setRating(val) {
    document.getElementById('ratingVal').value = val;
    document.querySelectorAll('.star-input').forEach(s => {
        s.style.color = parseInt(s.dataset.value) <= val ? 'var(--secondary)' : 'var(--border)';
    });
}

document.getElementById('reviewForm')?.addEventListener('submit', async function(e) {
    e.preventDefault();
    const rating = parseInt(document.getElementById('ratingVal').value);
    if (rating < 1) { showToast('Please select a rating', 'error'); return; }
    const data = Object.fromEntries(new FormData(this));
    try {
        const res = await fetch('/Craft/includes/ajax/review.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        const json = await res.json();
        if (json.success) {
            showToast('Review submitted! Thank you.', 'success');
            this.reset();
            setRating(0);
        } else { showToast(json.message || 'Failed to submit', 'error'); }
    } catch { showToast('Error submitting review', 'error'); }
});
</script>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body>
</html>
