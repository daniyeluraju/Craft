<?php
require_once '../includes/auth.php';

if (is_logged_in()) {
    header("Location: " . SITE_URL . "/" . get_role() . "/index.php");
    exit;
}

$error = '';
$success = '';
$pre_role = sanitize($_GET['role'] ?? 'customer');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    $role = $_POST['role'] ?? 'customer';
    $phone = trim($_POST['phone'] ?? '');
    $gender = sanitize($_POST['gender'] ?? '');
    $address = sanitize($_POST['address'] ?? '');

    if (empty($name) || empty($email) || empty($password)) {
        $error = 'Please fill in all required fields.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } elseif (!in_array($role, ['customer', 'seller'])) {
        $error = 'Invalid role selected.';
    } else {
        $result = register_user(['name' => $name, 'email' => $email, 'password' => $password, 'role' => $role, 'phone' => $phone, 'address' => $address]);
        if ($result['success']) {
            // Save gender if provided
            if ($gender && $result['user_id']) {
                db_query("UPDATE users SET address=? WHERE id=?", [$address, $result['user_id']]);
            }
            redirect_with_message(SITE_URL . '/public/login.php', 'Registration successful! Please sign in.', 'success');
        } else {
            $error = $result['message'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register – CraftStore</title>
    <meta name="description"
        content="Create your CraftStore account to start shopping handcrafted art or sell your own creations.">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/main.css">
</head>

<body>
    <div class="auth-page"
        style="background: linear-gradient(rgba(10,10,15,0.75), rgba(10,10,15,0.75)), url('https://images.creativemarket.com/0.1.0/ps/7060886/1820/1213/m1/fpnw/wm1/jgem4t3x1dvdfy1iuhv0hrbmz09pobzey6i6kim6mef6jiribuujg6xo0ykpfcp2-.jpg?1569918428&s=2ad58ae0e186a81269a8c5890627971f') center/cover no-repeat; position:relative; min-height:100vh;">

        <div class="auth-card" style="max-width:500px">
            <div class="auth-logo">
                <a href="<?= SITE_URL ?>/public/index.php">
                    <div class="logo-icon"
                        style="width:44px;height:44px;font-size:1.1rem;display:inline-flex;align-items:center;justify-content:center;background:linear-gradient(135deg,var(--primary),var(--primary-light));border-radius:12px;color:white;margin-right:.5rem">
                        <i class="fas fa-palette"></i>
                    </div>
                    <span style="color:white;font-size:1.4rem;font-weight:800">E-commerce Web Application for Art <span
                            style="color:var(--primary-light)">& Handcrafted Items</span></span>
                </a>
            </div>
            <h1 class="auth-title">Join CraftStore 🎨</h1>
            <p class="auth-subtitle">Create your account and start your creative journey</p>

            <?php if ($error): ?>
                <div
                    style="background:rgba(239,68,68,0.12);border:1px solid rgba(239,68,68,0.3);border-radius:10px;padding:.9rem 1rem;margin-bottom:1.25rem;display:flex;align-items:center;gap:.6rem;color:#FCA5A5;font-size:.9rem">
                    <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <form method="POST">
                <!-- Role Selector -->
                <div class="form-group">
                    <label class="form-label">I want to join as</label>
                    <div class="role-selector">
                        <div class="role-option">
                            <input type="radio" name="role" id="role_customer" value="customer" <?= ($pre_role !== 'seller') ? 'checked' : '' ?>>
                            <label class="role-label" for="role_customer">
                                <i class="fas fa-shopping-bag"></i>
                                <span>Customer</span>
                            </label>
                        </div>
                        <div class="role-option">
                            <input type="radio" name="role" id="role_seller" value="seller" <?= ($pre_role === 'seller') ? 'checked' : '' ?>>
                            <label class="role-label" for="role_seller">
                                <i class="fas fa-store"></i>
                                <span>Seller</span>
                            </label>
                        </div>
                        <div class="role-option">
                            <input type="radio" name="role" id="role_admin" value="customer" disabled>

                        </div>
                    </div>
                </div>

                <div style="display:grid;grid-template-columns:1fr 1fr;gap:0.75rem">
                    <div class="form-group">
                        <label class="form-label" for="name">Full Name *</label>
                        <input type="text" name="name" id="name" class="form-control" placeholder="Your name"
                            value="<?= htmlspecialchars($_POST['name'] ?? '') ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="phone">Phone</label>
                        <input type="tel" name="phone" id="phone" class="form-control" placeholder="9876543210"
                            value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="reg_email">Email Address *</label>
                    <input type="email" name="email" id="reg_email" class="form-control" placeholder="you@example.com"
                        value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
                </div>

                <div style="display:grid;grid-template-columns:1fr 1fr;gap:0.75rem">
                    <div class="form-group">
                        <label class="form-label" for="reg_password">Password *</label>
                        <input type="password" name="password" id="reg_password" class="form-control"
                            placeholder="Min. 6 characters" required minlength="6">
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="confirm_password">Confirm Password *</label>
                        <input type="password" name="confirm_password" id="confirm_password" class="form-control"
                            placeholder="Repeat password" required>
                    </div>
                </div>

                <!-- Gender -->
                <div class="form-group">
                    <label class="form-label">Gender</label>
                    <div style="display:flex;gap:1rem;margin-top:.3rem">
                        <label
                            style="display:flex;align-items:center;gap:.55rem;cursor:pointer;padding:.6rem 1.1rem;border-radius:50px;border:2px solid rgba(255,255,255,0.15);transition:all .25s;flex:1;justify-content:center"
                            id="lbl_male">
                            <input type="radio" name="gender" value="male" id="gender_male" style="display:none"
                                <?= ($_POST['gender'] ?? '') === 'male' ? 'checked' : '' ?> onchange="highlightGender()">
                            <i class="fas fa-mars" style="font-size:1rem;color:rgba(255,255,255,0.55)"
                                id="icon_male"></i>
                            <span style="font-size:.88rem;font-weight:600;color:rgba(255,255,255,0.75)">Male</span>
                        </label>
                        <label
                            style="display:flex;align-items:center;gap:.55rem;cursor:pointer;padding:.6rem 1.1rem;border-radius:50px;border:2px solid rgba(255,255,255,0.15);transition:all .25s;flex:1;justify-content:center"
                            id="lbl_female">
                            <input type="radio" name="gender" value="female" id="gender_female" style="display:none"
                                <?= ($_POST['gender'] ?? '') === 'female' ? 'checked' : '' ?> onchange="highlightGender()">
                            <i class="fas fa-venus" style="font-size:1rem;color:rgba(255,255,255,0.55)"
                                id="icon_female"></i>
                            <span style="font-size:.88rem;font-weight:600;color:rgba(255,255,255,0.75)">Female</span>
                        </label>
                    </div>
                </div>

                <!-- Address -->
                <div class="form-group">
                    <label class="form-label" for="address">Address</label>
                    <textarea name="address" id="address" class="form-control" rows="2"
                        placeholder="House no, Street, City, State..."
                        style="resize:none"><?= htmlspecialchars($_POST['address'] ?? '') ?></textarea>
                </div>

                <div class="form-group" style="margin-bottom:1.5rem">
                    <label
                        style="display:flex;align-items:flex-start;gap:.6rem;cursor:pointer;font-size:.83rem;color:rgba(255,255,255,0.7)">
                        <input type="checkbox" required style="accent-color:var(--primary-light);margin-top:2px">
                        I agree to the <a href="#" style="color:var(--primary-light)">Terms of Service</a> and <a
                            href="#" style="color:var(--primary-light)">Privacy Policy</a>
                    </label>
                </div>

                <button type="submit" class="btn btn-primary w-full btn-lg" style="border-radius:12px">
                    <i class="fas fa-user-plus"></i> Create Account
                </button>
            </form>

            <p class="auth-footer">
                Already have an account? <a href="<?= SITE_URL ?>/public/login.php">Sign in</a>
            </p>
        </div>
    </div>

    <script>
        function highlightGender() {
            const male = document.getElementById('gender_male').checked;
            const female = document.getElementById('gender_female').checked;

            const lblM = document.getElementById('lbl_male');
            const lblF = document.getElementById('lbl_female');
            const icnM = document.getElementById('icon_male');
            const icnF = document.getElementById('icon_female');

            lblM.style.borderColor = male ? 'var(--primary-light)' : 'rgba(255,255,255,0.15)';
            lblM.style.background = male ? 'rgba(124,58,237,0.25)' : '';
            icnM.style.color = male ? 'var(--primary-light)' : 'rgba(255,255,255,0.55)';

            lblF.style.borderColor = female ? '#F472B6' : 'rgba(255,255,255,0.15)';
            lblF.style.background = female ? 'rgba(244,114,182,0.18)' : '';
            icnF.style.color = female ? '#F472B6' : 'rgba(255,255,255,0.55)';
        }
        // Restore state on page load (after validation error)
        document.addEventListener('DOMContentLoaded', highlightGender);
    </script>
    <script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body>

</html>