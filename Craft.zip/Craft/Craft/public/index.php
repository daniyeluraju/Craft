<?php
require_once '../includes/auth.php';

// Fetch featured products
$featured = db_fetch_all("SELECT p.*, c.name as cat_name FROM products p JOIN categories c ON p.category_id = c.id WHERE p.status='approved' AND p.is_featured=1 ORDER BY p.created_at DESC LIMIT 8");
$trending = db_fetch_all("SELECT p.*, c.name as cat_name FROM products p JOIN categories c ON p.category_id = c.id WHERE p.status='approved' AND p.is_trending=1 LIMIT 8");
$categories = db_fetch_all("SELECT c.*, COUNT(p.id) as product_count FROM categories c LEFT JOIN products p ON p.category_id=c.id AND p.status='approved' GROUP BY c.id ORDER BY c.name LIMIT 6");
$hero_stats = [
    'artists' => db_fetch("SELECT COUNT(*) as c FROM users WHERE role_id=2")['c'] ?? 0,
    'products' => db_fetch("SELECT COUNT(*) as c FROM products WHERE status='approved'")['c'] ?? 0,
    'orders' => db_fetch("SELECT COUNT(*) as c FROM orders")['c'] ?? 0,
];

$page_title = 'E-commerce Web Application for Art & Handcrafted Items';
$page_desc = 'Discover and shop unique handcrafted art, jewelry, home decor, and more from talented Indian artisans.';
?>
<?php include '../includes/navbar.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?></title>
    <meta name="description" content="<?= $page_desc ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/main.css">
</head>

<body>

    <!-- ══════════════ HERO ══════════════ -->
    <section class="hero"
        style="background: url('https://mir-s3-cdn-cf.behance.net/projects/404/0b055a228765763.Y3JvcCwxMzgwLDEwODAsMjAxLDA.png') center/cover no-repeat; min-height: 60vh; position: relative;">
        <div style="position:absolute;inset:0;background:rgba(0,0,0,0.2);"></div>
    </section>


    <!-- ══════════════ CATEGORIES ══════════════ -->
    <section class="section">
        <div class="container">
            <div class="section-header">
                <div class="section-badge"><i class="fas fa-th"></i> Browse Categories</div>
                <h2 class="section-title">Shop by <span>Category</span></h2>
                <p class="section-subtitle">Explore our curated collection of handcrafted art across different
                    categories</p>
            </div>
            <div class="categories-grid">
                <?php
                $cat_icons = ['paintings' => 'fa-paint-brush', 'handicrafts' => 'fa-hands', 'jewelry' => 'fa-gem', 'home-decor' => 'fa-home', 'pottery' => 'fa-vial', 'textiles' => 'fa-scroll'];
                $cat_grads = [
                    'paintings' => 'linear-gradient(135deg,#7C3AED,#9D5CF6)',
                    'handicrafts' => 'linear-gradient(135deg,#F59E0B,#FBBF24)',
                    'jewelry' => 'linear-gradient(135deg,#10B981,#34D399)',
                    'home-decor' => 'linear-gradient(135deg,#EF4444,#F87171)',
                    'pottery' => 'linear-gradient(135deg,#3B82F6,#60A5FA)',
                    'textiles' => 'linear-gradient(135deg,#8B5CF6,#C084FC)',
                ];
                foreach ($categories as $cat):
                    $icon = $cat_icons[$cat['slug']] ?? 'fa-star';
                    $grad = $cat_grads[$cat['slug']] ?? 'linear-gradient(135deg,#7C3AED,#5B21B6)';
                    ?>
                    <a href="<?= SITE_URL ?>/public/shop.php?category=<?= $cat['id'] ?>" class="category-card"
                        style="background:<?= $grad ?>">
                        <div class="category-icon"><i class="fas <?= $icon ?>"></i></div>
                        <div class="category-info">
                            <p class="category-title"><?= htmlspecialchars($cat['name']) ?></p>
                            <p class="category-count"><?= $cat['product_count'] ?> Products</p>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ══════════════ FEATURED PRODUCTS ══════════════ -->
    <section class="section" style="background:var(--surface)">
        <div class="container">
            <div class="section-header">
                <div class="section-badge"><i class="fas fa-star"></i> Handpicked</div>
                <h2 class="section-title">Featured <span>Products</span></h2>
                <p class="section-subtitle">Our curated selection of premium handcrafted items you'll love</p>
            </div>
            <div class="product-grid">
                <?php foreach ($featured as $p):
                    $rating = get_product_rating($p['id']);
                    $discount = $p['sale_price'] ? round((($p['price'] - $p['sale_price']) / $p['price']) * 100) : 0;
                    $display_price = $p['sale_price'] ?? $p['price'];
                    ?>
                    <div class="product-card">
                        <div class="product-image">
                            <?php if (!empty($p['featured_image'])): ?>
                                <img src="<?= SITE_URL . '/assets/uploads' . $p['featured_image'] ?>"
                                    alt="<?= htmlspecialchars($p['name']) ?>"
                                    style="width:100%;height:100%;object-fit:cover;position:absolute;inset:0">
                            <?php else: ?>
                                <img src="<?= SITE_URL ?>/assets/img/default-product.svg" alt="Default"
                                    style="width:100%;height:100%;object-fit:cover;position:absolute;inset:0">
                            <?php endif; ?>
                            <div class="product-badges">
                                <?php if ($p['is_featured']): ?><span
                                        class="badge-pill badge-featured">Featured</span><?php endif; ?>
                                <?php if ($discount > 0): ?><span class="badge-pill badge-sale"><?= $discount ?>%
                                        OFF</span><?php endif; ?>
                            </div>
                            <div class="product-actions">
                                <button class="product-action-btn" onclick="toggleWishlist(<?= $p['id'] ?>, this)"
                                    title="Wishlist">
                                    <i class="fas fa-heart"></i>
                                </button>
                                <a href="<?= SITE_URL ?>/public/product.php?id=<?= $p['id'] ?>" class="product-action-btn"
                                    title="View">
                                    <i class="fas fa-eye"></i>
                                </a>
                            </div>
                        </div>
                        <div class="product-info">
                            <p class="product-category"><?= htmlspecialchars($p['cat_name']) ?></p>
                            <h3 class="product-name"><?= htmlspecialchars($p['name']) ?></h3>
                            <div class="product-rating">
                                <?= star_rating($rating['avg_rating'] ?? 4.5) ?>
                                <span class="rating-count">(<?= $rating['total'] ?? 0 ?>)</span>
                            </div>
                            <div class="product-price">
                                <span class="price-current"><?= format_price($display_price) ?></span>
                                <?php if ($p['sale_price']): ?>
                                    <span class="price-original"><?= format_price($p['price']) ?></span>
                                    <span class="price-discount"><?= $discount ?>% off</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="product-footer">
                            <?php if (is_logged_in() && is_customer()): ?>
                                <button class="btn btn-primary btn-sm btn-add-cart" onclick="addToCart(<?= $p['id'] ?>)">
                                    <i class="fas fa-cart-plus"></i> Add to Cart
                                </button>
                            <?php else: ?>
                                <a href="<?= SITE_URL ?>/public/product.php?id=<?= $p['id'] ?>"
                                    class="btn btn-primary btn-sm btn-add-cart">
                                    <i class="fas fa-eye"></i> View Product
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <div style="text-align:center;margin-top:2.5rem">
                <a href="<?= SITE_URL ?>/public/shop.php" class="btn btn-outline btn-lg">
                    View All Products <i class="fas fa-arrow-right"></i>
                </a>
            </div>
        </div>
    </section>

    <!-- ══════════════ TRENDING ══════════════ -->
    <section class="section">
        <div class="container">
            <div class="section-header">
                <div class="section-badge"><i class="fas fa-fire"></i> Hot Right Now</div>
                <h2 class="section-title">Trending <span>This Week</span></h2>
                <p class="section-subtitle">Most loved products by our community of art enthusiasts</p>
            </div>
            <div class="product-grid">
                <?php foreach ($trending as $p):
                    $rating = get_product_rating($p['id']);
                    $display_price = $p['sale_price'] ?? $p['price'];
                    ?>
                    <div class="product-card">
                        <div class="product-image">
                            <?php if (!empty($p['featured_image'])): ?>
                                <img src="<?= SITE_URL . '/assets/uploads' . $p['featured_image'] ?>"
                                    alt="<?= htmlspecialchars($p['name']) ?>"
                                    style="width:100%;height:100%;object-fit:cover;position:absolute;inset:0">
                            <?php else: ?>
                                <img src="<?= SITE_URL ?>/assets/img/default-product.svg" alt="Default"
                                    style="width:100%;height:100%;object-fit:cover;position:absolute;inset:0">
                            <?php endif; ?>
                            <div class="product-badges">
                                <span class="badge-pill badge-trending">🔥 Trending</span>
                            </div>
                            <div class="product-actions">
                                <button class="product-action-btn" onclick="toggleWishlist(<?= $p['id'] ?>, this)"
                                    title="Wishlist">
                                    <i class="fas fa-heart"></i>
                                </button>
                                <a href="<?= SITE_URL ?>/public/product.php?id=<?= $p['id'] ?>" class="product-action-btn"
                                    title="View">
                                    <i class="fas fa-eye"></i>
                                </a>
                            </div>
                        </div>
                        <div class="product-info">
                            <p class="product-category"><?= htmlspecialchars($p['cat_name'] ?? '') ?></p>
                            <h3 class="product-name"><?= htmlspecialchars($p['name']) ?></h3>
                            <div class="product-rating">
                                <?= star_rating($rating['avg_rating'] ?? 4) ?>
                                <span class="rating-count">(<?= $rating['total'] ?? 0 ?>)</span>
                            </div>
                            <div class="product-price">
                                <span class="price-current"><?= format_price($display_price) ?></span>
                                <?php if ($p['sale_price']): ?>
                                    <span class="price-original"><?= format_price($p['price']) ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="product-footer">
                            <a href="<?= SITE_URL ?>/public/product.php?id=<?= $p['id'] ?>"
                                class="btn btn-primary btn-sm btn-add-cart">
                                <i class="fas fa-eye"></i> View Details
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ══════════════ CTA BANNER ══════════════ -->
    <section class="section-sm" style="background:linear-gradient(135deg,var(--primary-dark),var(--primary))">
        <div class="container" style="text-align:center">
            <h2 style="color:white;font-size:clamp(1.6rem,3vw,2.4rem);margin-bottom:1rem">Are You an Artisan?</h2>
            <p style="color:rgba(255,255,255,0.8);max-width:520px;margin:0 auto 2rem;font-size:1rem;line-height:1.7">
                Join thousands of sellers on CraftStore. List your handmade products, reach a wider audience, and grow
                your business.
            </p>
            <a href="<?= SITE_URL ?>/public/register.php?role=seller" class="btn btn-secondary btn-xl">
                <i class="fas fa-store"></i> Start Selling Today
            </a>
        </div>
    </section>

    <!-- ══════════════ FOOTER ══════════════ -->
    <footer class="footer">
        <div class="container">
            <div class="footer-grid">
                <div>
                    <div class="footer-logo">
                        <div class="logo-icon"><i class="fas fa-palette"></i></div>
                        <span class="logo-text" style="font-size:1.1rem;white-space:normal;line-height:1.2;">E-commerce
                            Web Application for Art & Handcrafted Items</span>
                    </div>
                    <p class="footer-about">India's premier marketplace for handcrafted art and traditional crafts.
                        Connecting artisans with art lovers since 2024.</p>
                    <div class="footer-socials">
                        <a href="#" class="social-link"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
                <div>
                    <h4 class="footer-heading">Quick Links</h4>
                    <ul class="footer-links">
                        <li><a href="<?= SITE_URL ?>/public/index.php">Home</a></li>
                        <li><a href="<?= SITE_URL ?>/public/shop.php">Shop</a></li>
                        <li><a href="<?= SITE_URL ?>/public/about.php">About Us</a></li>
                        <li><a href="<?= SITE_URL ?>/public/contact.php">Contact</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="footer-heading">Categories</h4>
                    <ul class="footer-links">
                        <li><a href="<?= SITE_URL ?>/public/shop.php?category=1">Paintings</a></li>
                        <li><a href="<?= SITE_URL ?>/public/shop.php?category=2">Handicrafts</a></li>
                        <li><a href="<?= SITE_URL ?>/public/shop.php?category=3">Jewelry</a></li>
                        <li><a href="<?= SITE_URL ?>/public/shop.php?category=4">Home Decor</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="footer-heading">Support</h4>
                    <ul class="footer-links">
                        <li><a href="#">FAQ</a></li>
                        <li><a href="#">Shipping Policy</a></li>
                        <li><a href="#">Return Policy</a></li>
                        <li><a href="<?= SITE_URL ?>/public/contact.php">Help Center</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>© 2024 E-commerce Web Application for Art & Handcrafted Items.</p>
                <div class="footer-bottom-links">
                    <a href="#">Privacy Policy</a>
                    <a href="#">Terms of Service</a>
                </div>
            </div>
        </div>
    </footer>

    <script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body>

</html>