<?php
require_once '../includes/auth.php';
require_role('customer');

$uid = get_user_id();
$cart_items = db_fetch_all("
    SELECT c.id, c.quantity, p.id as product_id, p.name, COALESCE(p.sale_price,p.price) as price, p.stock
    FROM cart c JOIN products p ON p.id=c.product_id WHERE c.user_id=?
", [$uid]);

if (empty($cart_items)) {
    redirect_with_message('/Craft/customer/cart.php', 'Your cart is empty!', 'error');
}

$subtotal = array_sum(array_map(fn($i) => $i['price'] * $i['quantity'], $cart_items));
$shipping = $subtotal >= 500 ? 0 : 49;
$total    = $subtotal + $shipping;

$user = get_current_user_data();

// Handle order placement
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = sanitize($_POST['ship_name'] ?? '');
    $phone    = sanitize($_POST['ship_phone'] ?? '');
    $address  = sanitize($_POST['ship_address'] ?? '');
    $city     = sanitize($_POST['ship_city'] ?? '');
    $state    = sanitize($_POST['ship_state'] ?? '');
    $pincode  = sanitize($_POST['ship_pincode'] ?? '');
    $method   = sanitize($_POST['payment_method'] ?? 'cod');
    
    if (!$name || !$phone || !$address || !$city || !$pincode) {
        $error = 'Please fill in all shipping details.';
    } else {
        $order_no = generate_order_number();
        
        db_query(
            "INSERT INTO orders (user_id,order_number,total_amount,shipping_amount,final_amount,status,payment_method,payment_status,shipping_name,shipping_phone,shipping_address,shipping_city,shipping_state,shipping_pincode)
             VALUES (?,?,?,?,?,'pending',?,?,?,?,?,?,?,?)",
            [$uid,$order_no,$subtotal,$shipping,$total,$method,$method==='cod'?'pending':'paid',$name,$phone,$address,$city,$state,$pincode]
        );
        $order_id = db_last_id();
        
        // Insert order items
        foreach ($cart_items as $ci) {
            $seller = db_fetch("SELECT seller_id FROM products WHERE id=?", [$ci['product_id']]);
            db_query(
                "INSERT INTO order_items (order_id,product_id,seller_id,product_name,product_price,quantity,subtotal) VALUES (?,?,?,?,?,?,?)",
                [$order_id,$ci['product_id'],$seller['seller_id'],$ci['name'],$ci['price'],$ci['quantity'],$ci['price']*$ci['quantity']]
            );
            db_query("UPDATE products SET stock=stock-? WHERE id=?", [$ci['quantity'],$ci['product_id']]);
        }
        
        // Clear cart
        db_query("DELETE FROM cart WHERE user_id=?", [$uid]);
        
        // Notification
        db_query("INSERT INTO notifications (user_id,title,message,type) VALUES (?,?,?,'order')",
            [$uid,"Order Placed! 🎉","Your order #$order_no has been placed successfully."]);
        
        redirect_with_message('/Craft/customer/orders.php', "Order #$order_no placed successfully! 🎉", 'success');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Checkout – CraftStore</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/main.css">
</head>
<body>
<div class="dashboard-layout">
    <?php include '../includes/sidebar.php'; ?>
    <div class="dashboard-main">
        <div class="dashboard-topbar">
            <div style="display:flex;align-items:center;gap:1rem">
                <button class="btn btn-ghost btn-icon" id="sidebarOpenBtn"><i class="fas fa-bars"></i></button>
                <h1 class="topbar-title">Checkout</h1>
            </div>
            <div class="topbar-actions">
                <a href="/Craft/customer/cart.php" class="btn btn-ghost btn-sm"><i class="fas fa-arrow-left"></i> Back to Cart</a>
                <button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button>
            </div>
        </div>
        <div class="dashboard-content">
            <?php if (!empty($error)): ?>
            <div style="background:rgba(239,68,68,0.08);border:1px solid rgba(239,68,68,0.25);border-radius:10px;padding:1rem;margin-bottom:1.25rem;color:var(--danger);display:flex;gap:.5rem"><i class="fas fa-exclamation-circle"></i> <?= $error ?></div>
            <?php endif; ?>

            <!-- Progress Steps -->
            <div class="step-indicator" style="margin-bottom:2rem">
                <div class="step completed"><div class="step-circle"><i class="fas fa-check"></i></div><span class="step-label">Cart</span></div>
                <div class="step active"><div class="step-circle">2</div><span class="step-label">Checkout</span></div>
                <div class="step"><div class="step-circle">3</div><span class="step-label">Confirm</span></div>
            </div>

            <form method="POST" id="checkoutForm">
                <div class="checkout-layout">
                    <!-- Left -->
                    <div>
                        <!-- Shipping -->
                        <div style="background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);padding:1.75rem;margin-bottom:1.25rem">
                            <h3 style="font-size:1rem;font-weight:700;margin-bottom:1.25rem;padding-bottom:.75rem;border-bottom:1px solid var(--border)"><i class="fas fa-map-marker-alt" style="color:var(--primary);margin-right:.4rem"></i>Shipping Address</h3>
                            <div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem">
                                <div class="form-group">
                                    <label class="form-label">Full Name *</label>
                                    <input type="text" name="ship_name" class="form-control" value="<?= htmlspecialchars($user['name'] ?? '') ?>" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Phone *</label>
                                    <input type="tel" name="ship_phone" class="form-control" value="<?= htmlspecialchars($user['phone'] ?? '') ?>" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Address *</label>
                                <textarea name="ship_address" class="form-control" rows="2" placeholder="House no, Street, Area..." required><?= htmlspecialchars($user['address'] ?? '') ?></textarea>
                            </div>
                            <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:.75rem">
                                <div class="form-group">
                                    <label class="form-label">City *</label>
                                    <input type="text" name="ship_city" class="form-control" placeholder="City" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">State *</label>
                                    <select name="ship_state" class="form-control" required>
                                        <option value="">State</option>
                                        <?php foreach(['Andhra Pradesh','Assam','Bihar','Delhi','Goa','Gujarat','Haryana','Karnataka','Kerala','Madhya Pradesh','Maharashtra','Odisha','Punjab','Rajasthan','Tamil Nadu','Telangana','Uttar Pradesh','West Bengal'] as $st): ?>
                                        <option><?= $st ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Pincode *</label>
                                    <input type="text" name="ship_pincode" class="form-control" placeholder="110001" maxlength="6" pattern="[0-9]{6}" required>
                                </div>
                            </div>
                        </div>

                        <!-- Payment -->
                        <div style="background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);padding:1.75rem">
                            <h3 style="font-size:1rem;font-weight:700;margin-bottom:1.25rem;padding-bottom:.75rem;border-bottom:1px solid var(--border)"><i class="fas fa-credit-card" style="color:var(--accent);margin-right:.4rem"></i>Payment Method</h3>
                            <div class="payment-methods">
                                <?php
                                $payment_opts = [
                                    ['value'=>'cod','icon'=>'fa-money-bill-wave','label'=>'Cash on Delivery','desc'=>'Pay when delivered'],
                                    ['value'=>'upi','icon'=>'fa-qrcode','label'=>'UPI Payment','desc'=>'GPay, PhonePe, Paytm'],
                                    ['value'=>'card','icon'=>'fa-credit-card','label'=>'Credit/Debit Card','desc'=>'Visa, Mastercard, RuPay'],
                                    ['value'=>'netbanking','icon'=>'fa-university','label'=>'Net Banking','desc'=>'All major banks'],
                                ];
                                foreach($payment_opts as $po): ?>
                                <div class="payment-method">
                                    <input type="radio" name="payment_method" id="pay_<?= $po['value'] ?>" value="<?= $po['value'] ?>" <?= $po['value']==='cod' ? 'checked' : '' ?>>
                                    <label class="payment-label" for="pay_<?= $po['value'] ?>">
                                        <div class="pay-icon"><i class="fas <?= $po['icon'] ?>" style="color:var(--primary)"></i></div>
                                        <div>
                                            <strong><?= $po['label'] ?></strong>
                                            <span><?= $po['desc'] ?></span>
                                        </div>
                                    </label>
                                </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- UPI simulation -->
                            <div id="upiFields" style="display:none;margin-top:.75rem">
                                <div class="form-group">
                                    <label class="form-label">UPI ID</label>
                                    <input type="text" class="form-control" placeholder="yourname@paytm" id="upiId">
                                </div>
                            </div>
                            <!-- Card simulation -->
                            <div id="cardFields" style="display:none;margin-top:.75rem">
                                <div class="form-group">
                                    <label class="form-label">Card Number</label>
                                    <input type="text" class="form-control" placeholder="1234 5678 9012 3456" maxlength="19" id="cardNum" oninput="formatCard(this)">
                                </div>
                                <div style="display:grid;grid-template-columns:2fr 1fr;gap:.75rem">
                                    <div class="form-group">
                                        <label class="form-label">Expiry</label>
                                        <input type="text" class="form-control" placeholder="MM/YY" maxlength="5">
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">CVV</label>
                                        <input type="text" class="form-control" placeholder="123" maxlength="3">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Right: Summary -->
                    <div>
                        <div class="order-summary">
                            <h3 style="font-weight:800;margin-bottom:1.25rem">Order Summary</h3>
                            <?php foreach ($cart_items as $ci): ?>
                            <div style="display:flex;justify-content:space-between;padding:.5rem 0;font-size:.85rem;border-bottom:1px solid var(--border)">
                                <span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding-right:.5rem"><?= htmlspecialchars($ci['name']) ?> <span style="color:var(--text-muted)">×<?= $ci['quantity'] ?></span></span>
                                <span style="font-weight:700;flex-shrink:0">₹<?= number_format($ci['price'] * $ci['quantity']) ?></span>
                            </div>
                            <?php endforeach; ?>
                            <div class="summary-row"><span>Subtotal</span><span>₹<?= number_format($subtotal) ?></span></div>
                            <div class="summary-row"><span>Shipping</span><span style="color:<?= $shipping===0 ? 'var(--accent)' : '' ?>"><?= $shipping===0 ? 'FREE' : "₹$shipping" ?></span></div>
                            <div class="summary-row total"><span>Total</span><span style="color:var(--primary)">₹<?= number_format($total) ?></span></div>
                            <button type="submit" id="placeOrderBtn" class="btn btn-primary btn-lg w-full" style="margin-top:1.25rem">
                                <i class="fas fa-check-circle"></i> Place Order
                            </button>
                            <p style="font-size:.75rem;color:var(--text-muted);text-align:center;margin-top:.75rem">
                                <i class="fas fa-lock"></i> Your payment is secured with 256-bit SSL
                            </p>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<div id="sidebarOverlay" style="position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:850;display:none" onclick="document.getElementById('dashboardSidebar').classList.remove('open');this.style.display='none'"></div>
<script>
document.getElementById('sidebarOpenBtn')?.addEventListener('click', function() {
    document.getElementById('dashboardSidebar').classList.toggle('open');
    document.getElementById('sidebarOverlay').style.display = document.getElementById('dashboardSidebar').classList.contains('open') ? 'block' : 'none';
});

document.querySelectorAll('[name="payment_method"]').forEach(radio => {
    radio.addEventListener('change', function() {
        document.getElementById('upiFields').style.display = this.value === 'upi' ? 'block' : 'none';
        document.getElementById('cardFields').style.display = this.value === 'card' ? 'block' : 'none';
    });
});

function formatCard(input) {
    let v = input.value.replace(/\D/g, '').substring(0, 16);
    input.value = v.replace(/(.{4})/g, '$1 ').trim();
}

document.getElementById('checkoutForm')?.addEventListener('submit', function(e) {
    const btn = document.getElementById('placeOrderBtn');
    btn.innerHTML = '<div class="spinner" style="width:20px;height:20px;border-width:2px;margin-right:.5rem"></div> Processing...';
    btn.disabled = true;
});
</script>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body></html>
