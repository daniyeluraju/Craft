<?php
require_once '../includes/auth.php';
require_role('customer');
$uid = get_user_id();

$orders = db_fetch_all("
    SELECT o.*, COUNT(oi.id) as item_count
    FROM orders o
    LEFT JOIN order_items oi ON oi.order_id=o.id
    WHERE o.user_id=?
    GROUP BY o.id
    ORDER BY o.created_at DESC
", [$uid]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Orders – CraftStore</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/main.css">
</head>
<body>
<div class="dashboard-layout">
    <?php include '../includes/sidebar.php'; ?>
    <div class="dashboard-main">
        <div class="dashboard-topbar">
            <div style="display:flex;align-items:center;gap:1rem">
                <button class="btn btn-ghost btn-icon" id="sidebarOpenBtn"><i class="fas fa-bars"></i></button>
                <h1 class="topbar-title">My Orders</h1>
            </div>
            <div class="topbar-actions"><button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button></div>
        </div>
        <div class="dashboard-content">
            <?php $flash = get_flash_message(); if ($flash): ?>
            <div style="background:rgba(16,185,129,0.08);border:1px solid rgba(16,185,129,0.25);border-radius:10px;padding:1rem;margin-bottom:1.25rem;color:var(--accent);display:flex;align-items:center;gap:.5rem"><i class="fas fa-check-circle"></i> <?= $flash['message'] ?></div>
            <?php endif; ?>

            <?php if (empty($orders)): ?>
            <div class="empty-state">
                <div class="empty-icon"><i class="fas fa-box-open"></i></div>
                <h3 class="empty-title">No Orders Yet</h3>
                <p class="empty-subtitle">Once you place an order, it will appear here</p>
                <a href="<?= SITE_URL ?>/public/shop.php" class="btn btn-primary btn-lg"><i class="fas fa-shopping-bag"></i> Start Shopping</a>
            </div>
            <?php else: ?>
            <div style="display:flex;flex-direction:column;gap:1rem">
            <?php foreach ($orders as $o):
                $items = db_fetch_all("SELECT oi.*, p.name as product_name FROM order_items oi JOIN products p ON p.id=oi.product_id WHERE oi.order_id=?", [$o['id']]);
                $status_steps = ['pending'=>1,'confirmed'=>2,'processing'=>2,'shipped'=>3,'delivered'=>4,'cancelled'=>0];
                $step = $status_steps[$o['status']] ?? 0;
            ?>
            <div style="background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);overflow:hidden">
                <!-- Order Header -->
                <div style="padding:1.25rem 1.5rem;background:var(--surface-2);display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:.75rem">
                    <div>
                        <span style="font-weight:800;color:var(--primary)"><?= $o['order_number'] ?></span>
                        <span style="color:var(--text-muted);font-size:.8rem;margin-left:.75rem"><?= date('d M Y, h:i A', strtotime($o['created_at'])) ?></span>
                    </div>
                    <div style="display:flex;align-items:center;gap:1rem">
                        <span style="font-size:.85rem;font-weight:600"><?= $o['item_count'] ?> item<?= $o['item_count']!=1?'s':'' ?></span>
                        <span style="font-weight:800;color:var(--primary);font-size:1.05rem">₹<?= number_format($o['final_amount']) ?></span>
                        <span class="status-badge status-<?= $o['status'] ?>"><?= ucfirst($o['status']) ?></span>
                    </div>
                </div>

                <!-- Order items list -->
                <div style="padding:1.25rem 1.5rem">
                    <?php foreach ($items as $item): ?>
                    <div style="display:flex;align-items:center;gap:.75rem;padding:.6rem 0;border-bottom:1px solid var(--border)">
                        <div style="width:40px;height:40px;background:rgba(124,58,237,0.08);border-radius:10px;display:flex;align-items:center;justify-content:center;flex-shrink:0">
                            <i class="fas fa-palette" style="color:var(--primary);font-size:.85rem"></i>
                        </div>
                        <div style="flex:1">
                            <p style="font-size:.88rem;font-weight:600"><?= htmlspecialchars($item['product_name']) ?></p>
                            <p style="font-size:.75rem;color:var(--text-muted)">Qty: <?= $item['quantity'] ?> × ₹<?= number_format($item['product_price']) ?></p>
                        </div>
                        <strong style="color:var(--primary)">₹<?= number_format($item['subtotal']) ?></strong>
                    </div>
                    <?php endforeach; ?>
                </div>

                <!-- Tracking progress (for non-cancelled) -->
                <?php if ($o['status'] !== 'cancelled'): ?>
                <div style="padding:1rem 1.5rem;border-top:1px solid var(--border)">
                    <div style="display:flex;align-items:center;justify-content:space-between;position:relative">
                        <div style="position:absolute;left:16px;right:16px;top:16px;height:2px;background:var(--border)"></div>
                        <div style="position:absolute;left:16px;top:16px;height:2px;background:var(--accent);width:<?= min(100, ($step - 1) / 3 * 100) ?>%;transition:width 1s"></div>
                        <?php foreach([['Ordered','fa-check'],['Confirmed','fa-box'],['Shipped','fa-truck'],['Delivered','fa-home']] as $i => [$label,$icon]): ?>
                        <div style="display:flex;flex-direction:column;align-items:center;gap:.25rem;position:relative;z-index:1">
                            <div style="width:32px;height:32px;border-radius:50%;<?= $i+1<=$step ? 'background:var(--accent);color:white;' : 'background:var(--surface-2);color:var(--text-muted);border:2px solid var(--border);' ?>display:flex;align-items:center;justify-content:center;font-size:.75rem">
                                <i class="fas <?= $icon ?>"></i>
                            </div>
                            <span style="font-size:.7rem;color:<?= $i+1<=$step ? 'var(--accent)' : 'var(--text-muted)' ?>;font-weight:<?= $i+1<=$step ? '700' : '400' ?>;white-space:nowrap"><?= $label ?></span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Shipping info -->
                <div style="padding:1rem 1.5rem;background:var(--surface-2);border-top:1px solid var(--border);display:flex;justify-content:space-between;font-size:.82rem;color:var(--text-muted);flex-wrap:wrap;gap:.5rem">
                    <span><i class="fas fa-map-marker-alt" style="color:var(--primary)"></i> <?= htmlspecialchars($o['shipping_city']) ?>, <?= htmlspecialchars($o['shipping_state']) ?></span>
                    <span><i class="fas fa-credit-card" style="color:var(--secondary)"></i> <?= strtoupper($o['payment_method']) ?> – <?= ucfirst($o['payment_status']) ?></span>
                </div>
            </div>
            <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<div id="sidebarOverlay" style="position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:850;display:none" onclick="document.getElementById('dashboardSidebar').classList.remove('open');this.style.display='none'"></div>
<script>document.getElementById('sidebarOpenBtn')?.addEventListener('click', function() { document.getElementById('dashboardSidebar').classList.toggle('open'); document.getElementById('sidebarOverlay').style.display = document.getElementById('dashboardSidebar').classList.contains('open') ? 'block' : 'none'; });</script>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body></html>
