<?php
require_once '../includes/auth.php';
require_role('customer');

$uid = get_user_id();
$cart_items = db_fetch_all("
    SELECT c.id, c.quantity, p.id as product_id, p.name, p.description,
           COALESCE(p.sale_price, p.price) as price, p.price as original_price,
           p.sale_price, p.stock, cat.name as cat_name
    FROM cart c
    JOIN products p ON p.id = c.product_id
    JOIN categories cat ON cat.id = p.category_id
    WHERE c.user_id = ?
    ORDER BY c.created_at DESC
", [$uid]);

$subtotal = array_sum(array_map(fn($item) => $item['price'] * $item['quantity'], $cart_items));
$shipping = $subtotal > 500 ? 0 : 49;
$total    = $subtotal + $shipping;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Cart – CraftStore</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/main.css">
</head>
<body>
<div class="dashboard-layout">
    <?php include '../includes/sidebar.php'; ?>
    <div class="dashboard-main">
        <div class="dashboard-topbar">
            <div style="display:flex;align-items:center;gap:1rem">
                <button class="btn btn-ghost btn-icon" id="sidebarOpenBtn"><i class="fas fa-bars"></i></button>
                <h1 class="topbar-title">Shopping Cart</h1>
            </div>
            <div class="topbar-actions">
                <a href="<?= SITE_URL ?>/public/shop.php" class="btn btn-ghost btn-sm"><i class="fas fa-arrow-left"></i> Continue Shopping</a>
                <button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button>
            </div>
        </div>
        <div class="dashboard-content">
            <?php if (empty($cart_items)): ?>
            <div class="empty-state">
                <div class="empty-icon"><i class="fas fa-shopping-cart"></i></div>
                <h3 class="empty-title">Your Cart is Empty</h3>
                <p class="empty-subtitle">Looks like you haven't added anything yet. Start exploring!</p>
                <a href="<?= SITE_URL ?>/public/shop.php" class="btn btn-primary btn-lg"><i class="fas fa-shopping-bag"></i> Explore Products</a>
            </div>
            <?php else: ?>
            <div class="cart-layout">
                <!-- Items -->
                <div>
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem">
                        <h2 style="font-size:1.1rem;font-weight:700"><?= count($cart_items) ?> Items in Cart</h2>
                        <button onclick="clearCart()" class="btn btn-ghost btn-sm" style="color:var(--danger)"><i class="fas fa-trash"></i> Clear Cart</button>
                    </div>
                    <?php foreach ($cart_items as $item): ?>
                    <div class="cart-item" id="cart-item-<?= $item['id'] ?>">
                        <div style="width:90px;height:90px;border-radius:12px;background:rgba(124,58,237,0.08);display:flex;align-items:center;justify-content:center;flex-shrink:0">
                            <i class="fas fa-palette" style="font-size:2rem;color:rgba(124,58,237,0.35)"></i>
                        </div>
                        <div class="cart-item-info">
                            <h3 class="cart-item-name"><?= htmlspecialchars($item['name']) ?></h3>
                            <p class="cart-item-cat"><?= htmlspecialchars($item['cat_name']) ?></p>
                            <?php if ($item['sale_price'] && $item['sale_price'] < $item['original_price']): ?>
                            <p style="font-size:.75rem;color:var(--accent);font-weight:600">
                                <?= round((($item['original_price']-$item['sale_price'])/$item['original_price'])*100) ?>% off applied
                            </p>
                            <?php endif; ?>
                            <div class="cart-item-footer">
                                <span class="cart-price">₹<?= number_format($item['price']) ?></span>
                                <div style="display:flex;align-items:center;gap:.75rem">
                                    <div class="quantity-selector" style="scale:.9">
                                        <button class="qty-btn" data-action="decrease" onclick="changeQty(<?= $item['id'] ?>, -1, this)">−</button>
                                        <input type="number" class="qty-input" value="<?= $item['quantity'] ?>" min="1" max="<?= $item['stock'] ?>" id="qty-<?= $item['id'] ?>" readonly>
                                        <button class="qty-btn" data-action="increase" onclick="changeQty(<?= $item['id'] ?>, 1, this)">+</button>
                                    </div>
                                    <span style="font-weight:800;color:var(--primary);font-size:.95rem" id="subtotal-<?= $item['id'] ?>">₹<?= number_format($item['price'] * $item['quantity']) ?></span>
                                    <button onclick="removeItem(<?= $item['id'] ?>)" class="btn btn-ghost btn-sm btn-icon" style="color:var(--danger)">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>

                <!-- Order Summary -->
                <div>
                    <div class="order-summary">
                        <h3 style="font-weight:800;margin-bottom:1.25rem">Order Summary</h3>
                        
                        <div class="summary-row"><span>Subtotal (<?= count($cart_items) ?> items)</span><span id="summarySubtotal">₹<?= number_format($subtotal) ?></span></div>
                        <div class="summary-row">
                            <span>Shipping</span>
                            <span id="summaryShipping" style="color:<?= $shipping===0 ? 'var(--accent)' : 'var(--text)' ?>">
                                <?= $shipping === 0 ? 'FREE' : "₹$shipping" ?>
                            </span>
                        </div>
                        <?php if ($shipping > 0): ?>
                        <p style="font-size:.75rem;color:var(--text-muted);margin-top:.25rem">Add ₹<?= number_format(500-$subtotal) ?> more for free shipping</p>
                        <?php endif; ?>
                        
                        <!-- Coupon -->
                        <div class="coupon-input">
                            <input type="text" id="couponCode" class="form-control" placeholder="Coupon code" style="font-size:.85rem">
                            <button class="btn btn-outline btn-sm" onclick="applyCoupon()"><i class="fas fa-tag"></i></button>
                        </div>
                        <p id="couponMsg" style="font-size:.8rem;margin-top:-.5rem;margin-bottom:.5rem"></p>
                        
                        <div class="summary-row total">
                            <span>Total Amount</span>
                            <span id="summaryTotal" style="color:var(--primary)">₹<?= number_format($total) ?></span>
                        </div>
                        
                        <a href="/Craft/customer/checkout.php" class="btn btn-primary btn-lg w-full" style="margin-top:1.25rem">
                            <i class="fas fa-shield-alt"></i> Proceed to Checkout
                        </a>
                        
                        <div style="display:flex;justify-content:center;gap:1rem;margin-top:1.25rem">
                            <span style="font-size:.72rem;color:var(--text-muted);display:flex;align-items:center;gap:.25rem"><i class="fas fa-lock"></i> Secure Checkout</span>
                            <span style="font-size:.72rem;color:var(--text-muted);display:flex;align-items:center;gap:.25rem"><i class="fas fa-undo"></i> Easy Returns</span>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<div id="sidebarOverlay" style="position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:850;display:none" onclick="document.getElementById('dashboardSidebar').classList.remove('open');this.style.display='none'"></div>
<script>
document.getElementById('sidebarOpenBtn')?.addEventListener('click', function() {
    document.getElementById('dashboardSidebar').classList.toggle('open');
    document.getElementById('sidebarOverlay').style.display = document.getElementById('dashboardSidebar').classList.contains('open') ? 'block' : 'none';
});

async function changeQty(itemId, delta, btn) {
    const input = document.getElementById('qty-' + itemId);
    const newQty = Math.max(1, parseInt(input.value) + delta);
    input.value = newQty;
    await updateCartQty(itemId, newQty, (data) => {
        updateTotals(data);
        const subtotalEl = document.getElementById('subtotal-' + itemId);
        const price = parseFloat(data.items?.find(i => i.id == itemId)?.price || 0);
        if (subtotalEl && price) subtotalEl.textContent = '₹' + (price * newQty).toLocaleString('en-IN');
    });
}

async function removeItem(itemId) {
    await removeFromCart(itemId, (data) => {
        document.getElementById('cart-item-' + itemId)?.remove();
        updateTotals(data);
        if (!document.querySelector('.cart-item')) location.reload();
    });
}

function updateTotals(data) {
    if (data.cart_total !== undefined) {
        document.getElementById('summarySubtotal').textContent = '₹' + parseFloat(data.cart_total).toLocaleString('en-IN');
        const shipping = parseFloat(data.cart_total) >= 500 ? 0 : 49;
        document.getElementById('summaryShipping').textContent = shipping === 0 ? 'FREE' : '₹49';
        document.getElementById('summaryShipping').style.color = shipping === 0 ? 'var(--accent)' : 'var(--text)';
        document.getElementById('summaryTotal').textContent = '₹' + (parseFloat(data.cart_total) + shipping).toLocaleString('en-IN');
    }
}

function applyCoupon() {
    const code = document.getElementById('couponCode').value.trim().toUpperCase();
    const valid = { 'CRAFT10': 10, 'NEWUSER20': 20, 'FLAT100': 'flat' };
    const msg = document.getElementById('couponMsg');
    if (valid[code]) {
        msg.style.color = 'var(--accent)';
        msg.textContent = code === 'FLAT100' ? '✓ ₹100 discount applied!' : '✓ ' + valid[code] + '% discount applied!';
    } else if (code) {
        msg.style.color = 'var(--danger)';
        msg.textContent = '✗ Invalid coupon code';
    }
}

async function clearCart() {
    if (!confirm('Clear your entire cart?')) return;
    const items = document.querySelectorAll('.cart-item');
    for (const item of items) {
        const id = item.id.replace('cart-item-', '');
        await fetch('/Craft/includes/ajax/cart.php', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({action:'remove',item_id:id}) });
    }
    location.reload();
}
</script>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body></html>
