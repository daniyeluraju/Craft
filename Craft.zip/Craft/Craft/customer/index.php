<?php
require_once '../includes/auth.php';
require_role('customer');

$uid = get_user_id();
$stats = [
    'orders'   => db_fetch("SELECT COUNT(*) as c FROM orders WHERE user_id=?", [$uid])['c'],
    'wishlist' => db_fetch("SELECT COUNT(*) as c FROM wishlist WHERE user_id=?", [$uid])['c'],
    'cart'     => db_fetch("SELECT SUM(quantity) as c FROM cart WHERE user_id=?", [$uid])['c'] ?? 0,
    'reviews'  => db_fetch("SELECT COUNT(*) as c FROM reviews WHERE user_id=?", [$uid])['c'],
];

$recent_orders = db_fetch_all("SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC LIMIT 5", [$uid]);
$wishlist_items = db_fetch_all("SELECT w.*, p.name, COALESCE(p.sale_price,p.price) as price, p.id as pid FROM wishlist w JOIN products p ON p.id=w.product_id WHERE w.user_id=? LIMIT 4", [$uid]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Dashboard – CraftStore</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/main.css">
</head>
<body>
<div class="dashboard-layout">
    <?php include '../includes/sidebar.php'; ?>
    <div class="dashboard-main">
        <div class="dashboard-topbar">
            <div style="display:flex;align-items:center;gap:1rem">
                <button class="btn btn-ghost btn-icon" id="sidebarOpenBtn"><i class="fas fa-bars"></i></button>
                <h1 class="topbar-title">My Dashboard</h1>
            </div>
            <div class="topbar-actions">
                <a href="<?= SITE_URL ?>/public/shop.php" class="btn btn-primary btn-sm"><i class="fas fa-shopping-bag"></i> Shop Now</a>
                <button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button>
            </div>
        </div>
        <div class="dashboard-content">
            <!-- Welcome banner -->
            <div style="background:linear-gradient(135deg,var(--primary-dark),var(--primary));border-radius:var(--radius-lg);padding:2rem;margin-bottom:1.5rem;position:relative;overflow:hidden">
                <div style="position:absolute;right:-30px;top:-30px;width:180px;height:180px;border-radius:50%;background:rgba(255,255,255,0.05)"></div>
                <div style="position:absolute;right:80px;bottom:-60px;width:220px;height:220px;border-radius:50%;background:rgba(255,255,255,0.04)"></div>
                <h2 style="color:white;font-size:1.5rem;margin-bottom:.4rem">Welcome back, <?= htmlspecialchars(explode(' ',$_SESSION['user_name'])[0]) ?>! 🎨</h2>
                <p style="color:rgba(255,255,255,0.75);font-size:.92rem">Here's a look at your shopping activity</p>
                <a href="<?= SITE_URL ?>/public/shop.php" class="btn btn-secondary btn-sm" style="margin-top:1.25rem">Explore New Arrivals <i class="fas fa-arrow-right"></i></a>
            </div>

            <!-- Stats -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon purple"><i class="fas fa-shopping-bag"></i></div>
                    <div>
                        <p class="stat-value"><?= $stats['orders'] ?></p>
                        <p class="stat-label">Total Orders</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon amber"><i class="fas fa-shopping-cart"></i></div>
                    <div>
                        <p class="stat-value"><?= $stats['cart'] ?></p>
                        <p class="stat-label">Items in Cart</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon red"><i class="fas fa-heart"></i></div>
                    <div>
                        <p class="stat-value"><?= $stats['wishlist'] ?></p>
                        <p class="stat-label">Wishlist Items</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon green"><i class="fas fa-star"></i></div>
                    <div>
                        <p class="stat-value"><?= $stats['reviews'] ?></p>
                        <p class="stat-label">Reviews Written</p>
                    </div>
                </div>
            </div>

            <!-- Two columns -->
            <div style="display:grid;grid-template-columns:1.5fr 1fr;gap:1.5rem">
                <!-- Recent Orders -->
                <div class="table-wrapper">
                    <div class="table-header">
                        <h3>Recent Orders</h3>
                        <a href="/Craft/customer/orders.php" class="btn btn-ghost btn-sm">View All</a>
                    </div>
                    <?php if (empty($recent_orders)): ?>
                    <div class="empty-state" style="padding:2rem">
                        <div class="empty-icon"><i class="fas fa-box-open"></i></div>
                        <p class="empty-subtitle">No orders yet</p>
                        <a href="<?= SITE_URL ?>/public/shop.php" class="btn btn-primary btn-sm">Start Shopping</a>
                    </div>
                    <?php else: ?>
                    <table class="data-table">
                        <thead><tr><th>Order #</th><th>Amount</th><th>Payment</th><th>Status</th><th>Date</th></tr></thead>
                        <tbody>
                        <?php foreach ($recent_orders as $o): ?>
                        <tr>
                            <td style="font-weight:600;color:var(--primary);font-size:.85rem"><?= $o['order_number'] ?></td>
                            <td style="font-weight:700">₹<?= number_format($o['final_amount']) ?></td>
                            <td style="font-size:.82rem;text-transform:uppercase"><?= $o['payment_method'] ?></td>
                            <td><span class="status-badge status-<?= $o['status'] ?>"><?= ucfirst($o['status']) ?></span></td>
                            <td style="font-size:.78rem;color:var(--text-muted)"><?= date('d M Y', strtotime($o['created_at'])) ?></td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>

                <!-- Wishlist -->
                <div class="chart-card">
                    <div class="chart-card-header">
                        <h3 class="chart-card-title"><i class="fas fa-heart" style="color:var(--danger);margin-right:.4rem"></i>Wishlist</h3>
                        <a href="/Craft/customer/wishlist.php" class="btn btn-ghost btn-sm">View All</a>
                    </div>
                    <?php if (empty($wishlist_items)): ?>
                    <div class="empty-state" style="padding:1.5rem">
                        <div class="empty-icon"><i class="fas fa-heart"></i></div>
                        <p class="empty-subtitle">Your wishlist is empty</p>
                        <a href="<?= SITE_URL ?>/public/shop.php" class="btn btn-primary btn-sm">Explore Products</a>
                    </div>
                    <?php else: foreach($wishlist_items as $wi): ?>
                    <div style="display:flex;align-items:center;gap:.75rem;padding:.75rem 0;border-bottom:1px solid var(--border)">
                        <div style="width:40px;height:40px;background:rgba(239,68,68,0.1);border-radius:10px;display:flex;align-items:center;justify-content:center;flex-shrink:0">
                            <i class="fas fa-heart" style="color:var(--danger);font-size:.85rem"></i>
                        </div>
                        <div style="flex:1;min-width:0">
                            <p style="font-size:.85rem;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($wi['name']) ?></p>
                            <p style="font-size:.78rem;color:var(--primary);font-weight:800">₹<?= number_format($wi['price']) ?></p>
                        </div>
                        <button class="btn btn-primary btn-sm" onclick="addToCart(<?= $wi['pid'] ?>)"><i class="fas fa-cart-plus"></i></button>
                    </div>
                    <?php endforeach; endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="sidebarOverlay" style="position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:850;display:none" onclick="document.getElementById('dashboardSidebar').classList.remove('open');this.style.display='none'"></div>
<script>document.getElementById('sidebarOpenBtn')?.addEventListener('click', function() { document.getElementById('dashboardSidebar').classList.toggle('open'); document.getElementById('sidebarOverlay').style.display = document.getElementById('dashboardSidebar').classList.contains('open') ? 'block' : 'none'; });</script>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body></html>
