<?php
require_once '../includes/auth.php';
require_role('customer');
$uid = get_user_id();

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $pid = intval($_POST['product_id'] ?? 0);
    if ($pid) { db_query("DELETE FROM wishlist WHERE user_id=? AND product_id=?", [$uid, $pid]); }
}

$wishlist = db_fetch_all("
    SELECT w.*, p.id as pid, p.name, p.description, COALESCE(p.sale_price,p.price) as price,
           p.price as orig_price, p.sale_price, c.name as cat_name
    FROM wishlist w JOIN products p ON p.id=w.product_id JOIN categories c ON c.id=p.category_id
    WHERE w.user_id=? ORDER BY w.created_at DESC
", [$uid]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Wishlist – CraftStore</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/main.css">
</head>
<body>
<div class="dashboard-layout">
    <?php include '../includes/sidebar.php'; ?>
    <div class="dashboard-main">
        <div class="dashboard-topbar">
            <div style="display:flex;align-items:center;gap:1rem">
                <button class="btn btn-ghost btn-icon" id="sidebarOpenBtn"><i class="fas fa-bars"></i></button>
                <h1 class="topbar-title">My Wishlist</h1>
            </div>
            <div class="topbar-actions"><button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button></div>
        </div>
        <div class="dashboard-content">
            <?php if (empty($wishlist)): ?>
            <div class="empty-state">
                <div class="empty-icon"><i class="fas fa-heart"></i></div>
                <h3 class="empty-title">Your Wishlist is Empty</h3>
                <p class="empty-subtitle">Save items you love by clicking the heart icon on any product</p>
                <a href="<?= SITE_URL ?>/public/shop.php" class="btn btn-primary btn-lg"><i class="fas fa-shopping-bag"></i> Explore Products</a>
            </div>
            <?php else: ?>
            <div class="product-grid">
                <?php foreach ($wishlist as $item): $disc = $item['sale_price'] ? round((($item['orig_price']-$item['sale_price'])/$item['orig_price'])*100) : 0; ?>
                <div class="product-card">
                    <div class="product-image">
                        <div class="art-placeholder" style="width:100%;height:100%">
                            <i class="fas fa-palette" style="font-size:3rem;color:rgba(239,68,68,0.25)"></i>
                        </div>
                        <div class="product-badges">
                            <?php if ($disc > 0): ?><span class="badge-pill badge-sale"><?= $disc ?>% off</span><?php endif; ?>
                        </div>
                        <div class="product-actions" style="opacity:1;transform:none">
                            <form method="POST" style="display:inline">
                                <input type="hidden" name="product_id" value="<?= $item['pid'] ?>">
                                <button class="product-action-btn wishlisted" title="Remove from wishlist"><i class="fas fa-heart"></i></button>
                            </form>
                        </div>
                    </div>
                    <div class="product-info">
                        <p class="product-category"><?= htmlspecialchars($item['cat_name']) ?></p>
                        <h3 class="product-name"><?= htmlspecialchars($item['name']) ?></h3>
                        <div class="product-price">
                            <span class="price-current">₹<?= number_format($item['price']) ?></span>
                            <?php if ($item['sale_price']): ?><span class="price-original">₹<?= number_format($item['orig_price']) ?></span><?php endif; ?>
                        </div>
                    </div>
                    <div class="product-footer">
                        <button class="btn btn-primary btn-sm btn-add-cart" onclick="addToCart(<?= $item['pid'] ?>)"><i class="fas fa-cart-plus"></i> Add to Cart</button>
                        <a href="<?= SITE_URL ?>/public/product.php?id=<?= $item['pid'] ?>" class="btn btn-ghost btn-sm btn-icon"><i class="fas fa-eye"></i></a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<div id="sidebarOverlay" style="position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:850;display:none" onclick="document.getElementById('dashboardSidebar').classList.remove('open');this.style.display='none'"></div>
<script>document.getElementById('sidebarOpenBtn')?.addEventListener('click', function() { document.getElementById('dashboardSidebar').classList.toggle('open'); document.getElementById('sidebarOverlay').style.display = document.getElementById('dashboardSidebar').classList.contains('open') ? 'block' : 'none'; });</script>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body></html>
