<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/auth.php';

$cart_count = get_cart_count();
$notif_count = get_notification_count();
$flash = get_flash_message();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/main.css">
</head>

<nav class="navbar" id="mainNavbar">
    <div class="nav-container">
        <a href="<?= SITE_URL ?>/public/index.php" class="nav-logo">
            <div class="logo-icon"><i class="fas fa-palette"></i></div>
            <span class="logo-text" style="font-size:.95rem;white-space:normal;line-height:1.2;max-width:220px;">E-commerce Web Application for Art & Handcrafted Items</span>
        </a>

        <div class="nav-search" id="navSearchBox">
            <form action="<?= SITE_URL ?>/public/shop.php" method="GET">
                <div class="search-wrapper">
                    <i class="fas fa-search search-icon"></i>
                    <input type="text" name="search" id="navSearch" placeholder="Search art, crafts, jewelry..." autocomplete="off">
                    <div class="search-dropdown" id="searchDropdown"></div>
                </div>
            </form>
        </div>

        <div class="nav-links">
            <a href="<?= SITE_URL ?>/public/index.php">Home</a>
            <a href="<?= SITE_URL ?>/public/shop.php">Shop</a>
            <a href="<?= SITE_URL ?>/public/about.php">About</a>
            <a href="<?= SITE_URL ?>/public/contact.php">Contact</a>
        </div>

        <div class="nav-actions">
            <?php if (is_logged_in()): ?>
                <a href="<?= SITE_URL ?>/<?= get_role() ?>/index.php" class="nav-icon-btn" title="Dashboard">
                    <i class="fas fa-tachometer-alt"></i>
                </a>
                <?php if (is_customer()): ?>
                <a href="<?= SITE_URL ?>/customer/wishlist.php" class="nav-icon-btn" title="Wishlist">
                    <i class="fas fa-heart"></i>
                </a>
                <a href="<?= SITE_URL ?>/customer/cart.php" class="nav-icon-btn cart-btn" title="Cart">
                    <i class="fas fa-shopping-cart"></i>
                    <?php if ($cart_count > 0): ?>
                    <span class="badge"><?= $cart_count ?></span>
                    <?php endif; ?>
                </a>
                <?php endif; ?>
                <div class="nav-user-menu">
                    <button class="user-avatar-btn">
                        <div class="avatar-circle"><?= strtoupper(substr($_SESSION['user_name'], 0, 1)) ?></div>
                        <span><?= htmlspecialchars(explode(' ', $_SESSION['user_name'])[0]) ?></span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="user-dropdown">
                        <div class="dropdown-header">
                            <strong><?= htmlspecialchars($_SESSION['user_name']) ?></strong>
                            <span class="role-badge <?= get_role() ?>"><?= ucfirst(get_role()) ?></span>
                        </div>
                        <a href="<?= SITE_URL ?>/<?= get_role() ?>/index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                        <a href="<?= SITE_URL ?>/<?= get_role() ?>/profile.php"><i class="fas fa-user"></i> Profile</a>
                        <?php if (is_customer()): ?>
                        <a href="<?= SITE_URL ?>/customer/orders.php"><i class="fas fa-box"></i> My Orders</a>
                        <?php endif; ?>
                        <div class="dropdown-divider"></div>
                        <a href="<?= SITE_URL ?>/logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> Logout</a>
                    </div>
                </div>
            <?php else: ?>
                <a href="<?= SITE_URL ?>/public/login.php" class="btn btn-outline-nav">Login</a>
                <a href="<?= SITE_URL ?>/public/register.php" class="btn btn-primary-nav">Sign Up</a>
            <?php endif; ?>

            <button class="theme-toggle" id="themeToggle" title="Toggle Theme">
                <i class="fas fa-moon"></i>
            </button>

            <button class="mobile-menu-btn" id="mobileMenuBtn">
                <span></span><span></span><span></span>
            </button>
        </div>
    </div>

    <!-- Mobile menu -->
    <div class="mobile-menu" id="mobileMenu">
        <a href="<?= SITE_URL ?>/public/index.php">Home</a>
        <a href="<?= SITE_URL ?>/public/shop.php">Shop</a>
        <a href="<?= SITE_URL ?>/public/about.php">About</a>
        <a href="<?= SITE_URL ?>/public/contact.php">Contact</a>
        <?php if (is_logged_in()): ?>
        <a href="<?= SITE_URL ?>/<?= get_role() ?>/index.php">Dashboard</a>
        <a href="<?= SITE_URL ?>/logout.php">Logout</a>
        <?php else: ?>
        <a href="<?= SITE_URL ?>/public/login.php">Login</a>
        <a href="<?= SITE_URL ?>/public/register.php">Register</a>
        <?php endif; ?>
    </div>
</nav>

<?php if ($flash): ?>
<div class="toast-container" id="toastContainer">
    <div class="toast toast-<?= $flash['type'] ?> show">
        <i class="fas fa-<?= $flash['type'] === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
        <?= htmlspecialchars($flash['message']) ?>
        <button class="toast-close" onclick="this.parentElement.remove()">×</button>
    </div>
</div>
<?php endif; ?>
