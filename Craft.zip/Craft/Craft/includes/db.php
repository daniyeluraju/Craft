<?php
// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'ecommerce_craft');

// Site Configuration
define('SITE_URL', 'http://localhost/Craft');
define('SITE_NAME', 'CraftStore');
define('UPLOAD_DIR', $_SERVER['DOCUMENT_ROOT'] . '/Craft/assets/uploads/');
define('UPLOAD_URL', SITE_URL . '/assets/uploads/');

// PDO Connection
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    die(json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]));
}

// Legacy mysqli connection for compatibility
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    // Silent fail - PDO is primary
}
$conn->set_charset("utf8mb4");

/**
 * Execute a query and return results
 */
function db_query($sql, $params = []) {
    global $pdo;
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    } catch (PDOException $e) {
        // Re-throw with SQL context so callers can catch it
        throw new RuntimeException('DB Error: ' . $e->getMessage() . ' | SQL: ' . $sql, 0, $e);
    }
}

/**
 * Fetch single row
 */
function db_fetch($sql, $params = []) {
    return db_query($sql, $params)->fetch();
}

/**
 * Fetch all rows
 */
function db_fetch_all($sql, $params = []) {
    return db_query($sql, $params)->fetchAll();
}

/**
 * Get last insert ID
 */
function db_last_id() {
    global $pdo;
    return $pdo->lastInsertId();
}
