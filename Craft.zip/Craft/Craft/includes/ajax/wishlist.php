<?php
require_once '../../includes/auth.php';
header('Content-Type: application/json');

if (!is_logged_in()) { echo json_encode(['success'=>false,'redirect'=>SITE_URL.'/public/login.php']); exit; }

$input = json_decode(file_get_contents('php://input'), true);
$pid   = intval($input['product_id'] ?? 0);
$uid   = get_user_id();

if (!$pid) { echo json_encode(['success'=>false,'message'=>'Invalid product']); exit; }

$existing = db_fetch("SELECT id FROM wishlist WHERE user_id=? AND product_id=?", [$uid, $pid]);
if ($existing) {
    db_query("DELETE FROM wishlist WHERE id=?", [$existing['id']]);
    echo json_encode(['success'=>true,'wishlisted'=>false]);
} else {
    db_query("INSERT INTO wishlist (user_id, product_id) VALUES (?,?)", [$uid, $pid]);
    echo json_encode(['success'=>true,'wishlisted'=>true]);
}
