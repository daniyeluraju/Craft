<?php
require_once '../../includes/auth.php';
header('Content-Type: application/json');

if (!is_logged_in() || !is_customer()) { echo json_encode(['success'=>false,'message'=>'Unauthorized']); exit; }

$input     = json_decode(file_get_contents('php://input'), true);
$pid       = intval($input['product_id'] ?? 0);
$uid       = get_user_id();
$rating    = intval($input['rating'] ?? 0);
$title     = sanitize($input['title'] ?? '');
$comment   = sanitize($input['comment'] ?? '');

if ($rating < 1 || $rating > 5) { echo json_encode(['success'=>false,'message'=>'Invalid rating']); exit; }
if (!$pid) { echo json_encode(['success'=>false,'message'=>'Invalid product']); exit; }

// Check if already reviewed
$existing = db_fetch("SELECT id FROM reviews WHERE product_id=? AND user_id=?", [$pid, $uid]);
if ($existing) { echo json_encode(['success'=>false,'message'=>'You have already reviewed this product']); exit; }

db_query("INSERT INTO reviews (product_id,user_id,rating,title,comment) VALUES (?,?,?,?,?)", [$pid,$uid,$rating,$title,$comment]);
echo json_encode(['success'=>true,'message'=>'Review submitted successfully']);
