<?php
require_once '../../includes/auth.php';
header('Content-Type: application/json');

$q = trim($_GET['q'] ?? '');
if (strlen($q) < 2) { echo json_encode([]); exit; }

$results = db_fetch_all(
    "SELECT p.id, p.name, COALESCE(p.sale_price, p.price) as price, c.name as cat_name
     FROM products p JOIN categories c ON p.category_id = c.id
     WHERE p.status='approved' AND (p.name LIKE ? OR p.description LIKE ?)
     ORDER BY p.is_featured DESC, p.views DESC LIMIT 8",
    ["%$q%", "%$q%"]
);

echo json_encode($results);
