<?php
require_once '../../includes/auth.php';
header('Content-Type: application/json');

if (!is_logged_in()) { echo json_encode(['success'=>false,'redirect'=>SITE_URL.'/public/login.php']); exit; }

$input  = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? $_POST['action'] ?? '';
$uid    = get_user_id();

if ($action === 'add') {
    $pid = intval($input['product_id'] ?? 0);
    $qty = max(1, intval($input['quantity'] ?? 1));
    
    if (!$pid) { echo json_encode(['success'=>false,'message'=>'Invalid product']); exit; }
    
    $product = db_fetch("SELECT id, stock FROM products WHERE id=? AND status='approved'", [$pid]);
    if (!$product) { echo json_encode(['success'=>false,'message'=>'Product not found']); exit; }
    if ($product['stock'] < $qty) { echo json_encode(['success'=>false,'message'=>'Insufficient stock']); exit; }
    
    $existing = db_fetch("SELECT id, quantity FROM cart WHERE user_id=? AND product_id=?", [$uid, $pid]);
    if ($existing) {
        $new_qty = $existing['quantity'] + $qty;
        db_query("UPDATE cart SET quantity=? WHERE id=?", [min($new_qty, $product['stock']), $existing['id']]);
    } else {
        db_query("INSERT INTO cart (user_id, product_id, quantity) VALUES (?,?,?)", [$uid, $pid, $qty]);
    }
    
    $count = db_fetch("SELECT SUM(quantity) as total FROM cart WHERE user_id=?", [$uid])['total'] ?? 0;
    echo json_encode(['success'=>true,'cart_count'=>(int)$count]);

} elseif ($action === 'remove') {
    $item_id = intval($input['item_id'] ?? 0);
    db_query("DELETE FROM cart WHERE id=? AND user_id=?", [$item_id, $uid]);
    $count = db_fetch("SELECT SUM(quantity) as total FROM cart WHERE user_id=?", [$uid])['total'] ?? 0;
    $total = db_fetch("SELECT SUM(COALESCE(p.sale_price,p.price)*c.quantity) as total FROM cart c JOIN products p ON p.id=c.product_id WHERE c.user_id=?", [$uid])['total'] ?? 0;
    echo json_encode(['success'=>true,'cart_count'=>(int)$count,'cart_total'=>$total]);

} elseif ($action === 'update') {
    $item_id = intval($input['item_id'] ?? 0);
    $qty     = max(1, intval($input['quantity'] ?? 1));
    
    $item = db_fetch("SELECT c.id, p.stock FROM cart c JOIN products p ON p.id=c.product_id WHERE c.id=? AND c.user_id=?", [$item_id, $uid]);
    if ($item) {
        $qty = min($qty, $item['stock']);
        db_query("UPDATE cart SET quantity=? WHERE id=?", [$qty, $item_id]);
    }
    
    $count = db_fetch("SELECT SUM(quantity) as total FROM cart WHERE user_id=?", [$uid])['total'] ?? 0;
    $total = db_fetch("SELECT SUM(COALESCE(p.sale_price,p.price)*c.quantity) as total FROM cart c JOIN products p ON p.id=c.product_id WHERE c.user_id=?", [$uid])['total'] ?? 0;
    echo json_encode(['success'=>true,'cart_count'=>(int)$count,'cart_total'=>$total]);

} elseif ($action === 'get') {
    $items = db_fetch_all(
        "SELECT c.id, c.quantity, p.id as product_id, p.name, COALESCE(p.sale_price,p.price) as price, p.stock
         FROM cart c JOIN products p ON p.id=c.product_id WHERE c.user_id=?", [$uid]
    );
    echo json_encode(['success'=>true,'items'=>$items]);

} else {
    echo json_encode(['success'=>false,'message'=>'Invalid action']);
}
