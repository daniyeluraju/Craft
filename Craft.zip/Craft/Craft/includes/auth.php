<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/db.php';

/**
 * Check if user is logged in
 */
function is_logged_in() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Get current user role
 */
function get_role() {
    return $_SESSION['role'] ?? null;
}

/**
 * Check if current user is admin
 */
function is_admin() {
    return get_role() === 'admin';
}

/**
 * Check if current user is seller
 */
function is_seller() {
    return get_role() === 'seller';
}

/**
 * Check if current user is customer
 */
function is_customer() {
    return get_role() === 'customer';
}

/**
 * Get current user ID
 */
function get_user_id() {
    return $_SESSION['user_id'] ?? null;
}

/**
 * Get current user data
 */
function get_current_user_data() {
    if (!is_logged_in()) return null;
    return db_fetch("SELECT u.*, r.name as role_name FROM users u JOIN roles r ON u.role_id = r.id WHERE u.id = ?", [get_user_id()]);
}

/**
 * Require login - redirect if not logged in
 */
function require_login($redirect = '/Craft/public/login.php') {
    if (!is_logged_in()) {
        header("Location: " . SITE_URL . "/public/login.php");
        exit;
    }
}

/**
 * Require specific role
 */
function require_role($role, $redirect = null) {
    require_login();
    if (get_role() !== $role) {
        if ($redirect) {
            header("Location: $redirect");
        } else {
            header("Location: " . SITE_URL . "/" . get_role() . "/index.php");
        }
        exit;
    }
}

/**
 * Login user
 */
function login_user($email, $password) {
    $user = db_fetch(
        "SELECT u.*, r.name as role_name FROM users u JOIN roles r ON u.role_id = r.id WHERE u.email = ? AND u.is_active = 1",
        [$email]
    );
    
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id']   = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['user_email']= $user['email'];
        $_SESSION['role']      = $user['role_name'];
        $_SESSION['avatar']    = $user['avatar'];
        return $user;
    }
    return false;
}

/**
 * Register new user
 */
function register_user($data) {
    // Check if email exists
    $existing = db_fetch("SELECT id FROM users WHERE email = ?", [$data['email']]);
    if ($existing) return ['success' => false, 'message' => 'Email already registered.'];
    
    $role = db_fetch("SELECT id FROM roles WHERE name = ?", [$data['role'] ?? 'customer']);
    if (!$role) return ['success' => false, 'message' => 'Invalid role selected.'];
    
    $hashed = password_hash($data['password'], PASSWORD_DEFAULT);
    
    db_query(
        "INSERT INTO users (role_id, name, email, password, phone, address) VALUES (?, ?, ?, ?, ?, ?)",
        [$role['id'], $data['name'], $data['email'], $hashed, $data['phone'] ?? '', $data['address'] ?? '']
    );
    
    $user_id = db_last_id();
    
    // Create seller profile if role is seller
    if ($data['role'] === 'seller') {
        db_query(
            "INSERT INTO seller_profiles (user_id, shop_name) VALUES (?, ?)",
            [$user_id, $data['name'] . "'s Shop"]
        );
    }
    
    return ['success' => true, 'user_id' => $user_id];
}

/**
 * Logout user
 */
function logout_user() {
    session_destroy();
    header("Location: " . SITE_URL . "/public/login.php");
    exit;
}

/**
 * Get cart count
 */
function get_cart_count() {
    if (!is_logged_in()) return 0;
    $result = db_fetch("SELECT SUM(quantity) as total FROM cart WHERE user_id = ?", [get_user_id()]);
    return $result['total'] ?? 0;
}

/**
 * Get notification count
 */
function get_notification_count() {
    if (!is_logged_in()) return 0;
    $result = db_fetch("SELECT COUNT(*) as total FROM notifications WHERE user_id = ? AND is_read = 0", [get_user_id()]);
    return $result['total'] ?? 0;
}

/**
 * Sanitize input
 */
function sanitize($input) {
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}

/**
 * Generate unique order number
 */
function generate_order_number() {
    return 'ORD-' . date('Y') . '-' . strtoupper(substr(uniqid(), -6));
}

/**
 * Format price in INR
 */
function format_price($price) {
    return '₹' . number_format($price, 2);
}

/**
 * Generate star rating HTML
 */
function star_rating($rating, $max = 5) {
    $html = '<div class="stars">';
    for ($i = 1; $i <= $max; $i++) {
        if ($i <= $rating) {
            $html .= '<i class="fas fa-star filled"></i>';
        } elseif ($i - 0.5 <= $rating) {
            $html .= '<i class="fas fa-star-half-alt filled"></i>';
        } else {
            $html .= '<i class="far fa-star"></i>';
        }
    }
    $html .= '</div>';
    return $html;
}

/**
 * Get average rating for product
 */
function get_product_rating($product_id) {
    $result = db_fetch(
        "SELECT AVG(rating) as avg_rating, COUNT(*) as total FROM reviews WHERE product_id = ? AND is_approved = 1",
        [$product_id]
    );
    return $result;
}

/**
 * Redirect with message
 */
function redirect_with_message($url, $message, $type = 'success') {
    $_SESSION['flash_message'] = $message;
    $_SESSION['flash_type'] = $type;
    header("Location: $url");
    exit;
}

/**
 * Get and clear flash message
 */
function get_flash_message() {
    if (isset($_SESSION['flash_message'])) {
        $msg = ['message' => $_SESSION['flash_message'], 'type' => $_SESSION['flash_type'] ?? 'success'];
        unset($_SESSION['flash_message'], $_SESSION['flash_type']);
        return $msg;
    }
    return null;
}
