<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/auth.php';

$role = get_role();
$user_name = $_SESSION['user_name'] ?? 'User';
?>
<aside class="dashboard-sidebar" id="dashboardSidebar">
    <div class="sidebar-header">
        <a href="<?= SITE_URL ?>/public/index.php" class="sidebar-logo">
            <i class="fas fa-palette"></i>
            <span>Craft<span>Store</span></span>
        </a>
        <button class="sidebar-close" id="sidebarClose"><i class="fas fa-times"></i></button>
    </div>

    <div class="sidebar-user">
        <div class="sidebar-avatar"><?= strtoupper(substr($user_name, 0, 1)) ?></div>
        <div class="sidebar-user-info">
            <strong><?= htmlspecialchars($user_name) ?></strong>
            <span class="sidebar-role"><?= ucfirst($role) ?></span>
        </div>
    </div>

    <nav class="sidebar-nav">
        <?php if ($role === 'admin'): ?>
        <div class="nav-section-title">OVERVIEW</div>
        <a href="/Craft/admin/index.php" class="sidebar-link <?= basename($_SERVER['PHP_SELF']) === 'index.php' ? 'active' : '' ?>">
            <i class="fas fa-tachometer-alt"></i><span>Dashboard</span>
        </a>
        <div class="nav-section-title">MANAGEMENT</div>
        <a href="/Craft/admin/users.php" class="sidebar-link <?= basename($_SERVER['PHP_SELF']) === 'users.php' ? 'active' : '' ?>">
            <i class="fas fa-users"></i><span>Users</span>
        </a>
        <a href="/Craft/admin/products.php" class="sidebar-link <?= basename($_SERVER['PHP_SELF']) === 'products.php' ? 'active' : '' ?>">
            <i class="fas fa-box"></i><span>Products</span>
        </a>
        <a href="/Craft/admin/orders.php" class="sidebar-link <?= basename($_SERVER['PHP_SELF']) === 'orders.php' ? 'active' : '' ?>">
            <i class="fas fa-shopping-bag"></i><span>Orders</span>
        </a>
        <a href="/Craft/admin/categories.php" class="sidebar-link <?= basename($_SERVER['PHP_SELF']) === 'categories.php' ? 'active' : '' ?>">
            <i class="fas fa-tags"></i><span>Categories</span>
        </a>
        <div class="nav-section-title">REPORTS</div>
        <a href="/Craft/admin/analytics.php" class="sidebar-link <?= basename($_SERVER['PHP_SELF']) === 'analytics.php' ? 'active' : '' ?>">
            <i class="fas fa-chart-line"></i><span>Analytics</span>
        </a>
        <a href="/Craft/admin/messages.php" class="sidebar-link <?= basename($_SERVER['PHP_SELF']) === 'messages.php' ? 'active' : '' ?>">
            <i class="fas fa-envelope"></i><span>Messages</span>
        </a>

        <?php elseif ($role === 'seller'): ?>
        <div class="nav-section-title">OVERVIEW</div>
        <a href="/Craft/seller/index.php" class="sidebar-link <?= basename($_SERVER['PHP_SELF']) === 'index.php' ? 'active' : '' ?>">
            <i class="fas fa-tachometer-alt"></i><span>Dashboard</span>
        </a>
        <div class="nav-section-title">STORE</div>
        <a href="/Craft/seller/products.php" class="sidebar-link <?= basename($_SERVER['PHP_SELF']) === 'products.php' ? 'active' : '' ?>">
            <i class="fas fa-paint-brush"></i><span>My Products</span>
        </a>
        <a href="/Craft/seller/add-product.php" class="sidebar-link <?= basename($_SERVER['PHP_SELF']) === 'add-product.php' ? 'active' : '' ?>">
            <i class="fas fa-plus-circle"></i><span>Add Product</span>
        </a>
        <a href="/Craft/seller/orders.php" class="sidebar-link <?= basename($_SERVER['PHP_SELF']) === 'orders.php' ? 'active' : '' ?>">
            <i class="fas fa-shopping-bag"></i><span>Orders</span>
        </a>
        <div class="nav-section-title">ACCOUNT</div>
        <a href="/Craft/seller/earnings.php" class="sidebar-link <?= basename($_SERVER['PHP_SELF']) === 'earnings.php' ? 'active' : '' ?>">
            <i class="fas fa-rupee-sign"></i><span>Earnings</span>
        </a>
        <a href="/Craft/seller/profile.php" class="sidebar-link <?= basename($_SERVER['PHP_SELF']) === 'profile.php' ? 'active' : '' ?>">
            <i class="fas fa-store"></i><span>Shop Profile</span>
        </a>

        <?php elseif ($role === 'customer'): ?>
        <div class="nav-section-title">OVERVIEW</div>
        <a href="/Craft/customer/index.php" class="sidebar-link <?= basename($_SERVER['PHP_SELF']) === 'index.php' ? 'active' : '' ?>">
            <i class="fas fa-home"></i><span>Dashboard</span>
        </a>
        <div class="nav-section-title">SHOPPING</div>
        <a href="/Craft/customer/cart.php" class="sidebar-link <?= basename($_SERVER['PHP_SELF']) === 'cart.php' ? 'active' : '' ?>">
            <i class="fas fa-shopping-cart"></i><span>My Cart</span>
        </a>
        <a href="/Craft/customer/wishlist.php" class="sidebar-link <?= basename($_SERVER['PHP_SELF']) === 'wishlist.php' ? 'active' : '' ?>">
            <i class="fas fa-heart"></i><span>Wishlist</span>
        </a>
        <a href="/Craft/customer/orders.php" class="sidebar-link <?= basename($_SERVER['PHP_SELF']) === 'orders.php' ? 'active' : '' ?>">
            <i class="fas fa-box"></i><span>My Orders</span>
        </a>
        <div class="nav-section-title">ACCOUNT</div>
        <a href="/Craft/customer/profile.php" class="sidebar-link <?= basename($_SERVER['PHP_SELF']) === 'profile.php' ? 'active' : '' ?>">
            <i class="fas fa-user"></i><span>Profile</span>
        </a>
        <?php endif; ?>
    </nav>

    <div class="sidebar-footer">
        <a href="<?= SITE_URL ?>/public/index.php" class="sidebar-link">
            <i class="fas fa-store"></i><span>Visit Store</span>
        </a>
        <a href="<?= SITE_URL ?>/logout.php" class="sidebar-link logout">
            <i class="fas fa-sign-out-alt"></i><span>Logout</span>
        </a>
    </div>
</aside>
