# CraftStore – Installation Guide
**E-Commerce Platform for Art & Handcrafted Products**

---

## Prerequisites
- XAMPP (with Apache + MySQL/MariaDB + PHP 8.0+)
- Web browser (Chrome, Firefox, Edge)

---

## Step-by-Step Installation

### 1. Copy Project Files
Place the `Craft` folder in:
```
d:\xampp\htdocs\Craft\
```

### 2. Import Database
1. Start XAMPP → Start **Apache** and **MySQL**
2. Open browser → go to `http://localhost/phpmyadmin`
3. Click **New** → Create database: `ecommerce_craft`
4. Click the new database → go to **Import** tab
5. Browse and select `d:\xampp\htdocs\Craft\database\ecommerce.sql`
6. Click **Go** to import

> **OR** use MySQL CLI:
> ```
> mysql -u root -e "source d:/xampp/htdocs/Craft/database/ecommerce.sql"
> ```

### 3. Configure Database
Edit `d:\xampp\htdocs\Craft\includes\db.php`:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');        // Change if you have a MySQL password
define('DB_NAME', 'ecommerce_craft');
define('SITE_URL', 'http://localhost/Craft');
```

### 4. Set Upload Permissions
Ensure the uploads directory exists and is writable:
```
d:\xampp\htdocs\Craft\assets\uploads\
```

### 5. Access the Application
Open browser → `http://localhost/Craft/public/index.php`

---

## Demo Login Credentials

| Role     | Email                     | Password |
|----------|---------------------------|----------|
| Admin    | admin@craftstore.com      | password |
| Seller   | seller@craftstore.com     | password |
| Customer | customer@craftstore.com   | password |

> Use the **Demo Login** buttons on the login page for one-click access!

---

## Project Structure
```
/Craft
├── public/          → Public pages (home, shop, product, about, contact)
├── admin/           → Admin dashboard (users, products, orders, analytics)
├── seller/          → Seller dashboard (products, orders, earnings)
├── customer/        → Customer dashboard (cart, orders, wishlist, profile)
├── includes/
│   ├── db.php       → Database connection
│   ├── auth.php     → Authentication helpers
│   ├── navbar.php   → Navigation bar
│   ├── sidebar.php  → Dashboard sidebar
│   └── ajax/        → AJAX endpoints (cart, wishlist, search, review)
├── assets/
│   ├── css/main.css → Main stylesheet (glassmorphism UI)
│   ├── js/main.js   → JavaScript (AJAX, theme, cart functions)
│   └── uploads/     → Product image uploads
├── database/
│   └── ecommerce.sql → Full database with sample data
└── logout.php
```

---

## Key Features
- ✅ Role-Based Access: Admin / Seller / Customer
- ✅ Glassmorphism UI + Dark Mode Toggle
- ✅ AJAX Live Search, Cart, Wishlist
- ✅ Complete Checkout with Payment Simulation (COD/UPI/Card)
- ✅ Order Tracking with Visual Progress
- ✅ Admin Analytics with Chart.js
- ✅ Seller Product Management with Approval Flow
- ✅ Star Ratings & Reviews
- ✅ Fully Responsive (Mobile-First)

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Blank page | Enable PHP errors in php.ini: `display_errors = On` |
| DB connection error | Check DB credentials in `includes/db.php` |
| Images not showing | The UI uses SVG placeholders (production: add real images to `assets/uploads/`) |
| Login not working | Re-import the SQL file; ensure password hash is correct |
| AJAX not working | Ensure Apache is running and `SITE_URL` is correct in `db.php` |

---

## Tech Stack
- **Backend:** PHP 8.x (PDO + MySQLi)
- **Database:** MySQL 8.x / MariaDB 10.x
- **Frontend:** HTML5, CSS3, Vanilla JavaScript
- **UI:** Glassmorphism, CSS Custom Properties, Flexbox/Grid
- **Charts:** Chart.js (CDN)
- **Icons:** Font Awesome 6.5
- **Fonts:** Google Fonts (Outfit)

---

*Built as MCA Final Year Project – CraftStore © 2024*
