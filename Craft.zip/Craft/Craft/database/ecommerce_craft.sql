-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 14, 2026 at 08:14 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce_craft`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(60) DEFAULT 'fa-tag',
  `image` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `description`, `icon`, `image`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Paintings', 'paintings', 'Original artworks, oil paintings, watercolors and more', 'fa-paint-brush', 'paintings.jpg', 1, '2026-04-14 16:13:37', '2026-04-14 16:52:48'),
(2, 'Handicrafts', 'handicrafts', 'Traditional handmade crafts from skilled artisans', 'fa-cut', 'handicrafts.jpg', 1, '2026-04-14 16:13:37', '2026-04-14 16:52:48'),
(3, 'Jewelry', 'jewelry', 'Handcrafted necklaces, earrings, bracelets and rings', 'fa-gem', 'jewelry.jpg', 1, '2026-04-14 16:13:37', '2026-04-14 16:52:48'),
(4, 'Home Decor', 'home-decor', 'Beautiful handmade items to decorate your home', 'fa-home', 'home-decor.jpg', 1, '2026-04-14 16:13:37', '2026-04-14 16:52:48'),
(5, 'Pottery', 'pottery', 'Hand-thrown and hand-painted pottery items', 'fa-wine-glass', 'pottery.jpg', 1, '2026-04-14 16:13:37', '2026-04-14 16:52:48'),
(6, 'Textiles', 'textiles', 'Hand-woven fabrics, shawls, and traditional textiles', 'fa-tshirt', 'textiles.jpg', 1, '2026-04-14 16:13:37', '2026-04-14 16:52:48');

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `subject` varchar(200) DEFAULT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `replied_at` timestamp NULL DEFAULT NULL,
  `reply` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact_messages`
--

INSERT INTO `contact_messages` (`id`, `name`, `email`, `subject`, `message`, `is_read`, `replied_at`, `reply`, `created_at`) VALUES
(1, 'citrezen', 'kitchen@hospital.com', 'Seller Inquiry', 'hii', 0, NULL, NULL, '2026-04-14 16:37:33');

-- --------------------------------------------------------

--
-- Table structure for table `coupons`
--

CREATE TABLE `coupons` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `type` enum('percentage','fixed') DEFAULT 'percentage',
  `value` decimal(10,2) NOT NULL,
  `min_order` decimal(10,2) DEFAULT 0.00,
  `max_uses` int(11) DEFAULT 100,
  `used_count` int(11) DEFAULT 0,
  `expires_at` date DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `coupons`
--

INSERT INTO `coupons` (`id`, `code`, `type`, `value`, `min_order`, `max_uses`, `used_count`, `expires_at`, `is_active`, `created_at`) VALUES
(1, 'CRAFT10', 'percentage', 10.00, 500.00, 100, 0, '2025-12-31', 1, '2026-04-14 16:13:42'),
(2, 'NEWUSER20', 'percentage', 20.00, 1000.00, 50, 0, '2025-12-31', 1, '2026-04-14 16:13:42'),
(3, 'FLAT100', 'fixed', 100.00, 800.00, 200, 0, '2025-06-30', 1, '2026-04-14 16:13:42');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `type` enum('order','payment','product','system','review') DEFAULT 'system',
  `is_read` tinyint(1) DEFAULT 0,
  `link` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `title`, `message`, `type`, `is_read`, `link`, `created_at`) VALUES
(1, 3, 'Order Delivered!', 'Your order ORD-2024-001 has been delivered successfully.', 'order', 0, NULL, '2026-04-14 16:13:42'),
(2, 3, 'Order Shipped', 'Your order ORD-2024-002 has been shipped. Track your package.', 'order', 0, NULL, '2026-04-14 16:13:42'),
(3, 2, 'New Order Received', 'You have received a new order for Radha Krishna Canvas Painting.', 'order', 1, NULL, '2026-04-14 16:13:42'),
(4, 1, 'New Product Pending', 'A new product is pending approval from seller Priya Sharma.', 'product', 0, NULL, '2026-04-14 16:13:42'),
(5, 3, 'Order Delivered!', 'Your order ORD-2024-001 has been delivered successfully.', 'order', 0, NULL, '2026-04-14 16:34:57'),
(6, 3, 'Order Shipped', 'Your order ORD-2024-002 has been shipped. Track your package.', 'order', 0, NULL, '2026-04-14 16:34:57'),
(7, 2, 'New Order Received', 'You have received a new order for Radha Krishna Canvas Painting.', 'order', 1, NULL, '2026-04-14 16:34:57'),
(8, 1, 'New Product Pending', 'A new product is pending approval from seller Priya Sharma.', 'product', 0, NULL, '2026-04-14 16:34:57'),
(9, 3, 'Order Placed! 🎉', 'Your order #ORD-2026-9DF953 has been placed successfully.', 'order', 0, NULL, '2026-04-14 17:54:02');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_number` varchar(20) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `discount_amount` decimal(10,2) DEFAULT 0.00,
  `shipping_amount` decimal(10,2) DEFAULT 0.00,
  `final_amount` decimal(10,2) NOT NULL,
  `status` enum('pending','confirmed','processing','shipped','delivered','cancelled','refunded') DEFAULT 'pending',
  `payment_method` enum('cod','upi','card','netbanking') DEFAULT 'cod',
  `payment_status` enum('pending','paid','failed','refunded') DEFAULT 'pending',
  `shipping_name` varchar(100) DEFAULT NULL,
  `shipping_phone` varchar(20) DEFAULT NULL,
  `shipping_address` text DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_pincode` varchar(10) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `order_number`, `total_amount`, `discount_amount`, `shipping_amount`, `final_amount`, `status`, `payment_method`, `payment_status`, `shipping_name`, `shipping_phone`, `shipping_address`, `shipping_city`, `shipping_state`, `shipping_pincode`, `notes`, `created_at`, `updated_at`) VALUES
(1, 3, 'ORD-2024-001', 1999.00, 0.00, 0.00, 1999.00, 'delivered', 'upi', 'paid', 'Rahul Kumar', '9876543212', '123 MG Road', 'Bangalore', 'Karnataka', '560001', NULL, '2026-04-14 16:13:40', '2026-04-14 16:13:40'),
(2, 3, 'ORD-2024-002', 2999.00, 0.00, 0.00, 2999.00, 'cancelled', 'card', 'paid', 'Rahul Kumar', '9876543212', '123 MG Road', 'Bangalore', 'Karnataka', '560001', NULL, '2026-04-14 16:13:40', '2026-04-14 16:55:50'),
(3, 5, 'ORD-2024-003', 699.00, 0.00, 0.00, 699.00, 'pending', 'cod', 'pending', 'Anjali Singh', '9876543214', '456 Lajpat Nagar', 'Delhi', 'Delhi', '110024', NULL, '2026-04-14 16:13:40', '2026-04-14 16:13:40'),
(7, 3, 'ORD-2026-9DF953', 1949.99, 0.00, 0.00, 1949.99, 'pending', 'upi', 'paid', 'Rahul Kumar', '9876543212', 'Bangalore, Karnataka', 'guntur', 'Andhra Pradesh', '522306', NULL, '2026-04-14 17:54:01', '2026-04-14 17:54:01');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `product_name` varchar(200) DEFAULT NULL,
  `product_price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `status` enum('pending','processing','shipped','delivered','cancelled') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `seller_id`, `product_name`, `product_price`, `quantity`, `subtotal`, `status`, `created_at`) VALUES
(1, 1, 1, 2, 'Radha Krishna Canvas Painting', 1999.00, 1, 1999.00, 'delivered', '2026-04-14 16:13:40'),
(2, 2, 3, 4, 'Kundan Bridal Necklace Set', 2999.00, 1, 2999.00, 'cancelled', '2026-04-14 16:13:40'),
(3, 3, 8, 4, 'Macrame Wall Hanging', 699.00, 1, 699.00, 'pending', '2026-04-14 16:13:40'),
(4, 1, 1, 2, 'Radha Krishna Canvas Painting', 1999.00, 1, 1999.00, 'delivered', '2026-04-14 16:34:57'),
(5, 2, 3, 4, 'Kundan Bridal Necklace Set', 2999.00, 1, 2999.00, 'cancelled', '2026-04-14 16:34:57'),
(6, 3, 8, 4, 'Macrame Wall Hanging', 699.00, 1, 699.00, 'pending', '2026-04-14 16:34:57'),
(7, 7, 21, 2, 'canvas of shiva', 1949.99, 1, 1949.99, 'shipped', '2026-04-14 17:54:02');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `transaction_id` varchar(100) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `method` enum('cod','upi','card','netbanking') NOT NULL,
  `status` enum('pending','success','failed','refunded') DEFAULT 'pending',
  `gateway_response` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `slug` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `sale_price` decimal(10,2) DEFAULT NULL,
  `stock` int(11) DEFAULT 0,
  `sku` varchar(100) DEFAULT NULL,
  `images` text DEFAULT NULL COMMENT 'JSON array of image filenames',
  `featured_image` varchar(255) DEFAULT NULL,
  `is_featured` tinyint(1) DEFAULT 0,
  `is_trending` tinyint(1) DEFAULT 0,
  `status` enum('pending','approved','rejected','draft') DEFAULT 'pending',
  `views` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `seller_id`, `category_id`, `name`, `slug`, `description`, `price`, `sale_price`, `stock`, `sku`, `images`, `featured_image`, `is_featured`, `is_trending`, `status`, `views`, `created_at`, `updated_at`) VALUES
(1, 2, 1, 'Radha Krishna Canvas Painting', 'radha-krishna-canvas-painting', 'Beautiful hand-painted Radha Krishna artwork on canvas. Made with premium quality acrylic colors. Size: 24x36 inches.', 2499.00, 2000.00, 15, NULL, NULL, 'product1.jpg', 1, 1, 'approved', 2, '2026-04-14 16:13:39', '2026-04-14 16:54:50'),
(2, 2, 2, 'Brass Ganesha Handicraft', 'brass-ganesha-handicraft', 'Intricately carved brass Ganesha idol. Perfect for home temples and gifting. Height: 8 inches.', 1299.00, NULL, 25, NULL, NULL, 'product2.jpg', 1, 1, 'approved', 0, '2026-04-14 16:13:39', '2026-04-14 16:13:39'),
(3, 4, 3, 'Kundan Bridal Necklace Set', 'kundan-bridal-necklace-set', 'Exquisite Kundan necklace with matching earrings. Handcrafted by skilled Jaipur artisans. Gold plated.', 3499.00, 2999.00, 8, NULL, NULL, 'product3.jpg', 1, 0, 'approved', 0, '2026-04-14 16:13:39', '2026-04-14 16:13:39'),
(4, 4, 4, 'Madhubani Wall Art', 'madhubani-wall-art', 'Traditional Madhubani painting on handmade paper. Framed and ready to hang. Size: 18x24 inches.', 899.00, NULL, 30, NULL, NULL, 'product4.jpg', 0, 1, 'approved', 0, '2026-04-14 16:13:39', '2026-04-14 16:13:39'),
(5, 2, 5, 'Blue Pottery Vase Set', 'blue-pottery-vase-set', 'Set of 3 hand-painted blue pottery vases from Jaipur. Unique floral patterns.', 1599.00, 1299.00, 12, NULL, NULL, 'product5.jpg', 1, 1, 'approved', 0, '2026-04-14 16:13:39', '2026-04-14 16:13:39'),
(6, 4, 6, 'Banarasi Silk Dupatta', 'banarasi-silk-dupatta', 'Pure Banarasi silk dupatta with zari work. Traditional weaving patterns. Length: 2.5 meters.', 2199.00, NULL, 20, NULL, NULL, 'product6.jpg', 0, 0, 'approved', 0, '2026-04-14 16:13:39', '2026-04-14 17:00:32'),
(7, 2, 1, 'Abstract Acrylic Artwork', 'abstract-acrylic-artwork', 'Modern abstract painting with vibrant colors. Perfect for contemporary home decor. Size: 20x20 inches.', 1799.00, 1499.00, 5, NULL, NULL, 'product7.jpg', 1, 0, 'approved', 1, '2026-04-14 16:13:39', '2026-04-14 16:36:56'),
(8, 4, 4, 'Macrame Wall Hanging', 'macrame-wall-hanging', 'Handknotted macrame wall hanging. Bohemian style decor. Size: 24x36 inches.', 699.00, NULL, 18, NULL, NULL, 'product8.jpg', 0, 1, 'approved', 0, '2026-04-14 16:13:39', '2026-04-14 16:13:39'),
(21, 2, 1, 'canvas of shiva', 'canvas-of-shiva-1776188839', 'best', 2000.00, 1949.99, 9, 'at', '[\"\\/products\\/prod_69de7da75a2d9.avif\"]', '/products/prod_69de7da75a2d9.avif', 1, 0, 'approved', 3, '2026-04-14 17:47:19', '2026-04-14 18:00:33');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `rating` tinyint(4) NOT NULL CHECK (`rating` >= 1 and `rating` <= 5),
  `title` varchar(200) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `is_approved` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `product_id`, `user_id`, `order_id`, `rating`, `title`, `comment`, `is_approved`, `created_at`) VALUES
(1, 1, 3, NULL, 5, 'Absolutely Beautiful!', 'The painting is stunning. Colors are vibrant and the quality is excellent. Highly recommend!', 1, '2026-04-14 16:13:41'),
(2, 2, 5, NULL, 4, 'Great Craftsmanship', 'Beautiful Ganesha idol. Very detailed work. Packed well and delivered on time.', 1, '2026-04-14 16:13:41'),
(3, 3, 3, NULL, 5, 'Perfect Bridal Set', 'Bought this for my wedding. Everyone loved it! The craftsmanship is impeccable.', 1, '2026-04-14 16:13:41'),
(4, 4, 5, NULL, 4, 'Lovely Art Piece', 'Beautiful Madhubani art. Looks amazing on my living room wall.', 1, '2026-04-14 16:13:41'),
(5, 5, 3, NULL, 5, 'Gorgeous Pottery', 'The blue pottery vases are absolutely stunning. Perfect home decor item.', 1, '2026-04-14 16:13:41');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `description`, `created_at`) VALUES
(1, 'admin', 'Platform administrator with full access', '2026-04-14 16:13:36'),
(2, 'seller', 'Artisan/seller who can list products', '2026-04-14 16:13:36'),
(3, 'customer', 'Buyer who can purchase products', '2026-04-14 16:13:36');

-- --------------------------------------------------------

--
-- Table structure for table `seller_profiles`
--

CREATE TABLE `seller_profiles` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `shop_name` varchar(150) DEFAULT NULL,
  `shop_description` text DEFAULT NULL,
  `shop_logo` varchar(255) DEFAULT NULL,
  `shop_banner` varchar(255) DEFAULT NULL,
  `speciality` varchar(255) DEFAULT NULL,
  `years_experience` int(11) DEFAULT 0,
  `total_sales` int(11) DEFAULT 0,
  `rating` decimal(3,2) DEFAULT 0.00,
  `bank_name` varchar(100) DEFAULT NULL,
  `account_number` varchar(50) DEFAULT NULL,
  `ifsc_code` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `seller_profiles`
--

INSERT INTO `seller_profiles` (`id`, `user_id`, `shop_name`, `shop_description`, `shop_logo`, `shop_banner`, `speciality`, `years_experience`, `total_sales`, `rating`, `bank_name`, `account_number`, `ifsc_code`, `created_at`) VALUES
(1, 2, 'Priya Art Studio', 'We create beautiful traditional Indian art and handicrafts. Each piece is made with love and skill.', NULL, NULL, 'Paintings, Pottery', 8, 245, 4.80, NULL, NULL, NULL, '2026-04-14 16:13:42'),
(2, 4, 'Meena Crafts', 'Authentic handmade jewelry and home decor from the heart of Rajasthan.', NULL, NULL, 'Jewelry, Home Decor', 12, 389, 4.90, NULL, NULL, NULL, '2026-04-14 16:13:42');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL DEFAULT 3,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `avatar` varchar(255) DEFAULT 'default.png',
  `bio` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `is_verified` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `role_id`, `name`, `email`, `password`, `phone`, `address`, `avatar`, `bio`, `is_active`, `is_verified`, `created_at`, `updated_at`) VALUES
(1, 1, 'Admin User', 'admin@craftstore.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '9876543210', 'Platform HQ, Mumbai', 'default.png', NULL, 1, 1, '2026-04-14 16:13:36', '2026-04-14 16:13:36'),
(2, 2, 'Priya Sharma', 'seller@craftstore.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '9876543211', 'Jaipur, Rajasthan', 'default.png', NULL, 1, 1, '2026-04-14 16:13:36', '2026-04-14 16:39:39'),
(3, 3, 'Rahul Kumar', 'customer@craftstore.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '9876543212', 'Bangalore, Karnataka', 'default.png', NULL, 1, 1, '2026-04-14 16:13:36', '2026-04-14 16:39:58'),
(4, 2, 'Meena Arts', 'meena@craftstore.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '9876543213', 'Kolkata, West Bengal', 'default.png', NULL, 1, 1, '2026-04-14 16:13:36', '2026-04-14 16:13:36'),
(5, 3, 'Anjali Singh', 'anjali@craftstore.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '9876543214', 'Delhi, India', 'default.png', NULL, 1, 1, '2026-04-14 16:13:36', '2026-04-14 16:13:36'),
(12, 3, 'mama', 'mama@gmail.com', '$2y$10$xP2UpQF1TpGZXZJvr0z2c.7izzI0rbKArbrT3/32/Fwq2OD0sOMUG', '7894561232', 'guntur', 'default.png', NULL, 1, 0, '2026-04-14 18:02:29', '2026-04-14 18:02:29');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_cart_item` (`user_id`,`product_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`),
  ADD KEY `idx_slug` (`slug`);

--
-- Indexes for table `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_is_read` (`is_read`);

--
-- Indexes for table `coupons`
--
ALTER TABLE `coupons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_read` (`user_id`,`is_read`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `order_number` (`order_number`),
  ADD KEY `idx_user` (`user_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_order_number` (`order_number`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `seller_id` (`seller_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`),
  ADD KEY `idx_seller` (`seller_id`),
  ADD KEY `idx_category` (`category_id`),
  ADD KEY `idx_status` (`status`);
ALTER TABLE `products` ADD FULLTEXT KEY `idx_search` (`name`,`description`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_review` (`product_id`,`user_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `seller_profiles`
--
ALTER TABLE `seller_profiles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_email` (`email`),
  ADD KEY `idx_role` (`role_id`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_wishlist` (`user_id`,`product_id`),
  ADD KEY `product_id` (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `contact_messages`
--
ALTER TABLE `contact_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `coupons`
--
ALTER TABLE `coupons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `seller_profiles`
--
ALTER TABLE `seller_profiles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `order_items_ibfk_3` FOREIGN KEY (`seller_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`seller_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `products_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `seller_profiles`
--
ALTER TABLE `seller_profiles`
  ADD CONSTRAINT `seller_profiles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);

--
-- Constraints for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD CONSTRAINT `wishlist_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `wishlist_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
