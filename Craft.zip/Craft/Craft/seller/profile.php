<?php
require_once '../includes/auth.php';
require_role('seller');
$uid = get_user_id();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name       = sanitize($_POST['name'] ?? '');
    $phone      = sanitize($_POST['phone'] ?? '');
    $address    = sanitize($_POST['address'] ?? '');
    
    $shop_name  = sanitize($_POST['shop_name'] ?? '');
    $shop_desc  = sanitize($_POST['shop_description'] ?? '');
    $speciality = sanitize($_POST['speciality'] ?? '');
    $bank_name  = sanitize($_POST['bank_name'] ?? '');
    $acct_num   = sanitize($_POST['account_number'] ?? '');
    $ifsc_code  = sanitize($_POST['ifsc_code'] ?? '');

    if ($name) {
        // Update generic user data
        db_query("UPDATE users SET name=?, phone=?, address=?, updated_at=NOW() WHERE id=?", [$name, $phone, $address, $uid]);
        $_SESSION['user_name'] = $name;
        
        // Update seller profile
        db_query("UPDATE seller_profiles SET shop_name=?, shop_description=?, speciality=?, bank_name=?, account_number=?, ifsc_code=? WHERE user_id=?", 
                 [$shop_name, $shop_desc, $speciality, $bank_name, $acct_num, $ifsc_code, $uid]);
        
        // Handle password update if provided
        if (!empty($_POST['password'])) {
            if (strlen($_POST['password']) >= 6 && $_POST['password'] === $_POST['confirm_password']) {
                db_query("UPDATE users SET password=? WHERE id=?", [password_hash($_POST['password'], PASSWORD_DEFAULT), $uid]);
            }
        }
        redirect_with_message('/Craft/seller/profile.php', 'Shop & Profile updated successfully!', 'success');
    }
}

$user = get_current_user_data();
$seller = db_fetch("SELECT * FROM seller_profiles WHERE user_id=?", [$uid]);
$flash = get_flash_message();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Shop Profile – Seller | CraftStore</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/main.css">
</head>
<body>
<div class="dashboard-layout">
    <?php include '../includes/sidebar.php'; ?>
    <div class="dashboard-main">
        <div class="dashboard-topbar">
            <div style="display:flex;align-items:center;gap:1rem">
                <button class="btn btn-ghost btn-icon" id="sidebarOpenBtn"><i class="fas fa-bars"></i></button>
                <h1 class="topbar-title">Shop Profile</h1>
            </div>
            <div class="topbar-actions"><button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button></div>
        </div>
        <div class="dashboard-content">
            <?php if ($flash): ?>
            <div style="background:rgba(16,185,129,0.08);border:1px solid rgba(16,185,129,0.25);border-radius:10px;padding:1rem;margin-bottom:1.25rem;color:var(--accent);display:flex;gap:.5rem"><i class="fas fa-check-circle"></i> <?= $flash['message'] ?></div>
            <?php endif; ?>

            <div style="display:grid;grid-template-columns:280px 1fr;gap:1.5rem;align-items:start">
                <!-- Personal Info Sidebar -->
                <div style="background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);padding:2rem;text-align:center;position:sticky;top:calc(var(--nav-h) + 1rem)">
                    <div style="width:90px;height:90px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--secondary));display:flex;align-items:center;justify-content:center;font-size:2.2rem;font-weight:900;color:white;margin:0 auto 1.25rem">
                        <?= strtoupper(substr($user['name'],0,1)) ?>
                    </div>
                    <h2 style="font-size:1.15rem;font-weight:800;margin-bottom:.25rem"><?= htmlspecialchars($seller['shop_name'] ?: $user['name']) ?></h2>
                    <p style="font-size:.82rem;color:var(--text-muted);margin-bottom:.75rem"><?= htmlspecialchars($user['email']) ?></p>
                    <span class="role-badge <?= $user['role_name'] ?>" style="font-size:.78rem">Verified <?= ucfirst($user['role_name']) ?></span>
                    
                    <div style="margin-top:1.5rem;padding-top:1.25rem;border-top:1px solid var(--border)">
                        <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;text-align:left;margin-bottom:1.5rem">
                            <div>
                                <p style="font-size:.75rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.05em">Sales</p>
                                <p style="font-size:1.1rem;font-weight:800;color:var(--text)"><?= $seller['total_sales'] ?? 0 ?></p>
                            </div>
                            <div>
                                <p style="font-size:.75rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.05em">Rating</p>
                                <p style="font-size:1.1rem;font-weight:800;color:var(--text)"><i class="fas fa-star" style="color:#F59E0B;font-size:.9rem;margin-right:.2rem"></i><?= $seller['rating'] > 0 ? $seller['rating'] : 'N/A' ?></p>
                            </div>
                        </div>
                        <?php if ($user['phone']): ?>
                        <p style="font-size:.82rem;color:var(--text-muted);display:flex;align-items:center;gap:.4rem;justify-content:center;margin-bottom:.4rem">
                            <i class="fas fa-phone"></i> <?= htmlspecialchars($user['phone']) ?>
                        </p>
                        <?php endif; ?>
                        <p style="font-size:.78rem;color:var(--text-muted)">Selling since <?= date('M Y', strtotime($user['created_at'])) ?></p>
                    </div>
                </div>

                <!-- Forms Area -->
                <div>
                    <form method="POST">
                        <div style="background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);padding:2rem;margin-bottom:1.5rem">
                            <h3 style="font-size:1.1rem;font-weight:700;margin-bottom:1.5rem;display:flex;align-items:center;gap:.5rem"><i class="fas fa-store" style="color:var(--primary)"></i> Shop Details</h3>
                            
                            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem">
                                <div class="form-group">
                                    <label class="form-label">Shop Name *</label>
                                    <input type="text" name="shop_name" class="form-control" value="<?= htmlspecialchars($seller['shop_name'] ?? '') ?>" placeholder="e.g. Dreamy Crafts Store" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Speciality</label>
                                    <input type="text" name="speciality" class="form-control" value="<?= htmlspecialchars($seller['speciality'] ?? '') ?>" placeholder="e.g. Handwoven Textiles, Pottery">
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">Shop Description</label>
                                <textarea name="shop_description" class="form-control" rows="4" placeholder="Tell buyers the story behind your crafts..."><?= htmlspecialchars($seller['shop_description'] ?? '') ?></textarea>
                            </div>
                        </div>

                        <div style="background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);padding:2rem;margin-bottom:1.5rem">
                            <h3 style="font-size:1.1rem;font-weight:700;margin-bottom:1.5rem;display:flex;align-items:center;gap:.5rem"><i class="fas fa-user-circle" style="color:var(--secondary)"></i> Personal Details</h3>
                            
                            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem">
                                <div class="form-group">
                                    <label class="form-label">Full Name *</label>
                                    <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($user['name']) ?>" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Phone Label</label>
                                    <input type="tel" name="phone" class="form-control" value="<?= htmlspecialchars($user['phone'] ?? '') ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Address</label>
                                <textarea name="address" class="form-control" rows="2" placeholder="Your operating address"><?= htmlspecialchars($user['address'] ?? '') ?></textarea>
                            </div>
                        </div>

                        <div style="background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);padding:2rem;margin-bottom:1.5rem">
                            <h3 style="font-size:1.1rem;font-weight:700;margin-bottom:1.5rem;display:flex;align-items:center;gap:.5rem"><i class="fas fa-landmark" style="color:var(--accent)"></i> Payment Details</h3>
                            <p style="font-size:.85rem;color:var(--text-muted);margin-bottom:1.25rem">We use these details to transfer your earnings every week.</p>
                            
                            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem">
                                <div class="form-group">
                                    <label class="form-label">Bank Name</label>
                                    <input type="text" name="bank_name" class="form-control" value="<?= htmlspecialchars($seller['bank_name'] ?? '') ?>" placeholder="e.g. State Bank of India">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">IFSC Code</label>
                                    <input type="text" name="ifsc_code" class="form-control" value="<?= htmlspecialchars($seller['ifsc_code'] ?? '') ?>" placeholder="e.g. SBIN0001234">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Account Number</label>
                                <input type="text" name="account_number" class="form-control" value="<?= htmlspecialchars($seller['account_number'] ?? '') ?>">
                            </div>
                        </div>
                        
                        <div style="background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);padding:2rem;margin-bottom:1.5rem">
                            <h3 style="font-size:1.1rem;font-weight:700;margin-bottom:1.5rem;display:flex;align-items:center;gap:.5rem"><i class="fas fa-lock" style="color:var(--danger)"></i> Security</h3>
                            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem">
                                <div class="form-group">
                                    <label class="form-label">New Password</label>
                                    <input type="password" name="password" class="form-control" placeholder="Leave blank to keep current">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Confirm Password</label>
                                    <input type="password" name="confirm_password" class="form-control" placeholder="Repeat new password">
                                </div>
                            </div>
                        </div>

                        <div style="display:flex;gap:1rem;margin-top:1.25rem">
                            <button type="submit" class="btn btn-primary btn-lg" style="flex:1"><i class="fas fa-save"></i> Save All Changes</button>
                            <a href="/Craft/<?= get_role() ?>/index.php" class="btn btn-ghost btn-lg"><i class="fas fa-arrow-left"></i> Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
            
        </div>
    </div>
</div>
<div id="sidebarOverlay" style="position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:850;display:none" onclick="document.getElementById('dashboardSidebar').classList.remove('open');this.style.display='none'"></div>
<script>document.getElementById('sidebarOpenBtn')?.addEventListener('click', function() { document.getElementById('dashboardSidebar').classList.toggle('open'); document.getElementById('sidebarOverlay').style.display = document.getElementById('dashboardSidebar').classList.contains('open') ? 'block' : 'none'; });</script>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body></html>
