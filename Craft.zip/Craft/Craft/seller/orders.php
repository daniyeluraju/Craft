<?php
require_once '../includes/auth.php';
require_role('seller');
$uid = get_user_id();

$orders = db_fetch_all("
    SELECT oi.*, o.order_number, o.status as order_status, o.created_at,
           u.name as customer_name, o.shipping_city, o.shipping_state
    FROM order_items oi
    JOIN orders o ON o.id=oi.order_id
    JOIN users u ON u.id=o.user_id
    WHERE oi.seller_id=?
    ORDER BY o.created_at DESC
", [$uid]);

// Handle status update
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $item_id = intval($_POST['item_id'] ?? 0);
    $status  = sanitize($_POST['status'] ?? '');
    if ($item_id && $status) {
        db_query("UPDATE order_items SET status=? WHERE id=? AND seller_id=?", [$status, $item_id, $uid]);
    }
    redirect_with_message('/Craft/seller/orders.php', 'Order status updated!', 'success');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Orders – Seller | CraftStore</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/main.css">
</head>
<body>
<div class="dashboard-layout">
    <?php include '../includes/sidebar.php'; ?>
    <div class="dashboard-main">
        <div class="dashboard-topbar">
            <div style="display:flex;align-items:center;gap:1rem">
                <button class="btn btn-ghost btn-icon" id="sidebarOpenBtn"><i class="fas fa-bars"></i></button>
                <h1 class="topbar-title">My Orders</h1>
            </div>
            <div class="topbar-actions"><button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button></div>
        </div>
        <div class="dashboard-content">
            <?php $flash = get_flash_message(); if ($flash): ?>
            <div style="background:rgba(16,185,129,0.08);border:1px solid rgba(16,185,129,0.25);border-radius:10px;padding:1rem;margin-bottom:1.25rem;color:var(--accent);display:flex;gap:.5rem"><i class="fas fa-check-circle"></i> <?= $flash['message'] ?></div>
            <?php endif; ?>

            <?php if (empty($orders)): ?>
            <div class="empty-state"><div class="empty-icon"><i class="fas fa-box-open"></i></div><h3 class="empty-title">No orders yet</h3><p class="empty-subtitle">Orders for your products will appear here</p></div>
            <?php else: ?>
            <div class="table-wrapper">
                <table class="data-table">
                    <thead><tr><th>Order #</th><th>Product</th><th>Customer</th><th>Location</th><th>Qty</th><th>Amount</th><th>Status</th><th>Update</th></tr></thead>
                    <tbody>
                    <?php foreach($orders as $o): ?>
                    <tr>
                        <td style="font-weight:700;color:var(--primary);font-size:.82rem"><?= $o['order_number'] ?></td>
                        <td style="font-size:.85rem"><?= htmlspecialchars(substr($o['product_name'],0,28)) ?></td>
                        <td style="font-size:.85rem"><?= htmlspecialchars($o['customer_name']) ?></td>
                        <td style="font-size:.78rem;color:var(--text-muted)"><?= htmlspecialchars($o['shipping_city']) ?>, <?= htmlspecialchars($o['shipping_state']) ?></td>
                        <td style="font-weight:600"><?= $o['quantity'] ?></td>
                        <td style="font-weight:800;color:var(--primary)">₹<?= number_format($o['subtotal']) ?></td>
                        <td><span class="status-badge status-<?= $o['status'] ?>"><?= ucfirst($o['status']) ?></span></td>
                        <td>
                            <form method="POST" style="display:flex;gap:.3rem">
                                <input type="hidden" name="item_id" value="<?= $o['id'] ?>">
                                <select name="status" class="sort-select" style="font-size:.78rem;padding:.3rem .5rem" onchange="this.form.submit()">
                                    <?php foreach(['pending','processing','shipped','delivered'] as $s): ?>
                                    <option value="<?= $s ?>" <?= $o['status']===$s?'selected':'' ?>><?= ucfirst($s) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<div id="sidebarOverlay" style="position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:850;display:none" onclick="document.getElementById('dashboardSidebar').classList.remove('open');this.style.display='none'"></div>
<script>document.getElementById('sidebarOpenBtn')?.addEventListener('click', function() { document.getElementById('dashboardSidebar').classList.toggle('open'); document.getElementById('sidebarOverlay').style.display = document.getElementById('dashboardSidebar').classList.contains('open') ? 'block' : 'none'; });</script>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body></html>
