<?php
require_once '../includes/auth.php';
require_role('seller');
$uid = get_user_id();

if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $pid = intval($_POST['pid']);
    try {
        global $pdo;
        $pdo->exec('SET FOREIGN_KEY_CHECKS=0');
        $pdo->exec("DELETE FROM reviews     WHERE product_id=$pid");
        $pdo->exec("DELETE FROM cart        WHERE product_id=$pid");
        $pdo->exec("DELETE FROM wishlist    WHERE product_id=$pid");
        $pdo->exec("DELETE FROM order_items WHERE product_id=$pid");
        $pdo->exec("DELETE FROM products    WHERE id=$pid AND seller_id=$uid");
        $pdo->exec('SET FOREIGN_KEY_CHECKS=1');
        redirect_with_message('/Craft/seller/products.php', 'Product deleted successfully.', 'success');
    } catch (Exception $e) {
        $pdo->exec('SET FOREIGN_KEY_CHECKS=1');
        redirect_with_message('/Craft/seller/products.php', 'Delete failed: ' . $e->getMessage(), 'error');
    }
}

$products = db_fetch_all("SELECT p.*, c.name as cat_name FROM products p JOIN categories c ON p.category_id=c.id WHERE p.seller_id=? ORDER BY p.created_at DESC", [$uid]);
$flash = get_flash_message();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Products – Seller | CraftStore</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/main.css">
<style>
  .del-confirm-row { display:none; background:rgba(239,68,68,.06); border-top:1px solid rgba(239,68,68,.2) }
  .del-confirm-row.show { display:table-row }
  .del-confirm-cell { padding:.75rem 1rem!important }
</style>
</head>
<body>
<div class="dashboard-layout">
    <?php include '../includes/sidebar.php'; ?>
    <div class="dashboard-main">
        <div class="dashboard-topbar">
            <div style="display:flex;align-items:center;gap:1rem">
                <button class="btn btn-ghost btn-icon" id="sidebarOpenBtn"><i class="fas fa-bars"></i></button>
                <h1 class="topbar-title">My Products</h1>
            </div>
            <div class="topbar-actions">
                <a href="/Craft/seller/add-product.php" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Add Product</a>
                <button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button>
            </div>
        </div>
        <div class="dashboard-content">
            <?php if ($flash): ?>
            <div style="background:rgba(<?= $flash['type']==='success'?'16,185,129':'239,68,68' ?>,0.08);border:1px solid rgba(<?= $flash['type']==='success'?'16,185,129':'239,68,68' ?>,0.25);border-radius:10px;padding:1rem;margin-bottom:1.25rem;color:var(--<?= $flash['type']==='success'?'accent':'danger' ?>);display:flex;align-items:center;gap:.5rem"><i class="fas fa-<?= $flash['type']==='success'?'check':'exclamation' ?>-circle"></i> <?= $flash['message'] ?></div>
            <?php endif; ?>

            <?php if (empty($products)): ?>
            <div class="empty-state">
                <div class="empty-icon"><i class="fas fa-store"></i></div>
                <h3 class="empty-title">No Products Yet</h3>
                <p class="empty-subtitle">Start listing your handcrafted products to reach buyers across India</p>
                <a href="/Craft/seller/add-product.php" class="btn btn-primary btn-lg"><i class="fas fa-plus"></i> Add Your First Product</a>
            </div>
            <?php else: ?>
            <div class="table-wrapper">
                <table class="data-table" id="productsTable">
                    <thead><tr><th>Product</th><th>Category</th><th>Price</th><th>Stock</th><th>Views</th><th>Status</th><th>Actions</th></tr></thead>
                    <tbody>
                    <?php foreach($products as $p): $dp = $p['sale_price'] ?? $p['price']; ?>
                    <!-- Main Row -->
                    <tr>
                        <td>
                            <div style="display:flex;align-items:center;gap:.75rem">
                                <div style="width:44px;height:44px;border-radius:10px;background:rgba(124,58,237,0.1);display:flex;align-items:center;justify-content:center;flex-shrink:0;overflow:hidden">
                                    <?php if (!empty($p['featured_image'])): ?>
                                    <img src="<?= SITE_URL . '/assets/uploads' . $p['featured_image'] ?>" alt="" style="width:100%;height:100%;object-fit:cover;">
                                    <?php else: ?>
                                    <img src="<?= SITE_URL ?>/assets/img/default-product.svg" alt="" style="width:100%;height:100%;object-fit:cover;">
                                    <?php endif; ?>
                                </div>
                                <div>
                                    <p style="font-weight:600;font-size:.88rem"><?= htmlspecialchars(substr($p['name'],0,32)) ?></p>
                                    <p style="font-size:.72rem;color:var(--text-muted)"><?= date('d M Y', strtotime($p['created_at'])) ?></p>
                                </div>
                            </div>
                        </td>
                        <td style="font-size:.85rem"><?= htmlspecialchars($p['cat_name']) ?></td>
                        <td>
                            <strong style="color:var(--primary)">₹<?= number_format($dp) ?></strong>
                            <?php if ($p['sale_price']): ?><br><small style="color:var(--text-muted);text-decoration:line-through">₹<?= number_format($p['price']) ?></small><?php endif; ?>
                        </td>
                        <td><span style="font-weight:600;color:<?= $p['stock']>0?'var(--accent)':'var(--danger)' ?>"><?= $p['stock'] ?></span></td>
                        <td style="font-size:.85rem;color:var(--text-muted)"><i class="fas fa-eye" style="font-size:.7rem"></i> <?= number_format($p['views']) ?></td>
                        <td><span class="status-badge status-<?= $p['status'] ?>"><?= ucfirst($p['status']) ?></span></td>
                        <td>
                            <div style="display:flex;gap:.35rem">
                                <a href="<?= SITE_URL ?>/public/product.php?id=<?= $p['id'] ?>" target="_blank" class="btn btn-ghost btn-sm btn-icon" title="View"><i class="fas fa-eye"></i></a>
                                <a href="/Craft/seller/edit-product.php?id=<?= $p['id'] ?>" class="btn btn-ghost btn-sm btn-icon" title="Edit"><i class="fas fa-edit"></i></a>
                                <button type="button" class="btn btn-danger btn-sm btn-icon" title="Delete" onclick="showDelRow(<?= $p['id'] ?>)">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                    <!-- Confirm Row -->
                    <tr class="del-confirm-row" id="del-row-<?= $p['id'] ?>">
                        <td class="del-confirm-cell" colspan="7">
                            <div style="display:flex;align-items:center;gap:1rem">
                                <i class="fas fa-exclamation-triangle" style="color:var(--danger)"></i>
                                <span style="font-size:.88rem;font-weight:600">Delete <strong><?= htmlspecialchars($p['name']) ?></strong> forever?</span>
                                <form method="POST" style="display:inline">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="pid" value="<?= $p['id'] ?>">
                                    <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i> Yes, Delete</button>
                                </form>
                                <button type="button" class="btn btn-ghost btn-sm" onclick="hideDelRow(<?= $p['id'] ?>)">Cancel</button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<div id="sidebarOverlay" style="position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:850;display:none" onclick="document.getElementById('dashboardSidebar').classList.remove('open');this.style.display='none'"></div>
<script>
document.getElementById('sidebarOpenBtn')?.addEventListener('click', function() { document.getElementById('dashboardSidebar').classList.toggle('open'); document.getElementById('sidebarOverlay').style.display = document.getElementById('dashboardSidebar').classList.contains('open') ? 'block' : 'none'; });

function showDelRow(pid) {
    document.querySelectorAll('.del-confirm-row.show').forEach(el => el.classList.remove('show'));
    document.getElementById('del-row-' + pid).classList.add('show');
}
function hideDelRow(pid) {
    document.getElementById('del-row-' + pid).classList.remove('show');
}
</script>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body></html>
