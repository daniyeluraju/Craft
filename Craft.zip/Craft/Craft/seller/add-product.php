<?php
require_once '../includes/auth.php';
require_role('seller');

$uid = get_user_id();
$categories = db_fetch_all("SELECT * FROM categories WHERE is_active=1");
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name        = sanitize($_POST['name'] ?? '');
    $cat_id      = intval($_POST['category_id'] ?? 0);
    $price       = floatval($_POST['price'] ?? 0);
    $sale_price  = $_POST['sale_price'] ? floatval($_POST['sale_price']) : null;
    $stock       = intval($_POST['stock'] ?? 0);
    $description = sanitize($_POST['description'] ?? '');
    $sku         = sanitize($_POST['sku'] ?? '');
    $is_featured = isset($_POST['is_featured']) ? 1 : 0;

    if (!$name || !$cat_id || !$price || !$stock) {
        $error = 'Please fill in all required fields.';
    } else {
        $slug = strtolower(preg_replace('/[^a-zA-Z0-9]+/', '-', $name)) . '-' . time();
        
        $image_paths = [];
        if (!empty($_FILES['images']['name'][0])) {
            $upload_dir = rtrim(UPLOAD_DIR, '/') . '/products/';
            if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
            foreach ($_FILES['images']['name'] as $i => $filename) {
                if ($_FILES['images']['error'][$i] === UPLOAD_ERR_OK) {
                    $ext = pathinfo($filename, PATHINFO_EXTENSION);
                    $new_name = uniqid('prod_') . '.' . $ext;
                    if (move_uploaded_file($_FILES['images']['tmp_name'][$i], $upload_dir . $new_name)) {
                        $image_paths[] = '/products/' . $new_name;
                    }
                }
            }
        }
        $featured_img = !empty($image_paths) ? $image_paths[0] : null;
        $images_json = !empty($image_paths) ? json_encode($image_paths) : null;

        db_query(
            "INSERT INTO products (seller_id,category_id,name,slug,description,price,sale_price,stock,sku,is_featured,status,images,featured_image) VALUES (?,?,?,?,?,?,?,?,?,?,'pending',?,?)",
            [$uid, $cat_id, $name, $slug, $description, $price, $sale_price, $stock, $sku, $is_featured, $images_json, $featured_img]
        );
        redirect_with_message('/Craft/seller/products.php', 'Product submitted for approval! 🎉', 'success');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Product – Seller | CraftStore</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/main.css">
</head>
<body>
<div class="dashboard-layout">
    <?php include '../includes/sidebar.php'; ?>
    <div class="dashboard-main">
        <div class="dashboard-topbar">
            <div style="display:flex;align-items:center;gap:1rem">
                <button class="btn btn-ghost btn-icon" id="sidebarOpenBtn"><i class="fas fa-bars"></i></button>
                <h1 class="topbar-title">Add New Product</h1>
            </div>
            <div class="topbar-actions">
                <a href="/Craft/seller/products.php" class="btn btn-ghost btn-sm"><i class="fas fa-arrow-left"></i> My Products</a>
                <button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button>
            </div>
        </div>
        <div class="dashboard-content">
            <?php if ($error): ?>
            <div style="background:rgba(239,68,68,0.08);border:1px solid rgba(239,68,68,0.25);border-radius:10px;padding:1rem;margin-bottom:1.25rem;color:var(--danger);display:flex;align-items:center;gap:.5rem"><i class="fas fa-exclamation-circle"></i> <?= $error ?></div>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data">
                <div style="display:grid;grid-template-columns:2fr 1fr;gap:1.5rem">
                    <!-- Left side -->
                    <div>
                        <div style="background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);padding:1.75rem;margin-bottom:1.25rem">
                            <h3 style="font-size:1rem;font-weight:700;margin-bottom:1.25rem;padding-bottom:.75rem;border-bottom:1px solid var(--border)"><i class="fas fa-info-circle" style="color:var(--primary);margin-right:.4rem"></i>Product Information</h3>
                            
                            <div class="form-group">
                                <label class="form-label" for="prod_name">Product Name *</label>
                                <input type="text" name="name" id="prod_name" class="form-control" placeholder="e.g. Handpainted Madhubani Canvas" required value="<?= htmlspecialchars($_POST['name'] ?? '') ?>">
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label" for="prod_cat">Category *</label>
                                <select name="category_id" id="prod_cat" class="form-control" required>
                                    <option value="">Select Category</option>
                                    <?php foreach($categories as $cat): ?>
                                    <option value="<?= $cat['id'] ?>" <?= ($_POST['category_id'] ?? '') == $cat['id'] ? 'selected' : '' ?>><?= htmlspecialchars($cat['name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label" for="prod_desc">Description</label>
                                <textarea name="description" id="prod_desc" class="form-control" rows="5" placeholder="Describe your product in detail..."><?= htmlspecialchars($_POST['description'] ?? '') ?></textarea>
                            </div>
                        </div>

                        <div style="background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);padding:1.75rem;margin-bottom:1.25rem">
                            <h3 style="font-size:1rem;font-weight:700;margin-bottom:1.25rem;padding-bottom:.75rem;border-bottom:1px solid var(--border)"><i class="fas fa-image" style="color:var(--secondary);margin-right:.4rem"></i>Product Image</h3>
                            <div id="imageDropZone" style="position:relative;border:2px dashed var(--border);border-radius:var(--radius-md);padding:2.5rem;text-align:center;cursor:pointer;transition:var(--transition)" ondragover="this.style.borderColor='var(--primary)'" ondragleave="this.style.borderColor='var(--border)'">
                                <i class="fas fa-cloud-upload-alt" style="font-size:2.5rem;color:var(--text-muted);margin-bottom:1rem;display:block"></i>
                                <p style="font-weight:600;margin-bottom:.4rem">Drop images here or click to upload</p>
                                <p style="font-size:.82rem;color:var(--text-muted)">PNG, JPG, WEBP – Max 5MB each</p>
                                <input type="file" name="images[]" id="imageInput" multiple accept="image/*" style="position:absolute;opacity:0;inset:0;cursor:pointer">
                            </div>
                            <div id="imagePreview" style="display:flex;gap:.5rem;flex-wrap:wrap;margin-top:.75rem"></div>
                        </div>
                    </div>

                    <!-- Right side -->
                    <div>
                        <div style="background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);padding:1.75rem;margin-bottom:1.25rem">
                            <h3 style="font-size:1rem;font-weight:700;margin-bottom:1.25rem;padding-bottom:.75rem;border-bottom:1px solid var(--border)"><i class="fas fa-rupee-sign" style="color:var(--accent);margin-right:.4rem"></i>Pricing & Inventory</h3>
                            
                            <div class="form-group">
                                <label class="form-label" for="prod_price">Original Price (₹) *</label>
                                <input type="number" name="price" id="prod_price" class="form-control" placeholder="0.00" min="1" step="0.01" required value="<?= htmlspecialchars($_POST['price'] ?? '') ?>">
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label" for="prod_sale">Sale Price (₹)</label>
                                <input type="number" name="sale_price" id="prod_sale" class="form-control" placeholder="Leave blank if no discount" min="0" step="0.01" value="<?= htmlspecialchars($_POST['sale_price'] ?? '') ?>">
                                <p class="form-hint">Must be less than original price</p>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label" for="prod_stock">Stock Quantity *</label>
                                <input type="number" name="stock" id="prod_stock" class="form-control" placeholder="Available units" min="0" required value="<?= htmlspecialchars($_POST['stock'] ?? '') ?>">
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label" for="prod_sku">SKU / Product Code</label>
                                <input type="text" name="sku" id="prod_sku" class="form-control" placeholder="e.g. ART-KR-001" value="<?= htmlspecialchars($_POST['sku'] ?? '') ?>">
                            </div>
                        </div>

                        <div style="background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);padding:1.75rem;margin-bottom:1.25rem">
                            <h3 style="font-size:1rem;font-weight:700;margin-bottom:1rem;padding-bottom:.75rem;border-bottom:1px solid var(--border)"><i class="fas fa-cog" style="color:var(--info);margin-right:.4rem"></i>Product Settings</h3>
                            <label style="display:flex;align-items:center;gap:.6rem;cursor:pointer;padding:.75rem;border-radius:10px;transition:var(--transition)" onmouseover="this.style.background='var(--surface-2)'" onmouseout="this.style.background=''">
                                <input type="checkbox" name="is_featured" value="1" style="accent-color:var(--primary);width:18px;height:18px">
                                <div>
                                    <p style="font-weight:600;font-size:.88rem">Mark as Featured</p>
                                    <p style="font-size:.75rem;color:var(--text-muted)">Show in featured products section</p>
                                </div>
                            </label>
                        </div>

                        <!-- Price preview -->
                        <div id="pricePreview" style="background:linear-gradient(135deg,rgba(124,58,237,0.08),rgba(16,185,129,0.05));border:1px solid var(--border);border-radius:var(--radius-md);padding:1.25rem;margin-bottom:1.25rem;display:none">
                            <p style="font-size:.75rem;text-transform:uppercase;letter-spacing:.06em;color:var(--text-muted);margin-bottom:.5rem">Price Preview</p>
                            <p style="font-size:1.4rem;font-weight:900;color:var(--primary)" id="previewSalePrice"></p>
                            <p style="font-size:.88rem;color:var(--text-muted);text-decoration:line-through" id="previewOriginalPrice"></p>
                            <p style="font-size:.8rem;font-weight:700;color:var(--accent)" id="previewDiscount"></p>
                        </div>

                        <button type="submit" class="btn btn-primary btn-lg w-full">
                            <i class="fas fa-paper-plane"></i> Submit for Approval
                        </button>
                        <p style="font-size:.78rem;color:var(--text-muted);text-align:center;margin-top:.5rem">Your product will be reviewed by our team before going live</p>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<div id="sidebarOverlay" style="position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:850;display:none" onclick="document.getElementById('dashboardSidebar').classList.remove('open');this.style.display='none'"></div>
<script>
document.getElementById('sidebarOpenBtn')?.addEventListener('click', function() {
    document.getElementById('dashboardSidebar').classList.toggle('open');
    document.getElementById('sidebarOverlay').style.display = document.getElementById('dashboardSidebar').classList.contains('open') ? 'block' : 'none';
});

// Price preview
function updatePricePreview() {
    const price = parseFloat(document.getElementById('prod_price').value) || 0;
    const sale  = parseFloat(document.getElementById('prod_sale').value) || 0;
    const preview = document.getElementById('pricePreview');
    if (price > 0) {
        preview.style.display = 'block';
        document.getElementById('previewSalePrice').textContent = '₹' + (sale > 0 ? sale : price).toLocaleString('en-IN');
        document.getElementById('previewOriginalPrice').textContent = sale > 0 ? '₹' + price.toLocaleString('en-IN') : '';
        document.getElementById('previewDiscount').textContent = sale > 0 && sale < price ? Math.round(((price-sale)/price)*100) + '% OFF' : '';
    } else {
        preview.style.display = 'none';
    }
}
document.getElementById('prod_price')?.addEventListener('input', updatePricePreview);
document.getElementById('prod_sale')?.addEventListener('input', updatePricePreview);

// Image preview
document.getElementById('imageInput')?.addEventListener('change', function() {
    const preview = document.getElementById('imagePreview');
    preview.innerHTML = '';
    Array.from(this.files).forEach(file => {
        const reader = new FileReader();
        reader.onload = e => {
            const img = document.createElement('img');
            img.src = e.target.result;
            img.style.cssText = 'width:80px;height:80px;object-fit:cover;border-radius:10px;border:2px solid var(--border)';
            preview.appendChild(img);
        };
        reader.readAsDataURL(file);
    });
});
</script>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body></html>
