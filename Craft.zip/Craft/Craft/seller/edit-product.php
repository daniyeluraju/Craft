<?php
require_once '../includes/auth.php';
require_role('seller');

$uid = get_user_id();
$pid = intval($_GET['id'] ?? 0);
$categories = db_fetch_all("SELECT * FROM categories WHERE is_active=1");
$error = '';

$product = db_fetch("SELECT * FROM products WHERE id=? AND seller_id=?", [$pid, $uid]);
if (!$product) {
    die("<div style='padding:2rem;text-align:center;font-family:sans-serif'><h2>Product not found or access denied.</h2><a href='/Craft/seller/products.php'>Back to My Products</a></div>");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name        = sanitize($_POST['name'] ?? '');
    $cat_id      = intval($_POST['category_id'] ?? 0);
    $price       = floatval($_POST['price'] ?? 0);
    $sale_price  = !empty($_POST['sale_price']) ? floatval($_POST['sale_price']) : null;
    $stock       = intval($_POST['stock'] ?? 0);
    $description = sanitize($_POST['description'] ?? '');
    $sku         = sanitize($_POST['sku'] ?? '');
    $is_featured = isset($_POST['is_featured']) ? 1 : 0;

    if (!$name || !$cat_id || !$price) {
        $error = 'Please fill in all required fields.';
    } else {
        $image_paths = [];
        if (!empty($_FILES['images']['name'][0])) {
            $upload_dir = rtrim(UPLOAD_DIR, '/') . '/products/';
            if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
            foreach ($_FILES['images']['name'] as $i => $filename) {
                if ($_FILES['images']['error'][$i] === UPLOAD_ERR_OK) {
                    $ext = pathinfo($filename, PATHINFO_EXTENSION);
                    $new_name = uniqid('prod_') . '.' . $ext;
                    if (move_uploaded_file($_FILES['images']['tmp_name'][$i], $upload_dir . $new_name)) {
                        $image_paths[] = '/products/' . $new_name;
                    }
                }
            }
        }
        
        if (!empty($image_paths)) {
            $featured_img = $image_paths[0];
            $images_json = json_encode($image_paths);
            db_query(
                "UPDATE products SET category_id=?, name=?, description=?, price=?, sale_price=?, stock=?, sku=?, is_featured=?, images=?, featured_image=?, updated_at=NOW() WHERE id=? AND seller_id=?",
                [$cat_id, $name, $description, $price, $sale_price, $stock, $sku, $is_featured, $images_json, $featured_img, $pid, $uid]
            );
        } else {
            db_query(
                "UPDATE products SET category_id=?, name=?, description=?, price=?, sale_price=?, stock=?, sku=?, is_featured=?, updated_at=NOW() WHERE id=? AND seller_id=?",
                [$cat_id, $name, $description, $price, $sale_price, $stock, $sku, $is_featured, $pid, $uid]
            );
        }
        redirect_with_message('/Craft/seller/products.php', 'Product updated successfully! 🎉', 'success');
    }
}

// Prefill values
$val_name  = htmlspecialchars($_POST['name'] ?? $product['name']);
$val_cat   = $_POST['category_id'] ?? $product['category_id'];
$val_desc  = htmlspecialchars($_POST['description'] ?? $product['description']);
$val_price = htmlspecialchars($_POST['price'] ?? $product['price']);
$val_sale  = htmlspecialchars($_POST['sale_price'] ?? $product['sale_price']);
$val_stock = htmlspecialchars($_POST['stock'] ?? $product['stock']);
$val_sku   = htmlspecialchars($_POST['sku'] ?? $product['sku']);
$val_feat  = isset($_POST['is_featured']) ? 1 : $product['is_featured'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Product – Seller | CraftStore</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/main.css">
</head>
<body>
<div class="dashboard-layout">
    <?php include '../includes/sidebar.php'; ?>
    <div class="dashboard-main">
        <div class="dashboard-topbar">
            <div style="display:flex;align-items:center;gap:1rem">
                <button class="btn btn-ghost btn-icon" id="sidebarOpenBtn"><i class="fas fa-bars"></i></button>
                <h1 class="topbar-title">Edit Product</h1>
            </div>
            <div class="topbar-actions">
                <a href="/Craft/seller/products.php" class="btn btn-ghost btn-sm"><i class="fas fa-arrow-left"></i> My Products</a>
                <button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button>
            </div>
        </div>
        <div class="dashboard-content">
            <?php if ($error): ?>
            <div style="background:rgba(239,68,68,0.08);border:1px solid rgba(239,68,68,0.25);border-radius:10px;padding:1rem;margin-bottom:1.25rem;color:var(--danger);display:flex;align-items:center;gap:.5rem"><i class="fas fa-exclamation-circle"></i> <?= $error ?></div>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data">
                <div style="display:grid;grid-template-columns:2fr 1fr;gap:1.5rem">
                    <!-- Left side -->
                    <div>
                        <div style="background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);padding:1.75rem;margin-bottom:1.25rem">
                            <h3 style="font-size:1rem;font-weight:700;margin-bottom:1.25rem;padding-bottom:.75rem;border-bottom:1px solid var(--border)"><i class="fas fa-info-circle" style="color:var(--primary);margin-right:.4rem"></i>Product Information</h3>
                            
                            <div class="form-group">
                                <label class="form-label" for="prod_name">Product Name *</label>
                                <input type="text" name="name" id="prod_name" class="form-control" required value="<?= $val_name ?>">
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label" for="prod_cat">Category *</label>
                                <select name="category_id" id="prod_cat" class="form-control" required>
                                    <option value="">Select Category</option>
                                    <?php foreach($categories as $cat): ?>
                                    <option value="<?= $cat['id'] ?>" <?= $val_cat == $cat['id'] ? 'selected' : '' ?>><?= htmlspecialchars($cat['name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label" for="prod_desc">Description</label>
                                <textarea name="description" id="prod_desc" class="form-control" rows="5"><?= $val_desc ?></textarea>
                            </div>
                        </div>

                        <div style="background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);padding:1.75rem;margin-bottom:1.25rem">
                            <h3 style="font-size:1rem;font-weight:700;margin-bottom:1.25rem;padding-bottom:.75rem;border-bottom:1px solid var(--border)"><i class="fas fa-image" style="color:var(--secondary);margin-right:.4rem"></i>Product Image</h3>
                            <div id="imageDropZone" style="position:relative;border:2px dashed var(--border);border-radius:var(--radius-md);padding:2.5rem;text-align:center;cursor:pointer;transition:var(--transition)" ondragover="this.style.borderColor='var(--primary)'" ondragleave="this.style.borderColor='var(--border)'">
                                <i class="fas fa-cloud-upload-alt" style="font-size:2.5rem;color:var(--text-muted);margin-bottom:1rem;display:block"></i>
                                <p style="font-weight:600;margin-bottom:.4rem">Drop images here or click to upload</p>
                                <p style="font-size:.82rem;color:var(--text-muted)">PNG, JPG, WEBP</p>
                                <input type="file" name="images[]" id="imageInput" multiple accept="image/*" style="position:absolute;opacity:0;inset:0;cursor:pointer">
                            </div>
                            <div id="imagePreview" style="display:flex;gap:.5rem;flex-wrap:wrap;margin-top:.75rem"></div>
                        </div>
                    </div>

                    <!-- Right side -->
                    <div>
                        <div style="background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);padding:1.75rem;margin-bottom:1.25rem">
                            <h3 style="font-size:1rem;font-weight:700;margin-bottom:1.25rem;padding-bottom:.75rem;border-bottom:1px solid var(--border)"><i class="fas fa-rupee-sign" style="color:var(--accent);margin-right:.4rem"></i>Pricing & Inventory</h3>
                            
                            <div class="form-group">
                                <label class="form-label" for="prod_price">Original Price (₹) *</label>
                                <input type="number" name="price" id="prod_price" class="form-control" min="1" step="0.01" required value="<?= $val_price ?>">
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label" for="prod_sale">Sale Price (₹)</label>
                                <input type="number" name="sale_price" id="prod_sale" class="form-control" min="0" step="0.01" value="<?= $val_sale ?>">
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label" for="prod_stock">Stock Quantity *</label>
                                <input type="number" name="stock" id="prod_stock" class="form-control" min="0" required value="<?= $val_stock ?>">
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label" for="prod_sku">SKU / Product Code</label>
                                <input type="text" name="sku" id="prod_sku" class="form-control" value="<?= $val_sku ?>">
                            </div>
                        </div>

                        <div style="background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);padding:1.75rem;margin-bottom:1.25rem">
                            <h3 style="font-size:1rem;font-weight:700;margin-bottom:1rem;padding-bottom:.75rem;border-bottom:1px solid var(--border)"><i class="fas fa-cog" style="color:var(--info);margin-right:.4rem"></i>Settings</h3>
                            <label style="display:flex;align-items:center;gap:.6rem;cursor:pointer;padding:.75rem;border-radius:10px;transition:var(--transition)" onmouseover="this.style.background='var(--surface-2)'" onmouseout="this.style.background=''">
                                <input type="checkbox" name="is_featured" value="1" <?= $val_feat ? 'checked' : '' ?> style="accent-color:var(--primary);width:18px;height:18px">
                                <div>
                                    <p style="font-weight:600;font-size:.88rem">Mark as Featured</p>
                                    <p style="font-size:.75rem;color:var(--text-muted)">Show in featured products</p>
                                </div>
                            </label>
                        </div>

                        <!-- Price preview -->
                        <div id="pricePreview" style="background:linear-gradient(135deg,rgba(124,58,237,0.08),rgba(16,185,129,0.05));border:1px solid var(--border);border-radius:var(--radius-md);padding:1.25rem;margin-bottom:1.25rem;display:none">
                            <p style="font-size:.75rem;text-transform:uppercase;letter-spacing:.06em;color:var(--text-muted);margin-bottom:.5rem">Price Preview</p>
                            <p style="font-size:1.4rem;font-weight:900;color:var(--primary)" id="previewSalePrice"></p>
                            <p style="font-size:.88rem;color:var(--text-muted);text-decoration:line-through" id="previewOriginalPrice"></p>
                            <p style="font-size:.8rem;font-weight:700;color:var(--accent)" id="previewDiscount"></p>
                        </div>

                        <button type="submit" class="btn btn-primary btn-lg w-full">
                            <i class="fas fa-save"></i> Save Changes
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<div id="sidebarOverlay" style="position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:850;display:none" onclick="document.getElementById('dashboardSidebar').classList.remove('open');this.style.display='none'"></div>
<script>
document.getElementById('sidebarOpenBtn')?.addEventListener('click', function() {
    document.getElementById('dashboardSidebar').classList.toggle('open');
    document.getElementById('sidebarOverlay').style.display = document.getElementById('dashboardSidebar').classList.contains('open') ? 'block' : 'none';
});

function updatePricePreview() {
    const price = parseFloat(document.getElementById('prod_price').value) || 0;
    const sale  = parseFloat(document.getElementById('prod_sale').value) || 0;
    const preview = document.getElementById('pricePreview');
    if (price > 0) {
        preview.style.display = 'block';
        document.getElementById('previewSalePrice').textContent = '₹' + (sale > 0 ? sale : price).toLocaleString('en-IN');
        document.getElementById('previewOriginalPrice').textContent = sale > 0 ? '₹' + price.toLocaleString('en-IN') : '';
        document.getElementById('previewDiscount').textContent = sale > 0 && sale < price ? Math.round(((price-sale)/price)*100) + '% OFF' : '';
    } else {
        preview.style.display = 'none';
    }
}
document.getElementById('prod_price')?.addEventListener('input', updatePricePreview);
document.getElementById('prod_sale')?.addEventListener('input', updatePricePreview);
updatePricePreview();
</script>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body></html>
