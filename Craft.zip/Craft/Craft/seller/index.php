<?php
require_once '../includes/auth.php';
require_role('seller');

$uid = get_user_id();
$profile = db_fetch("SELECT * FROM seller_profiles WHERE user_id=?", [$uid]);

$stats = [
    'products' => db_fetch("SELECT COUNT(*) as c FROM products WHERE seller_id=?", [$uid])['c'],
    'approved' => db_fetch("SELECT COUNT(*) as c FROM products WHERE seller_id=? AND status='approved'", [$uid])['c'],
    'pending'  => db_fetch("SELECT COUNT(*) as c FROM products WHERE seller_id=? AND status='pending'", [$uid])['c'],
    'orders'   => db_fetch("SELECT COUNT(DISTINCT oi.order_id) as c FROM order_items oi WHERE oi.seller_id=?", [$uid])['c'],
    'earnings' => db_fetch("SELECT SUM(oi.subtotal) as c FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE oi.seller_id=? AND o.payment_status='paid'", [$uid])['c'] ?? 0,
];

$recent_orders = db_fetch_all("
    SELECT oi.*, o.order_number, o.status as order_status, o.created_at, u.name as customer_name
    FROM order_items oi
    JOIN orders o ON o.id=oi.order_id
    JOIN users u ON u.id=o.user_id
    WHERE oi.seller_id=?
    ORDER BY o.created_at DESC LIMIT 8
", [$uid]);

$my_products = db_fetch_all("SELECT p.*, c.name as cat_name FROM products p JOIN categories c ON p.category_id=c.id WHERE p.seller_id=? ORDER BY p.created_at DESC LIMIT 5", [$uid]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Seller Dashboard – CraftStore</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/main.css">
</head>
<body>
<div class="dashboard-layout">
    <?php include '../includes/sidebar.php'; ?>
    <div class="dashboard-main">
        <div class="dashboard-topbar">
            <div style="display:flex;align-items:center;gap:1rem">
                <button class="btn btn-ghost btn-icon" id="sidebarOpenBtn"><i class="fas fa-bars"></i></button>
                <div>
                    <h1 class="topbar-title">Welcome, <?= htmlspecialchars(explode(' ', $_SESSION['user_name'])[0]) ?>! 🎨</h1>
                    <p style="font-size:.78rem;color:var(--text-muted)"><?= htmlspecialchars($profile['shop_name'] ?? 'Your Shop') ?></p>
                </div>
            </div>
            <div class="topbar-actions">
                <a href="/Craft/seller/add-product.php" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Add Product</a>
                <button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button>
            </div>
        </div>
        <div class="dashboard-content">
            <!-- Stats -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon purple"><i class="fas fa-paint-brush"></i></div>
                    <div>
                        <p class="stat-value"><?= $stats['products'] ?></p>
                        <p class="stat-label">Total Products</p>
                        <span class="stat-change" style="color:var(--secondary)"><i class="fas fa-clock"></i> <?= $stats['pending'] ?> pending</span>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon green"><i class="fas fa-check-circle"></i></div>
                    <div>
                        <p class="stat-value"><?= $stats['approved'] ?></p>
                        <p class="stat-label">Approved Products</p>
                        <span class="stat-change up"><i class="fas fa-arrow-up"></i> Live on store</span>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon amber"><i class="fas fa-shopping-bag"></i></div>
                    <div>
                        <p class="stat-value"><?= $stats['orders'] ?></p>
                        <p class="stat-label">Total Orders</p>
                        <span class="stat-change up"><i class="fas fa-arrow-up"></i> Growing</span>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon blue"><i class="fas fa-rupee-sign"></i></div>
                    <div>
                        <p class="stat-value">₹<?= number_format($stats['earnings']) ?></p>
                        <p class="stat-label">Total Earnings</p>
                        <span class="stat-change up"><i class="fas fa-arrow-up"></i> Paid orders</span>
                    </div>
                </div>
            </div>

            <!-- Two columns -->
            <div style="display:grid;grid-template-columns:1.5fr 1fr;gap:1.5rem">
                <!-- Recent Orders -->
                <div class="table-wrapper">
                    <div class="table-header">
                        <h3>Recent Orders</h3>
                        <a href="/Craft/seller/orders.php" class="btn btn-ghost btn-sm">View All</a>
                    </div>
                    <table class="data-table">
                        <thead><tr><th>Order #</th><th>Product</th><th>Customer</th><th>Amount</th><th>Status</th></tr></thead>
                        <tbody>
                        <?php if (empty($recent_orders)): ?>
                        <tr><td colspan="5" style="text-align:center;padding:2rem;color:var(--text-muted)">No orders yet</td></tr>
                        <?php else: foreach($recent_orders as $ro): ?>
                        <tr>
                            <td style="font-size:.82rem;color:var(--primary);font-weight:600"><?= $ro['order_number'] ?></td>
                            <td style="font-size:.82rem"><?= htmlspecialchars(substr($ro['product_name'],0,25)) ?></td>
                            <td style="font-size:.82rem"><?= htmlspecialchars($ro['customer_name']) ?></td>
                            <td style="font-weight:700;font-size:.88rem">₹<?= number_format($ro['subtotal']) ?></td>
                            <td><span class="status-badge status-<?= $ro['order_status'] ?>"><?= ucfirst($ro['order_status']) ?></span></td>
                        </tr>
                        <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- My Products -->
                <div class="chart-card">
                    <div class="chart-card-header">
                        <h3 class="chart-card-title">My Products</h3>
                        <a href="/Craft/seller/products.php" class="btn btn-ghost btn-sm">View All</a>
                    </div>
                    <?php if (empty($my_products)): ?>
                    <div class="empty-state" style="padding:2rem">
                        <div class="empty-icon"><i class="fas fa-plus-circle"></i></div>
                        <p class="empty-subtitle">Start by adding your first product</p>
                        <a href="/Craft/seller/add-product.php" class="btn btn-primary btn-sm">Add Product</a>
                    </div>
                    <?php else: foreach($my_products as $p): ?>
                    <div style="display:flex;align-items:center;gap:.75rem;padding:.8rem 0;border-bottom:1px solid var(--border)">
                        <div style="width:40px;height:40px;background:rgba(124,58,237,0.1);border-radius:10px;display:flex;align-items:center;justify-content:center;flex-shrink:0">
                            <i class="fas fa-palette" style="color:var(--primary);font-size:.85rem"></i>
                        </div>
                        <div style="flex:1;min-width:0">
                            <p style="font-size:.85rem;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($p['name']) ?></p>
                            <p style="font-size:.73rem;color:var(--text-muted)"><?= $p['cat_name'] ?> • Stock: <?= $p['stock'] ?></p>
                        </div>
                        <div style="text-align:right;flex-shrink:0">
                            <p style="font-size:.85rem;font-weight:800;color:var(--primary)">₹<?= number_format($p['sale_price'] ?? $p['price']) ?></p>
                            <span class="status-badge status-<?= $p['status'] ?>" style="font-size:.65rem"><?= ucfirst($p['status']) ?></span>
                        </div>
                    </div>
                    <?php endforeach; endif; ?>
                    <div style="margin-top:1rem">
                        <a href="/Craft/seller/add-product.php" class="btn btn-primary w-full">
                            <i class="fas fa-plus"></i> Add New Product
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="sidebarOverlay" style="position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:850;display:none" onclick="document.getElementById('dashboardSidebar').classList.remove('open');this.style.display='none'"></div>
<script>document.getElementById('sidebarOpenBtn')?.addEventListener('click', function() { document.getElementById('dashboardSidebar').classList.toggle('open'); document.getElementById('sidebarOverlay').style.display = document.getElementById('dashboardSidebar').classList.contains('open') ? 'block' : 'none'; });</script>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body></html>
