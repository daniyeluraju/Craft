<?php
require_once '../includes/auth.php';
require_role('seller');
$uid = get_user_id();

// Fetch earnings (paid orders only)
$earnings = db_fetch_all("
    SELECT oi.*, o.order_number, o.created_at, o.payment_method, o.payment_status, u.name as customer_name
    FROM order_items oi
    JOIN orders o ON o.id = oi.order_id
    JOIN users u ON u.id = o.user_id
    WHERE oi.seller_id = ? AND o.payment_status = 'paid'
    ORDER BY o.created_at DESC
", [$uid]);

$total_earnings = 0;
$this_month = 0;
$current_month = date('Y-m');

foreach ($earnings as $e) {
    $total_earnings += $e['subtotal'];
    if (strpos($e['created_at'], $current_month) === 0) {
        $this_month += $e['subtotal'];
    }
}

// Get seller profile to check if payment info is set up
$seller = db_fetch("SELECT account_number, ifsc_code, bank_name FROM seller_profiles WHERE user_id=?", [$uid]);
$bank_setup = !empty($seller['account_number']) && !empty($seller['ifsc_code']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Earnings – Seller | CraftStore</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/main.css">
</head>
<body>
<div class="dashboard-layout">
    <?php include '../includes/sidebar.php'; ?>
    <div class="dashboard-main">
        <div class="dashboard-topbar">
            <div style="display:flex;align-items:center;gap:1rem">
                <button class="btn btn-ghost btn-icon" id="sidebarOpenBtn"><i class="fas fa-bars"></i></button>
                <h1 class="topbar-title">Earnings Overview</h1>
            </div>
            <div class="topbar-actions"><button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button></div>
        </div>
        <div class="dashboard-content">

            <?php if (!$bank_setup): ?>
            <div style="background:rgba(245,158,11,0.08);border:1px solid rgba(245,158,11,0.25);border-radius:10px;padding:1.25rem;margin-bottom:1.5rem;display:flex;align-items:center;gap:1rem">
                <div style="width:40px;height:40px;border-radius:50%;background:rgba(245,158,11,0.2);color:var(--secondary);display:flex;align-items:center;justify-content:center;font-size:1.2rem;flex-shrink:0">
                    <i class="fas fa-exclamation-triangle"></i>
                </div>
                <div style="flex:1">
                    <p style="font-weight:700;color:var(--text);margin-bottom:.2rem">Missing Payment Information</p>
                    <p style="font-size:.85rem;color:var(--text-muted)">Please set up your Bank Account Details in your profile to receive payouts smoothly.</p>
                </div>
                <a href="/Craft/seller/profile.php" class="btn btn-secondary btn-sm"><i class="fas fa-landmark"></i> Update Profile</a>
            </div>
            <?php endif; ?>

            <div class="stats-grid" style="grid-template-columns:repeat(3, 1fr);margin-bottom:1.5rem">
                <div class="stat-card" style="background:linear-gradient(135deg, rgba(16,185,129,0.1), rgba(16,185,129,0.02));border-color:rgba(16,185,129,0.2)">
                    <div class="stat-icon green"><i class="fas fa-wallet"></i></div>
                    <div>
                        <p class="stat-value" style="color:var(--accent)">₹<?= number_format($total_earnings, 2) ?></p>
                        <p class="stat-label">Total Earnings (Lifetime)</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon purple"><i class="fas fa-calendar-check"></i></div>
                    <div>
                        <p class="stat-value">₹<?= number_format($this_month, 2) ?></p>
                        <p class="stat-label">Earnings This Month</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon blue"><i class="fas fa-receipt"></i></div>
                    <div>
                        <p class="stat-value"><?= count($earnings) ?></p>
                        <p class="stat-label">Total Paid Items</p>
                    </div>
                </div>
            </div>

            <div class="chart-card">
                <div class="chart-card-header">
                    <h3 class="chart-card-title">Earnings History</h3>
                </div>
                
                <?php if (empty($earnings)): ?>
                <div class="empty-state">
                    <div class="empty-icon"><i class="fas fa-piggy-bank"></i></div>
                    <h3 class="empty-title">No Earnings Yet</h3>
                    <p class="empty-subtitle">Your completed and paid orders will appear here automatically.</p>
                </div>
                <?php else: ?>
                <div class="table-wrapper">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Order #</th>
                                <th>Product</th>
                                <th>Customer</th>
                                <th>Method</th>
                                <th>Amount</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($earnings as $e): ?>
                            <tr>
                                <td style="font-size:.85rem;color:var(--text-muted)"><?= date('d M Y, h:i A', strtotime($e['created_at'])) ?></td>
                                <td><span style="font-size:.82rem;font-weight:700;color:var(--primary)"><?= $e['order_number'] ?></span></td>
                                <td>
                                    <p style="font-weight:600;font-size:.88rem"><?= htmlspecialchars(substr($e['product_name'],0,30)) ?>...</p>
                                    <span style="font-size:.75rem;color:var(--text-muted)">Qty: <?= $e['quantity'] ?></span>
                                </td>
                                <td style="font-size:.85rem"><?= htmlspecialchars($e['customer_name']) ?></td>
                                <td>
                                    <span style="font-size:.78rem;padding:.2rem .5rem;background:var(--surface-2);border-radius:4px;font-weight:600">
                                        <?= strtoupper($e['payment_method']) ?>
                                    </span>
                                </td>
                                <td style="font-weight:800;color:var(--accent)">₹<?= number_format($e['subtotal'], 2) ?></td>
                                <td><span class="status-badge status-paid"><i class="fas fa-check-circle" style="margin-right:2px"></i> Paid</span></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
            
        </div>
    </div>
</div>
<div id="sidebarOverlay" style="position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:850;display:none" onclick="document.getElementById('dashboardSidebar').classList.remove('open');this.style.display='none'"></div>
<script>document.getElementById('sidebarOpenBtn')?.addEventListener('click', function() { document.getElementById('dashboardSidebar').classList.toggle('open'); document.getElementById('sidebarOverlay').style.display = document.getElementById('dashboardSidebar').classList.contains('open') ? 'block' : 'none'; });</script>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body></html>
