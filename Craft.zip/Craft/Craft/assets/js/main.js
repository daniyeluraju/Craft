// =====================================================
// CraftStore - Main JavaScript
// =====================================================

document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    initNavbar();
    initMobileMenu();
    initLiveSearch();
    initToasts();
    initModals();
    initQuantitySelectors();
    initParticles();
    initAnimations();
    initSidebar();
});

// ── Theme (Dark/Light) ──
function initTheme() {
    const toggle = document.getElementById('themeToggle');
    const saved   = localStorage.getItem('craft_theme') || 'light';
    applyTheme(saved);

    toggle?.addEventListener('click', () => {
        const current = document.documentElement.getAttribute('data-theme') || 'light';
        const next    = current === 'light' ? 'dark' : 'light';
        applyTheme(next);
        localStorage.setItem('craft_theme', next);
    });
}
function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    const icon = document.querySelector('#themeToggle i');
    if (icon) icon.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
}

// ── Navbar scroll effect ──
function initNavbar() {
    const navbar = document.getElementById('mainNavbar');
    if (!navbar) return;
    const onScroll = () => navbar.classList.toggle('scrolled', window.scrollY > 20);
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
}

// ── Mobile Menu ──
function initMobileMenu() {
    const btn   = document.getElementById('mobileMenuBtn');
    const menu  = document.getElementById('mobileMenu');
    if (!btn || !menu) return;
    btn.addEventListener('click', () => menu.classList.toggle('open'));
    document.addEventListener('click', e => {
        if (!btn.contains(e.target) && !menu.contains(e.target))
            menu.classList.remove('open');
    });
}

// ── Dashboard Sidebar ──
function initSidebar() {
    const openBtn  = document.getElementById('sidebarOpenBtn');
    const closeBtn = document.getElementById('sidebarClose');
    const sidebar  = document.getElementById('dashboardSidebar');
    const overlay  = document.getElementById('sidebarOverlay');
    if (!sidebar) return;
    const open  = () => { sidebar.classList.add('open');  overlay?.classList.add('show'); };
    const close = () => { sidebar.classList.remove('open'); overlay?.classList.remove('show'); };
    openBtn?.addEventListener('click', open);
    closeBtn?.addEventListener('click', close);
    overlay?.addEventListener('click', close);
}

// ── Live Search ──
function initLiveSearch() {
    const input    = document.getElementById('navSearch');
    const dropdown = document.getElementById('searchDropdown');
    if (!input || !dropdown) return;

    let timer;
    input.addEventListener('input', () => {
        clearTimeout(timer);
        const q = input.value.trim();
        if (q.length < 2) { dropdown.classList.remove('show'); return; }
        timer = setTimeout(() => fetchSearchResults(q, dropdown), 300);
    });

    document.addEventListener('click', e => {
        if (!input.contains(e.target)) dropdown.classList.remove('show');
    });
}
async function fetchSearchResults(query, dropdown) {
    try {
        const res  = await fetch(`/Craft/includes/ajax/search.php?q=${encodeURIComponent(query)}`);
        const data = await res.json();
        renderSearchResults(data, dropdown);
    } catch { dropdown.classList.remove('show'); }
}
function renderSearchResults(products, dropdown) {
    if (!products.length) {
        dropdown.innerHTML = `<div class="search-item"><p style="color:var(--text-muted);font-size:.85rem">No products found</p></div>`;
        dropdown.classList.add('show');
        return;
    }
    dropdown.innerHTML = products.map(p => `
        <a href="/Craft/public/product.php?id=${p.id}" class="search-item">
            <div class="art-placeholder" style="width:44px;height:44px;border-radius:8px;flex-shrink:0">
                <i class="fas fa-image" style="font-size:1rem"></i>
            </div>
            <div class="search-item-info">
                <strong>${escHtml(p.name)}</strong>
                <span>₹${parseFloat(p.price).toLocaleString('en-IN')}</span>
            </div>
        </a>`).join('');
    dropdown.classList.add('show');
}

// ── Toast Notifications ──
function initToasts() {
    // Auto-dismiss existing toasts
    document.querySelectorAll('.toast').forEach(t => {
        setTimeout(() => t.classList.remove('show'), 4000);
    });
}
function showToast(msg, type = 'success') {
    let container = document.getElementById('toastContainer');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toastContainer';
        container.className = 'toast-container';
        document.body.appendChild(container);
    }
    const icons = { success: 'check-circle', error: 'exclamation-circle', info: 'info-circle', warning: 'exclamation-triangle' };
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `<i class="fas fa-${icons[type] || icons.success}"></i> ${escHtml(msg)} <button class="toast-close" onclick="this.parentElement.remove()">×</button>`;
    container.appendChild(toast);
    requestAnimationFrame(() => { requestAnimationFrame(() => toast.classList.add('show')); });
    setTimeout(() => { toast.classList.remove('show'); setTimeout(() => toast.remove(), 400); }, 4000);
}

// ── Modals ──
function initModals() {
    document.querySelectorAll('[data-modal-open]').forEach(btn => {
        btn.addEventListener('click', () => openModal(btn.dataset.modalOpen));
    });
    document.querySelectorAll('[data-modal-close], .modal-close').forEach(btn => {
        btn.addEventListener('click', () => {
            const modal = btn.closest('.modal-overlay');
            if (modal) closeModal(modal.id);
        });
    });
    document.querySelectorAll('.modal-overlay').forEach(overlay => {
        overlay.addEventListener('click', e => { if (e.target === overlay) closeModal(overlay.id); });
    });
}
function openModal(id)  { document.getElementById(id)?.classList.add('open'); }
function closeModal(id) { document.getElementById(id)?.classList.remove('open'); }

// ── Quantity Selectors ──
function initQuantitySelectors() {
    document.querySelectorAll('.quantity-selector').forEach(sel => {
        const input  = sel.querySelector('.qty-input');
        const minBtn = sel.querySelector('.qty-btn[data-action="decrease"]');
        const maxBtn = sel.querySelector('.qty-btn[data-action="increase"]');
        const min    = parseInt(input?.min || 1);
        const max    = parseInt(input?.max || 99);
        minBtn?.addEventListener('click', () => { if (parseInt(input.value) > min) { input.value--; input.dispatchEvent(new Event('change')); } });
        maxBtn?.addEventListener('click', () => { if (parseInt(input.value) < max) { input.value++; input.dispatchEvent(new Event('change')); } });
    });
}

// ── Hero Particles ──
function initParticles() {
    const container = document.querySelector('.hero-particles');
    if (!container) return;
    const count = window.innerWidth > 768 ? 14 : 7;
    for (let i = 0; i < count; i++) {
        const p = document.createElement('div');
        p.className = 'hero-particle';
        const size = Math.random() * 8 + 3;
        p.style.cssText = `
            width:${size}px; height:${size}px;
            left:${Math.random() * 100}%;
            animation-delay:${Math.random() * 8}s;
            animation-duration:${Math.random() * 6 + 6}s;
            opacity:${Math.random() * 0.5 + 0.2};
        `;
        container.appendChild(p);
    }
}

// ── Scroll Animations ──
function initAnimations() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(e => {
            if (e.isIntersecting) { e.target.classList.add('animate-in'); observer.unobserve(e.target); }
        });
    }, { threshold: 0.1 });
    document.querySelectorAll('.product-card, .feature-card, .category-card, .stat-card').forEach(el => {
        el.style.opacity = '0'; el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
        observer.observe(el);
    });
    document.addEventListener('animationend', e => {
        if (e.target.classList.contains('animate-in')) { e.target.style.opacity = ''; e.target.style.transform = ''; }
    });
    // Trigger animate-in
    document.querySelectorAll('.animate-in').forEach(el => { el.style.opacity = '1'; el.style.transform = 'none'; });
}

// ── Cart Functions (AJAX) ──
async function addToCart(productId, qty = 1) {
    try {
        const res  = await fetch('/Craft/includes/ajax/cart.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'add', product_id: productId, quantity: qty })
        });
        const data = await res.json();
        if (data.success) {
            showToast('Added to cart! 🛒', 'success');
            updateCartCount(data.cart_count);
        } else {
            showToast(data.message || 'Failed to add to cart', 'error');
        }
    } catch { showToast('Something went wrong', 'error'); }
}

async function removeFromCart(itemId, callback) {
    try {
        const res  = await fetch('/Craft/includes/ajax/cart.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'remove', item_id: itemId })
        });
        const data = await res.json();
        if (data.success) { showToast('Item removed', 'info'); callback && callback(data); }
    } catch { showToast('Error removing item', 'error'); }
}

async function updateCartQty(itemId, qty, callback) {
    try {
        const res  = await fetch('/Craft/includes/ajax/cart.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'update', item_id: itemId, quantity: qty })
        });
        const data = await res.json();
        if (data.success && callback) callback(data);
    } catch {}
}

function updateCartCount(count) {
    const badge = document.querySelector('.cart-btn .badge');
    if (!badge && count > 0) {
        const btn = document.querySelector('.cart-btn');
        if (btn) { const b2 = document.createElement('span'); b2.className = 'badge'; b2.textContent = count; btn.appendChild(b2); }
    } else if (badge) {
        badge.textContent = count;
        if (count <= 0) badge.remove();
    }
}

// ── Wishlist Functions ──
async function toggleWishlist(productId, btn) {
    try {
        const res  = await fetch('/Craft/includes/ajax/wishlist.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ product_id: productId })
        });
        const data = await res.json();
        if (data.success) {
            btn?.classList.toggle('wishlisted', data.wishlisted);
            showToast(data.wishlisted ? 'Added to wishlist ❤️' : 'Removed from wishlist', data.wishlisted ? 'success' : 'info');
        } else if (data.redirect) {
            window.location.href = data.redirect;
        }
    } catch { showToast('Something went wrong', 'error'); }
}

// ── Utilities ──
function escHtml(str) {
    const d = document.createElement('div'); d.textContent = str; return d.innerHTML;
}
function formatPrice(n) {
    return '₹' + parseFloat(n).toLocaleString('en-IN', { minimumFractionDigits: 2 });
}
function debounce(fn, delay) {
    let t; return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), delay); };
}

// ── Star Rating Input ──
function initStarRating(containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;
    const stars  = container.querySelectorAll('.star-input');
    const hidden = container.querySelector('input[type="hidden"]');
    stars.forEach(star => {
        star.addEventListener('click', () => {
            const val = parseInt(star.dataset.value);
            if (hidden) hidden.value = val;
            stars.forEach(s => s.classList.toggle('active', parseInt(s.dataset.value) <= val));
        });
        star.addEventListener('mouseenter', () => {
            const val = parseInt(star.dataset.value);
            stars.forEach(s => s.classList.toggle('hover', parseInt(s.dataset.value) <= val));
        });
    });
    container.addEventListener('mouseleave', () => stars.forEach(s => s.classList.remove('hover')));
}

// IntersectionObserver for animate-in
(function() {
    const style = document.createElement('style');
    style.textContent = `.animate-in { opacity: 1 !important; transform: translateY(0) !important; }`;
    document.head.appendChild(style);
})();
